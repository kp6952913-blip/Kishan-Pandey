import 'dotenv/config'
import fs from 'fs'
import path from 'path'
import bcrypt from 'bcryptjs'
import { fileURLToPath } from 'url'
import { connectDB } from '../config/db.js'
import Patient from '../models/Patient.js'
import HospitalStaff from '../models/HospitalStaff.js'
import MedicalReport from '../models/MedicalReport.js'
import { storePdf } from '../services/pdfService.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const patients = JSON.parse(fs.readFileSync(path.join(__dirname,'data/patients.json'),'utf8'))
const staff = JSON.parse(fs.readFileSync(path.join(__dirname,'data/hospitalStaff.json'),'utf8'))
const sampleReports = JSON.parse(fs.readFileSync(path.join(__dirname,'data/medicalReports.json'),'utf8'))

// Minimal, valid, single-page PDF used as placeholder content for seeded demo reports.
const PLACEHOLDER_PDF = Buffer.from(
  '%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n' +
  '3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Resources<</Font<</F1 4 0 R>>>>/Contents 5 0 R>>endobj\n' +
  '4 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\n' +
  '5 0 obj<</Length 78>>stream\nBT /F1 18 Tf 72 700 Td (MaatriCare Medical Report - Sample Document) Tj ET\nendstream endobj\n' +
  'trailer<</Root 1 0 R>>',
  'utf8'
)

await connectDB()
for (const item of staff) {
  const existing=await HospitalStaff.findOne({id:item.id})
  if (!existing) await HospitalStaff.create({...item,password:await bcrypt.hash(item.password,12)})
}
for (const item of patients) {
  const existing=await Patient.findOne({id:item.id})
  if (!existing) await Patient.create({...item,password:await bcrypt.hash(item.password,12)})
}

for (const item of sampleReports) {
  const existing = await MedicalReport.findOne({ reportId: item.reportId })
  if (existing) continue
  const patient = await Patient.findOne({ id: item.patientId })
  const provider = await HospitalStaff.findOne({ id: item.staffId })
  if (!patient || !provider) continue
  const pdfFileId = await storePdf(PLACEHOLDER_PDF, `${item.reportId}.pdf`, 'application/pdf')
  await MedicalReport.create({
    ...item,
    patientName: patient.name,
    staffName: provider.name,
    staffProfession: provider.profession,
    pdfFileId,
    pdfFileName: `${item.reportId}.pdf`,
    pdfMimeType: 'application/pdf',
    pdfSize: PLACEHOLDER_PDF.length,
  })
}

console.log(`Seed complete: ${await Patient.countDocuments()} patients, ${await HospitalStaff.countDocuments()} staff, ${await MedicalReport.countDocuments()} medical reports.`)
process.exit(0)
