import Appointment from '../models/Appointment.js'
import Patient from '../models/Patient.js'
import HospitalStaff from '../models/HospitalStaff.js'

const pub = (a) => { const o = a.toObject ? a.toObject() : a; delete o._id; delete o.__v; return { ...o, id: o.appointmentId } }

export async function createAppointment(req, res) {
  const body = req.body || {}
  const patientId = req.user.role === 'patient' ? req.user.id : body.patientId
  const patient = await Patient.findOne({ id: patientId })
  const staff = await HospitalStaff.findOne({ id: body.staffId })
  if (!patient) return res.status(404).json({ success:false,message:'Patient not found.' })
  if (!staff) return res.status(404).json({ success:false,message:'Selected care provider was not found.' })
  if (!body.date || !body.time) return res.status(400).json({ success:false,message:'Appointment date and time are required.' })
  const dateOnly = new Date(`${body.date}T00:00:00`)
  if (Number.isNaN(dateOnly.getTime())) return res.status(400).json({ success:false,message:'Invalid appointment date.' })
  if (dateOnly < new Date(new Date().toDateString())) return res.status(400).json({ success:false,message:'Appointment date cannot be in the past.' })
  const conflict = await Appointment.findOne({ staffId: staff.id, date: body.date, time: body.time, status: { $ne: 'Cancelled' } })
  if (conflict) return res.status(409).json({ success:false,message:'This appointment slot is already booked.' })
  const appointment = await Appointment.create({
    appointmentId: `APT-${Date.now()}-${Math.floor(Math.random()*1000)}`,
    patientId: patient.id, patientName: patient.name,
    staffId: staff.id, staffName: staff.name, staffProfession: staff.profession,
    date: body.date, time: body.time, status: 'Upcoming'
  })
  res.status(201).json({ success:true,data:pub(appointment) })
}

export async function myAppointments(req, res) {
  const filter = req.user.role === 'patient' ? { patientId: req.user.id } : { staffId: req.user.id }
  const appointments = await Appointment.find(filter).sort({ date: 1, time: 1 })
  res.json({ success:true,data:appointments.map(pub) })
}

export async function getAppointment(req, res) {
  const appointment = await Appointment.findOne({ appointmentId: req.params.id })
  if (!appointment) return res.status(404).json({ success:false,message:'Appointment not found.' })
  if (req.user.role === 'patient' && appointment.patientId !== req.user.id) return res.status(403).json({ success:false,message:'Not authorized.' })
  if (req.user.role === 'staff' && appointment.staffId !== req.user.id) return res.status(403).json({ success:false,message:'Not authorized.' })
  res.json({ success:true,data:pub(appointment) })
}

export async function updateAppointment(req, res) {
  const appointment = await Appointment.findOne({ appointmentId: req.params.id })
  if (!appointment) return res.status(404).json({ success:false,message:'Appointment not found.' })
  if (req.user.role === 'patient' && appointment.patientId !== req.user.id) return res.status(403).json({ success:false,message:'Not authorized.' })
  if (req.user.role === 'staff' && appointment.staffId !== req.user.id) return res.status(403).json({ success:false,message:'Not authorized.' })
  if (req.body.status) appointment.status = req.body.status
  if (req.body.date) appointment.date = req.body.date
  if (req.body.time) appointment.time = req.body.time
  await appointment.save()
  res.json({ success:true,data:pub(appointment) })
}

export async function deleteAppointment(req, res) {
  const appointment = await Appointment.findOne({ appointmentId: req.params.id })
  if (!appointment) return res.status(404).json({ success:false,message:'Appointment not found.' })
  if (req.user.role === 'patient' && appointment.patientId !== req.user.id) return res.status(403).json({ success:false,message:'Not authorized.' })
  if (req.user.role === 'staff' && appointment.staffId !== req.user.id) return res.status(403).json({ success:false,message:'Not authorized.' })
  await appointment.deleteOne()
  res.json({ success:true })
}

export async function availability(req, res) {
  const { staffId, date } = req.query
  if (!staffId || !date) return res.status(400).json({ success:false,message:'staffId and date are required.' })
  const appointments = await Appointment.find({ staffId, date, status: { $ne: 'Cancelled' } }).select('time status -_id')
  res.json({ success:true,data:appointments })
}
