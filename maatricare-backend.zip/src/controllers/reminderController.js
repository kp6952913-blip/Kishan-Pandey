import Reminder from '../models/Reminder.js'

function defaults(patientId) { return [
  { id:`${patientId}-r1`, patientId, time:'08:00 AM', type:'Medicine', title:'Prenatal Vitamins', detail:'Take with food. Dosage: 1 Tablet.', completed:false },
  { id:`${patientId}-r2`, patientId, time:'09:00 AM', type:'Hydration', title:'Morning Hydration', detail:'Drink 500ml of water.', completed:false },
  { id:`${patientId}-r3`, patientId, time:'02:30 PM', type:'Appointment', title:'Ultrasound Scan', detail:'Remember to bring previous reports.', completed:false },
] }
const pub = (x) => { const o = x.toObject ? x.toObject() : x; delete o._id; delete o.__v; return o }

export async function listMyReminders(req,res) {
  let reminders = await Reminder.find({ patientId:req.user.id }).sort({ time:1 })
  if (!reminders.length) { reminders = await Reminder.insertMany(defaults(req.user.id)); }
  res.json({success:true,data:reminders.map(pub)})
}
export async function createReminder(req,res) { const r=await Reminder.create({ ...req.body, id:req.body.id || `${req.user.id}-r-${Date.now()}`, patientId:req.user.id }); res.status(201).json({success:true,data:pub(r)}) }
export async function updateReminder(req,res) { const r=await Reminder.findOneAndUpdate({id:req.params.id,patientId:req.user.id},{ $set:req.body },{new:true}); if(!r)return res.status(404).json({success:false,message:'Reminder not found.'}); res.json({success:true,data:pub(r)}) }
export async function deleteReminder(req,res) { await Reminder.deleteOne({id:req.params.id,patientId:req.user.id}); res.json({success:true}) }
