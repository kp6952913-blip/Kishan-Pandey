import HealthLog from '../models/HealthLog.js'
import Patient from '../models/Patient.js'

const pub = (x) => { const o = x.toObject ? x.toObject() : x; delete o._id; delete o.__v; return o }

export async function addHealthLog(req, res) {
  if (req.user.role !== 'patient' || req.user.id !== req.params.patientId) return res.status(403).json({ success:false,message:'You can only add health logs to your own record.' })
  const log = await HealthLog.create({ patientId: req.user.id, ...req.body })
  const patient = await Patient.findOne({ id: req.user.id })
  if (patient) {
    patient.weight = req.body.weight || patient.weight
    patient.vitals = { ...(patient.vitals || {}), bloodPressure: req.body.bloodPressure || patient.vitals?.bloodPressure, heartRate: req.body.heartRate || patient.vitals?.heartRate, bloodSugar: req.body.bloodSugar || patient.vitals?.bloodSugar }
    patient.currentSymptoms = req.body.symptoms || patient.currentSymptoms
    await patient.save()
  }
  res.status(201).json({ success:true,data:pub(log),patient })
}

export async function listHealthLogs(req, res) {
  if (req.user.role === 'patient' && req.user.id !== req.params.patientId) return res.status(403).json({ success:false,message:'Not authorized.' })
  const logs = await HealthLog.find({ patientId: req.params.patientId }).sort({ date: -1 })
  res.json({ success:true,data:logs.map(pub) })
}
