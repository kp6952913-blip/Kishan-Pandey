import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import Patient from '../models/Patient.js'
import HospitalStaff from '../models/HospitalStaff.js'

function publicPatient(p) { const obj = p.toObject ? p.toObject() : p; delete obj.password; delete obj._id; delete obj.__v; return obj }
function publicStaff(s) { const obj = s.toObject ? s.toObject() : s; delete obj.password; delete obj._id; delete obj.__v; return obj }
function setAuthCookie(res, user) {
  const token = jwt.sign(user, process.env.JWT_SECRET, { expiresIn: '7d' })
  res.cookie('midcare_token', token, { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 7 * 24 * 60 * 60 * 1000, path: '/' })
}

export async function patientLogin(req, res) {
  const { email, password } = req.body
  const patient = await Patient.findOne({ email: String(email || '').toLowerCase() }).select('+password')
  if (!patient || !(await bcrypt.compare(String(password || ''), patient.password))) return res.status(401).json({ success: false, message: 'Incorrect email or password for patient portal.' })
  setAuthCookie(res, { role: 'patient', id: patient.id })
  res.json({ success: true, data: { user: publicPatient(patient), role: 'patient' } })
}

export async function staffLogin(req, res) {
  const { email, password } = req.body
  const staff = await HospitalStaff.findOne({ email: String(email || '').toLowerCase() }).select('+password')
  if (!staff || !(await bcrypt.compare(String(password || ''), staff.password))) return res.status(401).json({ success: false, message: 'Incorrect email or password for hospital staff.' })
  setAuthCookie(res, { role: 'staff', id: staff.id })
  res.json({ success: true, data: { user: publicStaff(staff), role: 'staff' } })
}

export async function me(req, res) {
  if (req.user.role === 'patient') {
    const patient = await Patient.findOne({ id: req.user.id })
    if (!patient) return res.status(401).json({ success: false, message: 'Patient account no longer exists.' })
    return res.json({ success: true, data: { user: publicPatient(patient), role: 'patient' } })
  }
  const staff = await HospitalStaff.findOne({ id: req.user.id })
  if (!staff) return res.status(401).json({ success: false, message: 'Staff account no longer exists.' })
  res.json({ success: true, data: { user: publicStaff(staff), role: 'staff' } })
}

export function logout(req, res) {
  res.clearCookie('midcare_token', { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/' })
  res.json({ success: true })
}
