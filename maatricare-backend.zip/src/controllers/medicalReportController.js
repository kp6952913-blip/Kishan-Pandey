import MedicalReport from '../models/MedicalReport.js'
import Patient from '../models/Patient.js'
import HospitalStaff from '../models/HospitalStaff.js'
import { storePdf, streamPdf, deletePdf } from '../services/pdfService.js'

const REPORT_TYPES = ['Anomaly Scan', 'Growth Scan', 'Blood Test', 'Ultrasound', 'Lab Report', 'General Consultation']

const pub = (r) => {
  const o = r.toObject ? r.toObject() : r
  delete o._id; delete o.__v; delete o.pdfFileId
  return { ...o, id: o.reportId, hasPdf: !!r.pdfFileId }
}

function nextReportId() {
  return `MR-${Date.now()}-${Math.floor(Math.random() * 1000)}`
}

// POST /api/medical-reports  (staff only, multipart/form-data)
export async function createMedicalReport(req, res) {
  const body = req.body || {}
  const { patientId, title, summary } = body
  const reportType = body.reportType && REPORT_TYPES.includes(body.reportType) ? body.reportType : (body.reportType || 'General Consultation')
  const status = body.status === 'Requires Review' ? 'Requires Review' : 'Normal'

  if (!patientId) return res.status(400).json({ success: false, message: 'Please select a patient.' })
  if (!title || !summary) return res.status(400).json({ success: false, message: 'Report title and summary are required.' })

  const patient = await Patient.findOne({ id: patientId })
  if (!patient) return res.status(404).json({ success: false, message: 'Patient not found.' })

  const staff = await HospitalStaff.findOne({ id: req.user.id })
  if (!staff) return res.status(404).json({ success: false, message: 'Staff account not found.' })

  if (!req.file) return res.status(400).json({ success: false, message: 'A PDF attachment is required for the medical report.' })

  let pdfFileId
  try {
    pdfFileId = await storePdf(req.file.buffer, req.file.originalname, req.file.mimetype)
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Failed to store the PDF attachment. Please try again.' })
  }

  try {
    const report = await MedicalReport.create({
      reportId: nextReportId(),
      patientId: patient.id,
      patientName: patient.name,
      staffId: staff.id,
      staffName: staff.name,
      staffProfession: staff.profession,
      title,
      reportType,
      summary,
      status,
      pdfFileId,
      pdfFileName: req.file.originalname,
      pdfMimeType: req.file.mimetype,
      pdfSize: req.file.size,
    })
    res.status(201).json({ success: true, data: pub(report) })
  } catch (err) {
    await deletePdf(pdfFileId)
    throw err
  }
}

// GET /api/medical-reports/my  (patient only — own reports)
export async function myMedicalReports(req, res) {
  const reports = await MedicalReport.find({ patientId: req.user.id }).sort({ createdAt: -1 })
  res.json({ success: true, data: reports.map(pub) })
}

// GET /api/medical-reports/patient/:patientId  (staff only — reports for a given patient)
export async function patientMedicalReports(req, res) {
  const reports = await MedicalReport.find({ patientId: req.params.patientId }).sort({ createdAt: -1 })
  res.json({ success: true, data: reports.map(pub) })
}

// GET /api/medical-reports/:id
export async function getMedicalReport(req, res) {
  const report = await MedicalReport.findOne({ reportId: req.params.id })
  if (!report) return res.status(404).json({ success: false, message: 'Report not found.' })
  if (req.user.role === 'patient' && report.patientId !== req.user.id) {
    return res.status(403).json({ success: false, message: 'Not authorized to view this report.' })
  }
  res.json({ success: true, data: pub(report) })
}

// GET /api/medical-reports/:id/pdf
export async function downloadMedicalReportPdf(req, res) {
  const report = await MedicalReport.findOne({ reportId: req.params.id })
  if (!report) return res.status(404).json({ success: false, message: 'Report not found.' })
  if (req.user.role === 'patient' && report.patientId !== req.user.id) {
    return res.status(403).json({ success: false, message: 'Not authorized to download this report.' })
  }
  if (req.user.role === 'staff' && report.staffId !== req.user.id) {
    return res.status(403).json({ success: false, message: 'Not authorized to download this report.' })
  }
  if (!report.pdfFileId) return res.status(404).json({ success: false, message: 'No PDF is attached to this report.' })

  res.setHeader('Content-Type', report.pdfMimeType || 'application/pdf')
  res.setHeader('Content-Disposition', `attachment; filename="${(report.pdfFileName || 'report.pdf').replace(/"/g, '')}"`)
  try {
    await streamPdf(report.pdfFileId, res)
  } catch (err) {
    if (!res.headersSent) res.status(404).json({ success: false, message: 'The stored PDF could not be found.' })
  }
}
