import Patient from '../models/Patient.js'
import Appointment from '../models/Appointment.js'

export async function staffDashboard(req,res) {
  const today = new Date().toISOString().slice(0,10)
  const [patients, appointments, highRisk, deliveries] = await Promise.all([
    Patient.find().select('id status createdAt pregnancyWeek riskLevel name lastCheckup lastNote').sort({createdAt:-1}),
    Appointment.find({ staffId:req.user.id, date:today, status:{ $ne:'Cancelled' } }).sort({time:1}),
    Patient.countDocuments({ $or:[{riskLevel:'High Risk'},{risk:'High Risk'}] }),
    Patient.countDocuments({ pregnancyWeek:{ $gte:38 } }),
  ])
  const months=[]; const now=new Date()
  for(let i=5;i>=0;i--){ const d=new Date(now.getFullYear(),now.getMonth()-i,1); months.push({key:`${d.getFullYear()}-${d.getMonth()}`,month:d.toLocaleString('en-US',{month:'short'})}) }
  const counts=Object.fromEntries(months.map(m=>[m.key,0])); patients.forEach(p=>{const d=new Date(p.createdAt);const k=`${d.getFullYear()}-${d.getMonth()}`;if(k in counts)counts[k]++})
  res.json({success:true,data:{patientsCount:patients.length,activePatients:patients.filter(p=>p.status!=='DISCHARGED').length,highRiskPatients:highRisk,deliveries, todaysAppointments:appointments, registrationTrend:months.map(m=>({month:m.month,patients:counts[m.key]})),recentRegistrations:patients.slice(0,5)}})
}
