import bcrypt from 'bcryptjs'
import Patient from '../models/Patient.js'

const publicPatient = (p) => { const obj = p.toObject ? p.toObject() : p; delete obj.password; delete obj._id; delete obj.__v; return obj }

function nextPatientId() { return `PT-${Math.floor(100000 + Math.random() * 900000)}` }

export async function listPatients(req, res) {
  const q = String(req.query.search || '').trim()
  const filter = q ? { $or: [{ name: { $regex: q, $options: 'i' } }, { id: { $regex: q, $options: 'i' } }, { medicalConditions: { $regex: q, $options: 'i' } }] } : {}
  const patients = await Patient.find(filter).sort({ createdAt: -1 })
  res.json({ success: true, data: patients.map(publicPatient) })
}

export async function getMyPatient(req, res) {
  const patient = await Patient.findOne({ id: req.user.id })
  if (!patient) return res.status(404).json({ success: false, message: 'Patient not found.' })
  res.json({ success: true, data: publicPatient(patient) })
}

export async function getPatient(req, res) {
  const patient = await Patient.findOne({ id: req.params.id })
  if (!patient) return res.status(404).json({ success: false, message: 'Patient not found.' })
  if (req.user.role === 'patient' && req.user.id !== patient.id) return res.status(403).json({ success: false, message: 'You can only access your own patient record.' })
  res.json({ success: true, data: publicPatient(patient) })
}

export async function createPatient(req, res) {
  const body = req.body || {}
  const email = String(body.email || '').trim().toLowerCase()
  if (!body.name || !email || !body.password) return res.status(400).json({ success: false, message: 'Name, email, and password are required.' })
  if (await Patient.exists({ email })) return res.status(409).json({ success: false, message: 'A patient with this email already exists.' })
  let id = body.id?.trim() || nextPatientId()
  while (await Patient.exists({ id })) id = nextPatientId()
  const password = await bcrypt.hash(String(body.password), 12)
  const patient = await Patient.create({
    ...body,
    id,
    email,
    password,
    bmi: body.bmi || undefined,
    pregnancyWeek: Number(body.pregnancyWeek) || 1,
    previousPregnancies: Number(body.previousPregnancies) || 0,
    previousBirths: Number(body.previousBirths) || 0,
    status: body.status || 'STABLE',
    lastCheckup: body.lastCheckup || new Date().toISOString().slice(0, 10),
    lastNote: body.lastNote || 'New Registration',
    labReports: body.labReports || [],
  })
  res.status(201).json({ success: true, data: publicPatient(patient) })
}

export async function updatePatient(req, res) {
  const allowed = { ...req.body }
  delete allowed.password; delete allowed.email; delete allowed.id
  if (req.user.role === 'patient' && req.user.id !== req.params.id) return res.status(403).json({ success: false, message: 'You can only update your own patient record.' })
  const patient = await Patient.findOneAndUpdate({ id: req.params.id }, { $set: allowed }, { new: true, runValidators: true })
  if (!patient) return res.status(404).json({ success: false, message: 'Patient not found.' })
  res.json({ success: true, data: publicPatient(patient) })
}

export async function addLabReport(req, res) {
  if (req.user.role === 'patient' && req.user.id !== req.params.id) return res.status(403).json({ success: false, message: 'You can only update your own record.' })
  const patient = await Patient.findOneAndUpdate({ id: req.params.id }, { $push: { labReports: { $each: [req.body], $position: 0 } } }, { new: true })
  if (!patient) return res.status(404).json({ success: false, message: 'Patient not found.' })
  res.json({ success: true, data: publicPatient(patient) })
}
