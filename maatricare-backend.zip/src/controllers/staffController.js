import HospitalStaff from '../models/HospitalStaff.js'
const pub = (s) => { const o = s.toObject ? s.toObject() : s; delete o.password; delete o._id; delete o.__v; return o }
export async function listStaff(req, res) { const staff = await HospitalStaff.find().sort({ name: 1 }); res.json({ success: true, data: staff.map(pub) }) }
export async function getStaff(req, res) { const staff = await HospitalStaff.findOne({ id: req.params.id }); if (!staff) return res.status(404).json({ success:false,message:'Staff member not found.' }); res.json({ success:true,data:pub(staff) }) }
export async function meStaff(req, res) { const staff = await HospitalStaff.findOne({ id: req.user.id }); if (!staff) return res.status(404).json({ success:false,message:'Staff member not found.' }); res.json({ success:true,data:pub(staff) }) }
