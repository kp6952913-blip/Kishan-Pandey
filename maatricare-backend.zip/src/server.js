import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import rateLimit from 'express-rate-limit'
import cookieParser from 'cookie-parser'
import { connectDB } from './config/db.js'
import authRoutes from './routes/authRoutes.js'
import patientRoutes from './routes/patientRoutes.js'
import staffRoutes from './routes/staffRoutes.js'
import appointmentRoutes from './routes/appointmentRoutes.js'
import healthRoutes from './routes/healthRoutes.js'
import reminderRoutes from './routes/reminderRoutes.js'
import dashboardRoutes from './routes/dashboardRoutes.js'
import medicalReportRoutes from './routes/medicalReportRoutes.js'
import { notFound, errorHandler } from './middleware/errorMiddleware.js'

const app=express()
app.use(helmet())
app.use(cors({origin:process.env.CLIENT_URL || 'http://localhost:5173',credentials:true}))
app.use(express.json({limit:'1mb'}))
app.use(cookieParser())
app.use('/api/auth',rateLimit({windowMs:15*60*1000,max:100,standardHeaders:true,legacyHeaders:false}),authRoutes)
app.use('/api/patients',patientRoutes)
app.use('/api/staff',staffRoutes)
app.use('/api/appointments',appointmentRoutes)
app.use('/api/health-logs',healthRoutes)
app.use('/api/reminders',reminderRoutes)
app.use('/api/dashboard',dashboardRoutes)
app.use('/api/medical-reports',medicalReportRoutes)
app.get('/api/health',(req,res)=>res.json({success:true,message:'MaatriCare API is running.'}))
app.use(notFound); app.use(errorHandler)

const port=Number(process.env.PORT||5000)
connectDB().then(()=>app.listen(port,()=>console.log(`MaatriCare API listening on http://localhost:${port}`))).catch(err=>{console.error(err);process.exit(1)})
