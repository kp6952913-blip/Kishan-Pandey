import { Router } from 'express'
import { requireAuth, requireRole } from '../middleware/authMiddleware.js'
import { listMyReminders, createReminder, updateReminder, deleteReminder } from '../controllers/reminderController.js'
const router=Router(); router.use(requireAuth,requireRole('patient')); router.get('/my',listMyReminders); router.post('/',createReminder); router.patch('/:id',updateReminder); router.delete('/:id',deleteReminder); export default router
