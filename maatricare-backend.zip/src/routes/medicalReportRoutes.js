import { Router } from 'express'
import { requireAuth, requireRole } from '../middleware/authMiddleware.js'
import { handlePdfUpload } from '../middleware/uploadMiddleware.js'
import {
  createMedicalReport,
  myMedicalReports,
  patientMedicalReports,
  getMedicalReport,
  downloadMedicalReportPdf,
} from '../controllers/medicalReportController.js'

const router = Router()
router.use(requireAuth)

router.post('/', requireRole('staff'), handlePdfUpload, createMedicalReport)
router.get('/my', requireRole('patient'), myMedicalReports)
router.get('/patient/:patientId', requireRole('staff'), patientMedicalReports)
router.get('/:id/pdf', downloadMedicalReportPdf)
router.get('/:id', getMedicalReport)

export default router
