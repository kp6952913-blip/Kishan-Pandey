import { Router } from 'express'
import { requireAuth } from '../middleware/authMiddleware.js'
import { createAppointment, myAppointments, getAppointment, updateAppointment, deleteAppointment, availability } from '../controllers/appointmentController.js'
const router=Router(); router.use(requireAuth); router.post('/',createAppointment); router.get('/my',myAppointments); router.get('/availability',availability); router.get('/:id',getAppointment); router.patch('/:id',updateAppointment); router.delete('/:id',deleteAppointment); export default router
