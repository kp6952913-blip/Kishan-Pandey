import { Router } from 'express'
import { patientLogin, staffLogin, me, logout } from '../controllers/authController.js'
import { requireAuth } from '../middleware/authMiddleware.js'
const router=Router()
router.post('/patient/login',patientLogin); router.post('/staff/login',staffLogin); router.get('/me',requireAuth,me); router.post('/logout',logout)
export default router
