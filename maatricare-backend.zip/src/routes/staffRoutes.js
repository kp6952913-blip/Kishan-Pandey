import { Router } from 'express'
import { requireAuth } from '../middleware/authMiddleware.js'
import { listStaff, getStaff, meStaff } from '../controllers/staffController.js'
const router=Router(); router.use(requireAuth); router.get('/me',meStaff); router.get('/',listStaff); router.get('/:id',getStaff); export default router
