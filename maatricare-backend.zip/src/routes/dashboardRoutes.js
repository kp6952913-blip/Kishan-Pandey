import { Router } from 'express'
import { requireAuth, requireRole } from '../middleware/authMiddleware.js'
import { staffDashboard } from '../controllers/dashboardController.js'
const router=Router(); router.get('/staff',requireAuth,requireRole('staff'),staffDashboard); export default router
