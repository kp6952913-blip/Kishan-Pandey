import { Router } from 'express'
import { requireAuth, requireRole } from '../middleware/authMiddleware.js'
import { listPatients, getMyPatient, getPatient, createPatient, updatePatient, addLabReport } from '../controllers/patientController.js'
const router=Router()
router.use(requireAuth)
router.get('/me',requireRole('patient'),getMyPatient)
router.get('/',requireRole('staff'),listPatients)
router.post('/',requireRole('staff'),createPatient)
router.get('/:id',getPatient)
router.patch('/:id',updatePatient)
router.put('/:id',updatePatient)
router.post('/:id/lab-reports',addLabReport)
export default router
