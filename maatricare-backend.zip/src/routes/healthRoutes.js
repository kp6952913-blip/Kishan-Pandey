import { Router } from 'express'
import { requireAuth } from '../middleware/authMiddleware.js'
import { addHealthLog, listHealthLogs } from '../controllers/healthController.js'
const router=Router(); router.use(requireAuth); router.post('/:patientId',addHealthLog); router.get('/me',async (req,res)=>{ req.params.patientId=req.user.id; return listHealthLogs(req,res) }); router.get('/:patientId',listHealthLogs); export default router
