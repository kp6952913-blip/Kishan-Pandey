import mongoose from 'mongoose'
import { GridFSBucket, ObjectId } from 'mongodb'
import { Readable } from 'stream'

const BUCKET_NAME = 'medicalReportPdfs'

function getBucket() {
  return new GridFSBucket(mongoose.connection.db, { bucketName: BUCKET_NAME })
}

/**
 * Store a PDF buffer in GridFS and return its file id (as a string).
 */
export function storePdf(buffer, filename, mimeType) {
  return new Promise((resolve, reject) => {
    const bucket = getBucket()
    const uploadStream = bucket.openUploadStream(filename, { contentType: mimeType })
    Readable.from(buffer).pipe(uploadStream)
      .on('error', reject)
      .on('finish', () => resolve(uploadStream.id.toString()))
  })
}

/**
 * Stream a stored PDF to an Express response. Resolves once the stream has
 * started; rejects if the file cannot be found.
 */
export function streamPdf(fileId, res) {
  const bucket = getBucket()
  let objectId
  try {
    objectId = new ObjectId(fileId)
  } catch {
    return Promise.reject(new Error('Invalid file reference.'))
  }
  return new Promise((resolve, reject) => {
    const downloadStream = bucket.openDownloadStream(objectId)
    downloadStream.on('error', reject)
    downloadStream.on('file', () => resolve())
    downloadStream.pipe(res)
  })
}

/**
 * Delete a stored PDF (used if report creation fails after upload, or on report deletion).
 */
export async function deletePdf(fileId) {
  if (!fileId) return
  try {
    const bucket = getBucket()
    await bucket.delete(new ObjectId(fileId))
  } catch {
    // best-effort cleanup; ignore if already missing
  }
}
