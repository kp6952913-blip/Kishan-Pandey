import multer from 'multer'

const MAX_PDF_SIZE_MB = Number(process.env.PDF_MAX_SIZE_MB || 10)

const storage = multer.memoryStorage()

function pdfFileFilter(req, file, cb) {
  const isPdf = file.mimetype === 'application/pdf' || /\.pdf$/i.test(file.originalname || '')
  if (!isPdf) return cb(new Error('Only PDF files are allowed for medical report attachments.'))
  cb(null, true)
}

export const uploadPdf = multer({
  storage,
  fileFilter: pdfFileFilter,
  limits: { fileSize: MAX_PDF_SIZE_MB * 1024 * 1024 },
}).single('pdf')

// Wraps multer's callback-style middleware so upload errors flow into the
// existing Express error-handling middleware with friendly messages.
export function handlePdfUpload(req, res, next) {
  uploadPdf(req, res, (err) => {
    if (!err) return next()
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({ success: false, message: `PDF must be smaller than ${MAX_PDF_SIZE_MB}MB.` })
    }
    return res.status(400).json({ success: false, message: err.message || 'PDF upload failed.' })
  })
}
