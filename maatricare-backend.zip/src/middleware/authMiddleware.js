import jwt from 'jsonwebtoken'

export function requireAuth(req, res, next) {
  const token = req.cookies?.midcare_token
  if (!token) return res.status(401).json({ success: false, message: 'Authentication required.' })
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET)
    next()
  } catch {
    res.clearCookie('midcare_token')
    return res.status(401).json({ success: false, message: 'Your session has expired. Please log in again.' })
  }
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ success: false, message: 'You are not authorized to perform this action.' })
    }
    next()
  }
}
