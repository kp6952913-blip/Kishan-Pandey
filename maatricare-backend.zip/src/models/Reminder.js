import mongoose from 'mongoose'

const reminderSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  patientId: { type: String, required: true, index: true },
  time: String,
  type: String,
  title: String,
  detail: String,
  completed: { type: Boolean, default: false },
}, { timestamps: true })

export default mongoose.model('Reminder', reminderSchema)
