import mongoose from 'mongoose'

const patientSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true, index: true },
  password: { type: String, required: true, select: false },
  age: Number, dob: String, phone: String, address: String, bloodGroup: String,
  height: Number, weight: Number, bmi: Number,
  pregnancyWeek: Number, dueDate: String,
  previousPregnancies: Number, previousBirths: Number,
  previousComplications: String, medicalConditions: String, allergies: String, medications: String,
  partnerName: String, partnerPhone: String, partnerEmail: String, emergencyContact: String,
  riskLevel: String, currentSymptoms: { type: [String], default: [] },
  doctor: String, midwife: String, nurse: String,
  vitals: { bloodPressure: String, hemoglobin: mongoose.Schema.Types.Mixed, bloodSugar: mongoose.Schema.Types.Mixed, heartRate: mongoose.Schema.Types.Mixed },
  baby: { name: String, weight: mongoose.Schema.Types.Mixed, height: mongoose.Schema.Types.Mixed },
  status: String, lastCheckup: String, lastNote: String,
  labReports: { type: [mongoose.Schema.Types.Mixed], default: [] },
  createdAt: { type: Date, default: Date.now },
}, { timestamps: true })

export default mongoose.model('Patient', patientSchema)
