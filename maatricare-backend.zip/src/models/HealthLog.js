import mongoose from 'mongoose'

const healthLogSchema = new mongoose.Schema({
  patientId: { type: String, required: true, index: true },
  date: { type: Date, default: Date.now },
  weight: mongoose.Schema.Types.Mixed,
  bloodPressure: String,
  heartRate: mongoose.Schema.Types.Mixed,
  bloodSugar: mongoose.Schema.Types.Mixed,
  mood: String,
  energyLevel: Number,
  sleepQuality: String,
  symptoms: { type: [String], default: [] },
}, { timestamps: true })

export default mongoose.model('HealthLog', healthLogSchema)
