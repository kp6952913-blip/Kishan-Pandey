import mongoose from 'mongoose'

const appointmentSchema = new mongoose.Schema({
  appointmentId: { type: String, required: true, unique: true, index: true },
  patientId: { type: String, required: true, index: true },
  patientName: String,
  staffId: { type: String, required: true, index: true },
  staffName: String,
  staffProfession: String,
  date: { type: String, required: true, index: true },
  time: { type: String, required: true },
  status: { type: String, enum: ['Upcoming', 'Completed', 'Cancelled'], default: 'Upcoming', index: true },
}, { timestamps: true })

appointmentSchema.index({ staffId: 1, date: 1, time: 1 }, {})

export default mongoose.model('Appointment', appointmentSchema)
