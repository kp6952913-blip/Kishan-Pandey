import mongoose from 'mongoose'

const medicalReportSchema = new mongoose.Schema({
  reportId: { type: String, required: true, unique: true, index: true },

  patientId: { type: String, required: true, index: true },
  patientName: String,

  staffId: { type: String, required: true, index: true },
  staffName: String,
  staffProfession: String,

  title: { type: String, required: true },
  reportType: { type: String, required: true },
  summary: { type: String, required: true }, // human-readable message / key findings text
  status: { type: String, enum: ['Normal', 'Requires Review'], default: 'Normal' },

  // GridFS reference for the attached PDF
  pdfFileId: { type: String }, // ObjectId (as string) of the GridFS file
  pdfFileName: String,
  pdfMimeType: String,
  pdfSize: Number,
}, { timestamps: true })

medicalReportSchema.index({ patientId: 1, createdAt: -1 })
medicalReportSchema.index({ staffId: 1, createdAt: -1 })

export default mongoose.model('MedicalReport', medicalReportSchema)
