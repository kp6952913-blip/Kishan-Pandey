import mongoose from 'mongoose'

const staffSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true, index: true },
  password: { type: String, required: true, select: false },
  profession: { type: String, required: true },
}, { timestamps: true })

export default mongoose.model('HospitalStaff', staffSchema)
