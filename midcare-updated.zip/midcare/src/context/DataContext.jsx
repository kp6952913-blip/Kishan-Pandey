import React,{createContext,useContext,useEffect,useState} from 'react'
import {getAppointments,getHealthLogs,getPatients,getUploads,getReminders,saveAppointments,saveHealthLogs,savePatients,saveUploads,saveReminders} from '../utils/storage.js'
const C=createContext(null)
export function DataProvider({children}){const[,tick]=useState(0);useEffect(()=>{const f=()=>tick(x=>x+1);window.addEventListener('midcare-data',f);return()=>window.removeEventListener('midcare-data',f)},[]);return <C.Provider value={{patients:getPatients(),appointments:getAppointments(),healthLogs:getHealthLogs(),uploads:getUploads(),reminders:getReminders(),savePatients,saveAppointments,saveHealthLogs,saveUploads,saveReminders}}>{children}</C.Provider>}
export const useData=()=>useContext(C)
