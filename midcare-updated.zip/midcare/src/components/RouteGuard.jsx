import React from 'react'
import {Navigate,useLocation} from 'react-router-dom'
import {useAuth} from '../context/AuthContext.jsx'
export default function RouteGuard({role,children}){const{session}=useAuth();const loc=useLocation();if(!session)return <Navigate to="/login" replace state={{from:loc.pathname}}/>;if(session.role!==role)return <Navigate to={session.role==='hospital'?'/staff':'/portal'} replace/>;return children}
