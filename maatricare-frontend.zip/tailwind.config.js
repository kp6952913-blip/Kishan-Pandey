/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#eef4ff',
          100: '#dbe7ff',
          200: '#bcd2ff',
          300: '#8fb4ff',
          400: '#5c8dff',
          500: '#2f66f5',
          600: '#1a4be0',
          700: '#153bb8',
          800: '#152f8f',
          900: '#101d4a',
        },
        care: {
          teal: '#2fe0c0',
          tealDark: '#0f9f89',
        },
        ink: '#0b1330',
      },
      fontFamily: {
        serif: ['Georgia', 'Cambria', '"Times New Roman"', 'serif'],
        sans: ['Inter', 'system-ui', 'Segoe UI', 'sans-serif'],
      },
      boxShadow: {
        soft: '0 1px 2px rgba(16, 29, 74, 0.04), 0 8px 24px rgba(16, 29, 74, 0.06)',
      },
    },
  },
  plugins: [],
}
