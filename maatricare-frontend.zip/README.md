# MidCare — React + Node.js + MongoDB

This project now uses a real Node.js/Express backend and MongoDB instead of the frontend JSON/localStorage database.

## Architecture

React/Vite → Express/Node.js API → Mongoose → MongoDB

Dynamic application data is stored in MongoDB:

- `patients`
- `hospitalstaff`
- `appointments`
- `healthlogs`
- `reminders`

`src/data/patients.json` and `src/data/hospitalStaff.json` are no longer used by the frontend runtime. Seed copies live only under `backend/src/seed/data/` so the original demo accounts can be migrated once.

## Requirements

- Node.js 18+
- MongoDB running locally or a MongoDB Atlas connection

## Backend setup

```bash
cd backend
cp .env.example .env
npm install
npm run seed
npm run dev
```

Set `MONGODB_URI`, `JWT_SECRET`, and `CLIENT_URL` in `backend/.env`.

## Frontend setup

From the project root:

```bash
cp .env.example .env
npm install
npm run dev
```

Default API URL: `http://localhost:5000/api`.

## Demo accounts

Patient:

- `sarahj@midcare.com`
- `patient123`

Staff:

- `sarah@midcare.com`
- `doctor123`

The seed script hashes passwords with bcrypt before inserting them into MongoDB.

## Important flows

### Patient login

Patient login → `/api/auth/patient/login` → MongoDB `patients` → HttpOnly JWT cookie → patient portal.

### Staff login

Staff login → `/api/auth/staff/login` → MongoDB `hospitalstaff` → HttpOnly JWT cookie → staff portal.

### New patient

Staff New Patient form → `POST /api/patients` → bcrypt password hash → MongoDB → staff patient list.

### Appointment

Patient selects a date and care provider → `POST /api/appointments` → MongoDB `appointments` → authenticated staff appointment query → selected doctor/staff portal.

The backend prevents conflicting appointments for the same staff/date/time unless the existing appointment is cancelled.

### Health tracker

Patient health check-in → `POST /api/health-logs/:patientId` → MongoDB → patient vitals are updated → refresh-safe history.

### Reminders

Patient reminders → MongoDB `reminders`; first access creates the default reminder set for that patient.

## Main API routes

- `POST /api/auth/patient/login`
- `POST /api/auth/staff/login`
- `GET /api/auth/me`
- `POST /api/auth/logout`
- `GET/POST /api/patients`
- `GET/PATCH /api/patients/:id`
- `POST /api/patients/:id/lab-reports`
- `GET /api/staff`
- `POST /api/appointments`
- `GET /api/appointments/my`
- `GET /api/appointments/availability`
- `PATCH /api/appointments/:id`
- `POST /api/health-logs/:patientId`
- `GET /api/health-logs/me`
- `GET/PATCH /api/reminders/my` / `/api/reminders/:id`
- `GET /api/dashboard/staff`
