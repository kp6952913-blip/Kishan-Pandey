// All data below is transcribed directly from the provided PDF design spec.
// Replace with real API calls / a backend of your choice when wiring this up for production.

export const stats = [
  { label: 'Healthy Deliveries', value: '25,000' },
  { label: 'Partner Hospitals', value: '500' },
  { label: 'System Uptime', value: '99.9%' },
  { label: 'Support Access', value: '24/7' },
]

export const features = [
  {
    title: 'Hospital Management',
    description:
      'Streamline workflows, manage appointments, and access secure electronic health records with an interface designed for clinical speed.',
    icon: 'ClipboardPlus',
  },
  {
    title: 'Patient Tracking',
    description:
      'Real-time vitals sync, milestone tracking, and risk assessment algorithms that alert providers to potential complications early.',
    icon: 'Activity',
  },
  {
    title: 'Smart Reminders',
    description:
      'Automated SMS and push notifications for prenatal appointments, medication schedules, and personalized educational content.',
    icon: 'BellRing',
  },
]

export const staffNav = [
  { label: 'Dashboard', icon: 'LayoutGrid', to: '/staff' },
  { label: 'Patients', icon: 'Users', to: '/staff/patients' },
  { label: 'Appointments', icon: 'CalendarDays', to: '/staff/appointments' },
  { label: 'EMR', icon: 'FileStack', to: '/staff/emr' },
  { label: 'Vaccinations', icon: 'Syringe', to: '/staff/vaccinations' },
  { label: 'Delivery', icon: 'HeartHandshake', to: '/staff/delivery' },
  { label: 'Reports', icon: 'BarChart3', to: '/staff/reports' },
  { label: 'Emergency', icon: 'Siren', to: '/staff/emergency', danger: true },
]

export const staffKpis = [
  { label: 'Registered', value: '1,240', delta: '+12%', tone: 'up', icon: 'Users' },
  { label: 'Active', value: '450', delta: '+5%', tone: 'up', icon: 'PersonStanding' },
  { label: "Today's Appts", value: '18', sub: 'Scheduled', icon: 'CalendarDays' },
  { label: 'High-Risk', value: '12', delta: '+2', tone: 'alert', icon: 'AlertTriangle' },
  { label: 'Deliveries (Mo)', value: '45', sub: 'Est. 52', icon: 'Smile' },
]

export const registrationTrend = [
  { month: 'Jan', patients: 62 },
  { month: 'Feb', patients: 78 },
  { month: 'Mar', patients: 71 },
  { month: 'Apr', patients: 94 },
  { month: 'May', patients: 86 },
  { month: 'Jun', patients: 110 },
]

export const appointmentBreakdown = [
  { label: 'Completed', value: 10, color: '#2f66f5' },
  { label: 'In Progress', value: 4, color: '#2fe0c0' },
  { label: 'Waiting', value: 3, color: '#bcd2ff' },
  { label: 'No Show', value: 1, color: '#e2e8f0' },
]

export const recentRegistrations = [
  { name: 'Elena Rodriguez', id: 'PT-8924', week: 12, nextAppt: 'Oct 12, 10:00 AM', status: 'Routine' },
  { name: 'Sarah Jenkins', id: 'PT-8925', week: 34, nextAppt: 'Tomorrow, 2:30 PM', status: 'High Risk' },
  { name: 'Maya Patel', id: 'PT-8926', week: 20, nextAppt: 'Oct 15, 9:15 AM', status: 'Routine' },
]

export const urgentTasks = [
  {
    title: 'Review Blood Work — S. Jenkins',
    description: 'Elevated blood pressure noted in recent triage. Requires immediate sign-off.',
    cta: 'Review Now',
    tone: 'alert',
  },
  {
    title: 'Approve Ultrasound Referrals',
    description: '5 pending referrals for 20-week anatomy scans need authorization.',
    cta: 'Open Queue',
    tone: 'info',
  },
]

export const patients = [
  {
    initials: 'EJ',
    name: 'Elena Jimenez',
    id: '#4829-A',
    week: 32,
    risk: 'High Risk',
    lastCheckup: 'Oct 12, 2023',
    lastNote: 'BP Elevated',
    nextAppt: 'Tomorrow',
    nextApptTime: '09:00 AM',
    status: 'ADMITTED',
  },
  {
    initials: 'SW',
    name: 'Sarah Washington',
    id: '#5102-B',
    week: 14,
    risk: 'Routine',
    lastCheckup: 'Sep 28, 2023',
    lastNote: 'Normal Scan',
    nextAppt: 'Oct 26, 2023',
    nextApptTime: '14:30 PM',
    status: 'STABLE',
  },
  {
    initials: 'MC',
    name: 'Maria Chen',
    id: '#4911-C',
    week: 38,
    risk: 'Monitor',
    lastCheckup: 'Oct 14, 2023',
    lastNote: 'NST Reactive',
    nextAppt: 'Oct 17, 2023',
    nextApptTime: '10:00 AM',
    status: 'DISCHARGED',
  },
]

export const patientNav = [
  { label: 'Dashboard', icon: 'Home', to: '/portal' },
  { label: 'My Baby', icon: 'Baby', to: '/portal/baby' },
  { label: 'Appointments', icon: 'CalendarDays', to: '/portal/appointments' },
  { label: 'Medical Records', icon: 'FileText', to: '/portal/profile' },
  { label: 'Medical Reports', icon: 'FileStack', to: '/portal/reports' },
  { label: 'Reminders', icon: 'AlarmClock', to: '/portal/reminders' },
  { label: 'Health Tracker', icon: 'LineChart', to: '/portal/health' },
  { label: 'Messages', icon: 'MessageSquare', to: '/portal/messages' },
  { label: 'SOS Emergency', icon: 'Siren', to: '/portal/sos', danger: true },
]

export const atAGlance = [
  { label: 'Due Date', icon: 'CalendarHeart', value: 'Estimated: Jan 12', sub: '112 days' },
  { label: 'Next Visit', icon: 'Stethoscope', value: 'Dr. Sarah Jenkins', sub: 'Oct 15 · 10:30 AM · Clinic', highlight: true },
  { label: 'Weight Tracking', icon: 'Scale', value: 'Since week 1', sub: '+6 kg' },
  { label: 'Daily Tip', icon: 'Droplet', value: 'Stay Hydrated', sub: 'Aim for 8–12 cups of water today. Proper hydration helps fetal circulation.' },
]

export const quickAccess = [
  { label: 'Medical Records', icon: 'FileText', to: '/portal/profile' },
  { label: 'Vaccinations', icon: 'Syringe', to: '/portal/profile' },
  { label: 'Nutrition Plan', icon: 'Utensils', to: '/portal/health' },
  { label: 'Emergency SOS', icon: 'Siren', to: '/portal/sos', danger: true },
]

export const trimesters = [
  { range: 'Weeks 1–13', title: 'First Trimester', note: 'Foundation & first heartbeat.' },
  { range: 'Weeks 14–27', title: 'Second Trimester', note: 'Movement & hearing develop.', current: true },
  { range: 'Weeks 28–40', title: 'Third Trimester', note: 'Preparation for birth.' },
]

export const babyDevelopments = [
  { category: 'Sensory', detail: 'Hearing sounds from the outside world.' },
  { category: 'Motor Skills', detail: 'Feeling stronger kicks and movements.' },
  { category: 'Internal', detail: 'Lungs are developing surfactant.' },
]

export const weightProgression = [
  { week: 'Wk 14', lbs: 0 },
  { week: 'Wk 18', lbs: 0.4 },
  { week: 'Wk 24', lbs: 0.9 },
  { week: 'Wk 27', lbs: 1.3 },
]

export const vitals = [
  { label: 'Blood Pressure', value: '118/75', unit: 'mmHg', status: 'Optimal', icon: 'HeartPulse' },
  { label: 'Weight', value: '68.5', unit: 'kg', status: '+0.5kg since last', icon: 'Scale' },
  { label: 'Blood Sugar (F)', value: '85', unit: 'mg/dL', status: 'Normal', icon: 'Droplets' },
  { label: 'Hemoglobin', value: '11.8', unit: 'g/dL', status: 'Stable', icon: 'TestTube' },
  { label: 'BMI', value: '24.2', unit: '', status: 'Healthy Range', icon: 'Gauge' },
  { label: 'Risk Level', value: 'Low', unit: '', status: 'Routine Care Pathway', icon: 'ShieldCheck' },
]

export const medicalTimeline = [
  {
    date: 'Today · Wk 24',
    title: 'Routine Checkup',
    provider: 'Dr. Emily Chen',
    note: 'Fetal heart rate normal (145 bpm). Fundal height on track. Discussed nutrition plan for third trimester.',
  },
  {
    date: 'Aug 12, 2024 · Wk 20',
    title: 'Anatomy Scan',
    provider: 'Midwife Sarah Jenkins',
    note: 'Detailed anatomy scan completed. No anomalies detected. Placenta anterior, clear of os.',
  },
  {
    date: 'Jul 15, 2024 · Wk 16',
    title: 'Quad Marker Screen',
    provider: 'Dr. Emily Chen',
    note: 'Blood drawn for screening. Results negative for neural tube defects.',
  },
]

export const immunizations = [
  { name: 'Flu Vaccine', status: 'Administered: Wk 14' },
  { name: 'Tdap Vaccine', status: 'Upcoming: Wk 28' },
]

export const prescriptions = [
  { name: 'Prenatal Vitamins', freq: 'DAILY', dosage: '1 tablet oral with food', refills: 2 },
  { name: 'Iron Supplement (325mg)', freq: 'DAILY', dosage: '1 tablet oral, alternate days', refills: 1 },
]

export const reminderSummary = [
  { label: 'Today', value: '5 Tasks', sub: '2 Completed · 60%' },
  { label: 'Tomorrow', value: '3 Tasks', sub: 'Includes 1 Doctor Visit' },
  { label: 'This Week', value: '12 Tasks', sub: '4 Vaccinations pending' },
  { label: 'Completed', value: '85%', sub: 'Great job this week!' },
]

export const todaysSchedule = [
  { time: '08:00 AM', type: 'Medicine', title: 'Prenatal Vitamins', detail: 'Take with food. Dosage: 1 Tablet.' },
  { time: '09:00 AM', type: 'Hydration', title: 'Morning Hydration', detail: 'Drink 500ml of water.' },
  { time: '02:30 PM', type: 'Appointment', title: 'Ultrasound Scan', detail: 'Dr. Smith at City Hospital. Remember to bring previous reports.' },
]

export const quickAddActions = ['Medicine', 'Water', 'Exercise', 'Nutrition', 'Custom Reminder', 'Notification Settings']

export const healthToday = {
  weight: '142 lbs',
  bloodPressure: '118/76 mmHg',
  heartRate: '78 bpm',
  mood: 'Good',
  babyMovements: 'Normal',
  energyLevel: 7,
  sleepQuality: '6.5 hrs',
  symptoms: ['Nausea', 'Backache', 'Headache', 'Fatigue'],
}

export const weightChart = [
  { week: 'Wk 12', lbs: 132 },
  { week: 'Wk 16', lbs: 136 },
  { week: 'Wk 20', lbs: 139 },
  { week: 'Wk 24', lbs: 142 },
  { week: 'Wk 28', lbs: 146 },
  { week: 'Wk 32', lbs: 149 },
  { week: 'Wk 36', lbs: 152 },
]

export const bpTrend = [
  { day: 'M', systolic: 117 },
  { day: 'T', systolic: 119 },
  { day: 'W', systolic: 116 },
  { day: 'T', systolic: 118 },
  { day: 'F', systolic: 120 },
  { day: 'S', systolic: 118 },
  { day: 'S', systolic: 118 },
]

export const doctorNote = "Your blood pressure trend looks stable. Let's schedule your glucose screening test for sometime next week."

export const appointmentSummary = [
  { label: 'Upcoming', value: '3', sub: 'Next in 4 days' },
  { label: 'Completed', value: '12', sub: '75% of plan' },
  { label: 'Missed', value: '1', sub: 'Requires reschedule' },
  { label: 'Total Health Score', value: '94/100', sub: 'Excellent vitals trend' },
]

export const calendarMonth = {
  label: 'October 2024',
  days: [
    { day: 3, event: 'Dr. Smith — Routine' },
    { day: 10, event: 'Ultrasound — Resched' },
    { day: 14, event: '24W Checkup — 2:00 PM', active: true },
  ],
}

export const nextAppointment = {
  title: '24W Telehealth Review',
  provider: 'Dr. Sarah Jenkins · OBGYN',
  time: 'Today, 2:00 PM – 2:30 PM',
  eta: 'In 2 hours',
  checklist: ['Log morning blood pressure', 'Prepare list of questions'],
  location: {
    name: "MaatriCare Women's Pavilion",
    address: '1245 Medical Center Dr, Suite 300, New York, NY 10001',
  },
}

export const recentNotes = [
  {
    status: 'COMPLETED',
    date: 'Oct 3, 2024',
    title: 'Routine 22W Checkup',
    provider: 'Dr. Emily Chen · Memorial Hospital',
    note: 'Vitals normal. Fetal heart rate strong at 145 bpm. Fundal height measures 22cm, appropriate for gestational age. Patient reported mild round ligament pain, advised on gentle stretching and supportive wear.',
    attachment: 'Lab_Results_Oct3.pdf',
  },
]

export const careTeam = [
  { name: 'Dr. Sarah Evans', role: 'OBGYN', online: true },
  { name: 'Midwife Lin', role: 'Midwife', online: false },
  { name: 'Nurse Sam', role: 'Nurse', online: false },
]

export const conversations = [
  { name: 'Dr. Sarah Evans', preview: "I've reviewed your latest ultrasound...", time: '10:42 AM', active: true },
  { name: 'Midwife Lin', preview: "Don't forget your breathing exercises.", time: 'Yesterday' },
  { name: 'Billing Support', preview: 'Your recent invoice has been processed.', time: 'Mon' },
]

export const chatMessages = [
  { from: 'them', time: '10:30 AM', text: "Good morning Sarah! I've reviewed your latest ultrasound results from yesterday. Everything is looking wonderful. The baby is measuring right on track for 24 weeks." },
  { from: 'me', time: '10:32 AM', text: 'Oh that is such a relief to hear! Thank you Dr. Evans. I was a bit worried about the kick counts I have been feeling.' },
  { from: 'them', time: '10:35 AM', text: 'No need to worry, the kick counts are perfectly normal for this stage. I have attached the detailed report and a few images for your records.', attachment: 'Ultrasound_Report.pdf · 1.2 MB' },
  { from: 'them', time: '10:42 AM', text: "I've also sent over a prescription for those prenatal vitamins we discussed. Let me know if you need help scheduling your week 28 checkup.", cta: 'View Prescription' },
]

export const emergencyTimeline = [
  { time: '14:02', title: 'SOS Signal Sent', detail: 'Location and medical vitals transmitted to emergency network.' },
  { time: '14:03', title: 'Accepted by City General Hospital', detail: 'Dr. Emily Chen is reviewing your patient file.' },
  { time: '14:04', title: 'Ambulance Dispatched', detail: 'Unit #42 en route. Paramedic John Davis.' },
  { time: null, title: 'Arrived at Location', detail: 'Pending arrival.' },
]

export const criticalVitals = {
  week: 24,
  bloodGroup: 'O+',
  allergies: ['Penicillin', 'Latex'],
  conditions: ['Gestational Diabetes (Controlled)'],
  medicines: ['Prenatal Vitamins', 'Metformin (500mg)'],
}

export const quickDial = [
  { name: 'City General', role: 'HOSPITAL' },
  { name: 'Dr. E. Chen', role: 'PRIMARY OBGYN' },
  { name: 'Michael J.', role: 'PARTNER / EMERGENCY CONTACT' },
]
