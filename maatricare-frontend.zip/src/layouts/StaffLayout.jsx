import React from 'react'
import StaffSidebar from '../components/staff/StaffSidebar.jsx'
import StaffTopbar from '../components/staff/StaffTopbar.jsx'

export default function StaffLayout({ children }) {
  return (
    <div className="flex min-h-screen bg-slate-50">
      <StaffSidebar />
      <div className="flex-1">
        <StaffTopbar />
        <main className="px-4 py-6 sm:px-6 lg:px-8">{children}</main>
      </div>
    </div>
  )
}
