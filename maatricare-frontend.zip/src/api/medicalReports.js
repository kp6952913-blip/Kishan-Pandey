import { api, API_BASE_URL } from './apiClient.js'

/**
 * Staff: create a new medical report for a patient (message/summary + PDF attachment).
 * @param {{patientId:string,title:string,reportType:string,summary:string,status?:string,pdfFile:File}} input
 */
export function createMedicalReport({ patientId, title, reportType, summary, status, pdfFile }) {
  const form = new FormData()
  form.append('patientId', patientId)
  form.append('title', title)
  form.append('reportType', reportType)
  form.append('summary', summary)
  if (status) form.append('status', status)
  if (pdfFile) form.append('pdf', pdfFile)
  return api.postForm('/medical-reports', form)
}

/** Patient: fetch own report history. */
export function fetchMyMedicalReports() {
  return api.get('/medical-reports/my')
}

/** Staff: fetch reports previously sent to a given patient. */
export function fetchPatientMedicalReports(patientId) {
  return api.get(`/medical-reports/patient/${patientId}`)
}

export function fetchMedicalReport(reportId) {
  return api.get(`/medical-reports/${reportId}`)
}

/**
 * Downloads a report's PDF as a Blob and triggers a browser save.
 * Uses fetch with credentials directly (not apiClient) since the response is
 * a binary file, not JSON.
 */
export async function downloadMedicalReportPdf(reportId, suggestedFileName) {
  const response = await fetch(`${API_BASE_URL}/medical-reports/${reportId}/pdf`, { credentials: 'include' })
  if (!response.ok) {
    let message = 'Unable to download the PDF.'
    try { message = (await response.json()).message || message } catch { /* non-JSON error body */ }
    throw new Error(message)
  }
  const blob = await response.blob()
  const url = window.URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = suggestedFileName || 'medical-report.pdf'
  document.body.appendChild(link)
  link.click()
  link.remove()
  window.URL.revokeObjectURL(url)
}
