const API_BASE_URL = (import.meta.env.VITE_API_URL || 'http://localhost:5000/api').replace(/\/$/, '')

async function request(path, options = {}) {
  const config = {
    credentials: 'include',
    headers: {
      ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
      ...(options.headers || {}),
    },
    ...options,
  }

  const response = await fetch(`${API_BASE_URL}${path}`, config)
  let payload = null
  try { payload = await response.json() } catch { payload = null }

  if (!response.ok) {
    const error = new Error(payload?.message || 'Request failed. Please try again.')
    error.status = response.status
    error.payload = payload
    throw error
  }

  return payload
}

export const api = {
  get: (path) => request(path),
  post: (path, body) => request(path, { method: 'POST', body: JSON.stringify(body) }),
  // Use for multipart/form-data uploads (e.g. medical report PDF attachments).
  // `body` must be a FormData instance — request() already skips the JSON
  // Content-Type header for FormData so the browser can set the boundary.
  postForm: (path, formData) => request(path, { method: 'POST', body: formData }),
  patch: (path, body) => request(path, { method: 'PATCH', body: JSON.stringify(body) }),
  put: (path, body) => request(path, { method: 'PUT', body: JSON.stringify(body) }),
  delete: (path) => request(path, { method: 'DELETE' }),
}

export { API_BASE_URL }
