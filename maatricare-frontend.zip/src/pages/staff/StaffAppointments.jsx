import React, { useEffect, useMemo, useState } from 'react'
import { CalendarDays, Clock, User } from 'lucide-react'
import StaffLayout from '../../layouts/StaffLayout.jsx'
import Card from '../../components/common/Card.jsx'
import Badge from '../../components/common/Badge.jsx'
import { api } from '../../api/apiClient.js'
import { useAppData } from '../../context/AppDataContext.jsx'
import { formatDate, titleForProfession } from '../../utils/pregnancy.js'

const tabs = ['Upcoming', 'Completed', 'Cancelled']
const statusTone = { Upcoming: 'brand', Completed: 'success', Cancelled: 'alert' }

export default function StaffAppointments() {
  const { currentStaff } = useAppData()
  const [appointments, setAppointments] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [tab, setTab] = useState('Upcoming')
  const [updatingId, setUpdatingId] = useState(null)

  // Always fetches fresh from the database — this page never relies solely
  // on previously loaded React state, per the sync requirements.
  async function loadAppointments() {
    setLoading(true)
    setError('')
    try {
      const result = await api.get('/appointments/my')
      setAppointments(result.data || [])
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { loadAppointments() }, [])

  const filtered = useMemo(
    () => appointments.filter((a) => a.status === tab).sort((a, b) => new Date(`${a.date}T00:00`) - new Date(`${b.date}T00:00`)),
    [appointments, tab]
  )

  async function updateStatus(appointmentId, status) {
    setUpdatingId(appointmentId)
    setError('')
    try {
      const result = await api.patch(`/appointments/${appointmentId}`, { status })
      setAppointments((prev) => prev.map((a) => a.id === appointmentId ? result.data : a))
    } catch (e) {
      setError(e.message)
    } finally {
      setUpdatingId(null)
    }
  }

  return (
    <StaffLayout>
      <div className="space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="font-serif text-2xl font-bold text-ink sm:text-3xl">My Appointments</h1>
            <p className="mt-1 max-w-xl text-sm text-slate-500">
              {currentStaff ? `Appointments scheduled with ${titleForProfession(currentStaff.profession)} ${currentStaff.name}.` : 'Your scheduled appointments.'}
            </p>
          </div>
        </div>

        {error && <div className="rounded-xl border border-rose-100 bg-rose-50 px-3 py-2 text-sm text-rose-600">{error}</div>}

        <div className="flex flex-wrap gap-2">
          {tabs.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`rounded-full px-4 py-1.5 text-sm font-semibold transition-colors ${
                tab === t ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-500'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        <Card>
          {loading && <p className="py-10 text-center text-sm text-slate-400">Loading appointments…</p>}

          {!loading && filtered.length === 0 && (
            <p className="rounded-xl border border-dashed border-slate-200 p-8 text-center text-sm text-slate-400">
              No {tab.toLowerCase()} appointments.
            </p>
          )}

          {!loading && filtered.length > 0 && (
            <div className="space-y-3">
              {filtered.map((a) => (
                <div key={a.id} className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-100 p-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <User size={14} className="text-brand-600" />
                      <p className="font-semibold text-ink">{a.patientName}</p>
                      <span className="text-xs text-slate-400">{a.patientId}</span>
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-slate-500">
                      <span className="flex items-center gap-1"><CalendarDays size={12} /> {formatDate(a.date)}</span>
                      <span className="flex items-center gap-1"><Clock size={12} /> {a.time}</span>
                      <span>{titleForProfession(a.staffProfession)} {a.staffName} · {a.staffProfession}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Badge tone={statusTone[a.status] || 'default'}>{a.status}</Badge>
                    {a.status === 'Upcoming' && (
                      <>
                        <button
                          disabled={updatingId === a.id}
                          onClick={() => updateStatus(a.id, 'Completed')}
                          className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                        >
                          Mark Completed
                        </button>
                        <button
                          disabled={updatingId === a.id}
                          onClick={() => updateStatus(a.id, 'Cancelled')}
                          className="rounded-lg border border-rose-200 px-3 py-1.5 text-xs font-semibold text-rose-600 hover:bg-rose-50"
                        >
                          Cancel
                        </button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </StaffLayout>
  )
}
