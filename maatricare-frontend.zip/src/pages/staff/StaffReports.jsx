import React, { useEffect, useMemo, useState } from 'react'
import { FileText, Upload, Send, CheckCircle2 } from 'lucide-react'
import StaffLayout from '../../layouts/StaffLayout.jsx'
import Card from '../../components/common/Card.jsx'
import Button from '../../components/common/Button.jsx'
import Badge from '../../components/common/Badge.jsx'
import { useAppData } from '../../context/AppDataContext.jsx'
import { formatDate } from '../../utils/pregnancy.js'

const REPORT_TYPES = ['Anomaly Scan', 'Growth Scan', 'Blood Test', 'Ultrasound', 'Lab Report', 'General Consultation']

export default function StaffReports() {
  const { patients, sendMedicalReport, fetchReportsForPatient } = useAppData()

  const [patientId, setPatientId] = useState('')
  const [title, setTitle] = useState('')
  const [reportType, setReportType] = useState(REPORT_TYPES[0])
  const [summary, setSummary] = useState('')
  const [status, setStatus] = useState('Normal')
  const [pdfFile, setPdfFile] = useState(null)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  const [recentReports, setRecentReports] = useState([])
  const [recentLoading, setRecentLoading] = useState(false)

  const sortedPatients = useMemo(() => [...patients].sort((a, b) => a.name.localeCompare(b.name)), [patients])

  // Whenever the selected patient changes, load the reports this staff
  // member (or the hospital) has already sent them, straight from MongoDB.
  useEffect(() => {
    if (!patientId) { setRecentReports([]); return }
    let active = true
    ;(async () => {
      setRecentLoading(true)
      try {
        const reports = await fetchReportsForPatient(patientId)
        if (active) setRecentReports(reports)
      } catch {
        if (active) setRecentReports([])
      } finally {
        if (active) setRecentLoading(false)
      }
    })()
    return () => { active = false }
  }, [patientId, fetchReportsForPatient])

  function handleFileChange(e) {
    const file = e.target.files?.[0]
    if (!file) { setPdfFile(null); return }
    if (file.type !== 'application/pdf') {
      setError('Please attach a PDF file.')
      e.target.value = ''
      setPdfFile(null)
      return
    }
    setError('')
    setPdfFile(file)
  }

  function resetForm() {
    setTitle('')
    setReportType(REPORT_TYPES[0])
    setSummary('')
    setStatus('Normal')
    setPdfFile(null)
    const input = document.getElementById('report-pdf-input')
    if (input) input.value = ''
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setSuccess('')
    if (!patientId) return setError('Please select a patient.')
    if (!title.trim()) return setError('Please enter a report title.')
    if (!summary.trim()) return setError('Please write a summary / key findings.')
    if (!pdfFile) return setError('Please attach a PDF report.')

    setSubmitting(true)
    try {
      const created = await sendMedicalReport({ patientId, title, reportType, summary, status, pdfFile })
      setSuccess(`Report "${created.title}" was sent successfully.`)
      setRecentReports((prev) => [created, ...prev])
      resetForm()
    } catch (err) {
      setError(err.message)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <StaffLayout>
      <div className="space-y-6">
        <div>
          <h1 className="font-serif text-2xl font-bold text-ink sm:text-3xl">Create Medical Report</h1>
          <p className="mt-1 max-w-xl text-sm text-slate-500">
            Send a summary and PDF report to a specific patient. It will appear immediately in their Medical Reports page.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            {error && <div className="mb-4 rounded-xl border border-rose-100 bg-rose-50 px-3 py-2 text-sm text-rose-600">{error}</div>}
            {success && (
              <div className="mb-4 flex items-center gap-2 rounded-xl border border-emerald-100 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">
                <CheckCircle2 size={16} /> {success}
              </div>
            )}

            <form className="space-y-4" onSubmit={handleSubmit}>
              <div>
                <label className="mb-1.5 block text-sm font-semibold text-ink">Patient</label>
                <select
                  value={patientId}
                  onChange={(e) => setPatientId(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm text-ink focus:border-brand-300 focus:outline-none"
                >
                  <option value="">Select Patient</option>
                  {sortedPatients.map((p) => (
                    <option key={p.id} value={p.id}>{p.name} — {p.id}</option>
                  ))}
                </select>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-1.5 block text-sm font-semibold text-ink">Report Type</label>
                  <select
                    value={reportType}
                    onChange={(e) => setReportType(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm text-ink focus:border-brand-300 focus:outline-none"
                  >
                    {REPORT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-semibold text-ink">Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm text-ink focus:border-brand-300 focus:outline-none"
                  >
                    <option value="Normal">Normal</option>
                    <option value="Requires Review">Requires Review</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="mb-1.5 block text-sm font-semibold text-ink">Report Title</label>
                <input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Anomaly Scan Report"
                  className="w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm text-ink placeholder:text-slate-400 focus:border-brand-300 focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1.5 block text-sm font-semibold text-ink">Summary / Key Findings</label>
                <textarea
                  value={summary}
                  onChange={(e) => setSummary(e.target.value)}
                  rows={5}
                  placeholder="e.g. Fetal anatomy appears structurally normal. Amniotic fluid is within the expected range for gestational age."
                  className="w-full resize-none rounded-xl border border-slate-200 px-3 py-2.5 text-sm text-ink placeholder:text-slate-400 focus:border-brand-300 focus:outline-none"
                />
                <p className="mt-1 text-xs text-slate-400">Tip: put each finding on its own line — it will appear as a separate item under Key Findings.</p>
              </div>

              <div>
                <label className="mb-1.5 block text-sm font-semibold text-ink">Attach PDF</label>
                <label
                  htmlFor="report-pdf-input"
                  className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-slate-300 px-4 py-6 text-sm text-slate-500 hover:border-brand-300 hover:bg-brand-50/50"
                >
                  <Upload size={16} />
                  {pdfFile ? pdfFile.name : 'Choose PDF'}
                </label>
                <input id="report-pdf-input" type="file" accept="application/pdf" className="hidden" onChange={handleFileChange} />
              </div>

              <div className="flex justify-end">
                <Button type="submit" icon={Send} iconPosition="left" disabled={submitting}>
                  {submitting ? 'Sending…' : 'Send Report'}
                </Button>
              </div>
            </form>
          </Card>

          <Card>
            <h3 className="mb-3 font-semibold text-ink">Reports Sent to Patient</h3>
            {!patientId && <p className="text-sm text-slate-400">Select a patient to view their report history.</p>}
            {patientId && recentLoading && <p className="text-sm text-slate-400">Loading…</p>}
            {patientId && !recentLoading && recentReports.length === 0 && (
              <p className="rounded-xl border border-dashed border-slate-200 p-4 text-center text-sm text-slate-400">
                No reports sent yet.
              </p>
            )}
            <div className="space-y-3">
              {recentReports.map((r) => (
                <div key={r.id} className="rounded-xl border border-slate-100 p-3">
                  <div className="flex items-center gap-2">
                    <FileText size={14} className="text-brand-600" />
                    <p className="text-sm font-semibold text-ink">{r.title}</p>
                  </div>
                  <div className="mt-1 flex items-center gap-2">
                    <Badge tone={r.status === 'Requires Review' ? 'alert' : 'success'}>{r.status}</Badge>
                    <span className="text-xs text-slate-400">{formatDate(r.createdAt)}</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </StaffLayout>
  )
}
