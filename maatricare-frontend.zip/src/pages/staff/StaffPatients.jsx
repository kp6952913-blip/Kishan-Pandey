import React, { useMemo, useState } from 'react'
import { Download, Plus, ChevronLeft, ChevronRight } from 'lucide-react'
import StaffLayout from '../../layouts/StaffLayout.jsx'
import Button from '../../components/common/Button.jsx'
import Card from '../../components/common/Card.jsx'
import PatientFilters from '../../components/staff/PatientFilters.jsx'
import PatientRow from '../../components/staff/PatientRow.jsx'
import NewPatientModal from '../../components/staff/NewPatientModal.jsx'
import { useAppData } from '../../context/AppDataContext.jsx'
import { initialsOf, formatDate } from '../../utils/pregnancy.js'

export default function StaffPatients() {
  const { patients, appointments } = useAppData()
  const [showNewPatient, setShowNewPatient] = useState(false)
  const [search, setSearch] = useState('')

  const rows = useMemo(() => {
    return patients
      .filter((p) => {
        if (!search.trim()) return true
        const q = search.toLowerCase()
        return p.name.toLowerCase().includes(q) || p.id.toLowerCase().includes(q) || (p.medicalConditions || '').toLowerCase().includes(q)
      })
      .map((p) => {
        const nextAppt = appointments
          .filter((a) => a.patientId === p.id)
          .sort((a, b) => new Date(a.date) - new Date(b.date))[0]
        return {
          initials: initialsOf(p.name),
          name: p.name,
          id: p.id,
          week: p.pregnancyWeek,
          risk: p.riskLevel,
          lastCheckup: formatDate(p.lastCheckup),
          lastNote: p.lastNote,
          nextAppt: nextAppt ? formatDate(nextAppt.date) : 'Not scheduled',
          nextApptTime: nextAppt ? nextAppt.time : '',
          status: p.status,
        }
      })
  }, [patients, appointments, search])

  return (
    <StaffLayout>
      <div className="space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="font-serif text-2xl font-bold text-ink sm:text-3xl">Patients</h1>
            <p className="mt-1 max-w-xl text-sm text-slate-500">
              Manage and monitor your patient load. Review critical statuses and upcoming appointments.
            </p>
          </div>
          <div className="flex gap-3">
            <Button variant="secondary" icon={Download} iconPosition="left">
              Export List
            </Button>
            <Button icon={Plus} iconPosition="left" onClick={() => setShowNewPatient(true)}>
              Add Patient
            </Button>
          </div>
        </div>

        <Card>
          <PatientFilters value={search} onChange={setSearch} />
        </Card>

        <Card padded={false} className="overflow-x-auto p-5 sm:p-6">
          <table className="w-full min-w-[720px] text-left">
            <thead>
              <tr className="border-b border-slate-100 text-xs font-semibold uppercase tracking-wide text-slate-400">
                <th className="py-2 pr-4">Patient Name</th>
                <th className="py-2 pr-4">Week</th>
                <th className="py-2 pr-4">Risk Level</th>
                <th className="py-2 pr-4">Last Checkup</th>
                <th className="py-2 pr-4">Next Appt</th>
                <th className="py-2 text-right">Status / Action</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((patient) => (
                <PatientRow key={patient.id} patient={patient} />
              ))}
            </tbody>
          </table>

          {rows.length === 0 && <p className="py-8 text-center text-sm text-slate-400">No patients match your search.</p>}

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-sm text-slate-500">
            <p>Showing {rows.length} of {patients.length} patients</p>
            <div className="flex items-center gap-2">
              <button className="rounded-lg border border-slate-200 p-1.5 text-slate-400">
                <ChevronLeft size={16} />
              </button>
              <button className="rounded-lg bg-brand-600 px-3 py-1.5 text-white">1</button>
              <button className="rounded-lg border border-slate-200 p-1.5 text-slate-400">
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        </Card>
      </div>

      <NewPatientModal open={showNewPatient} onClose={() => setShowNewPatient(false)} />
    </StaffLayout>
  )
}
