import React, { useRef } from 'react'
import { Edit3, MessageCircle, Upload, RotateCw } from 'lucide-react'
import PatientLayout from '../../layouts/PatientLayout.jsx'
import Card from '../../components/common/Card.jsx'
import Button from '../../components/common/Button.jsx'
import Badge from '../../components/common/Badge.jsx'
import VitalCard from '../../components/patient/VitalCard.jsx'
import TimelineItem from '../../components/patient/TimelineItem.jsx'
import { medicalTimeline, immunizations, prescriptions } from '../../data/mockData.js'
import { useAppData } from '../../context/AppDataContext.jsx'
import { initialsOf, formatDate, getTrimester, getTrimesterLabel } from '../../utils/pregnancy.js'

export default function PatientProfile() {
  const { currentPatient, addLabReport } = useAppData()
  const fileInputRef = useRef(null)

  if (!currentPatient) return null

  const p = currentPatient
  const week = p.pregnancyWeek || 1
  const trimester = getTrimester(week)
  const progressPct = Math.min(100, Math.round((week / 40) * 100))

  const vitals = [
    { label: 'Blood Pressure', value: p.vitals?.bloodPressure, unit: 'mmHg', status: 'From latest record', icon: 'HeartPulse' },
    { label: 'Weight', value: p.weight, unit: 'kg', status: 'Current', icon: 'Scale' },
    { label: 'Blood Sugar (F)', value: p.vitals?.bloodSugar, unit: 'mg/dL', status: 'From latest record', icon: 'Droplets' },
    { label: 'Hemoglobin', value: p.vitals?.hemoglobin, unit: 'g/dL', status: 'From latest record', icon: 'TestTube' },
    { label: 'BMI', value: p.bmi, unit: '', status: 'Healthy Range', icon: 'Gauge' },
    { label: 'Risk Level', value: p.riskLevel, unit: '', status: 'Care Pathway', icon: 'ShieldCheck' },
  ]

  function handleUploadClick() {
    fileInputRef.current?.click()
  }

  function handleFileChange(e) {
    const file = e.target.files?.[0]
    if (!file) return
    addLabReport(p.id, {
      name: file.name.replace(/\.[^/.]+$/, ''),
      date: new Date().toISOString().slice(0, 10),
      uploadedBy: p.name,
      fileName: file.name,
    })
    e.target.value = ''
  }

  return (
    <PatientLayout showSearch>
      <div className="space-y-6">
        <Card className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <span className="flex h-16 w-16 items-center justify-center rounded-full bg-brand-100 text-lg font-bold text-brand-700">
              {initialsOf(p.name)}
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-ink">{p.name}</h1>
                <Badge tone="default">Patient ID: {p.id}</Badge>
              </div>
              <p className="mt-1 text-sm text-slate-500">
                {p.age ? `${p.age} Years Old · ` : ''}{p.bloodGroup || '—'} · EDD: {formatDate(p.dueDate)}
              </p>
            </div>
          </div>
          <div className="flex gap-3">
            <Button variant="secondary" icon={Edit3} iconPosition="left" size="sm">
              Edit Profile
            </Button>
            <Button icon={MessageCircle} iconPosition="left" size="sm">
              Message
            </Button>
          </div>
        </Card>

        <Card>
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-sm font-semibold text-slate-500">Pregnancy Progress</p>
              <p className="mt-1 text-lg font-bold text-ink">Week {week} of 40 · {getTrimesterLabel(week)}</p>
            </div>
            <div className="flex gap-6 text-sm">
              <div>
                <p className="text-xs text-slate-400">Primary OB/GYN</p>
                <p className="font-semibold text-ink">{p.doctor || '—'}</p>
              </div>
              <div>
                <p className="text-xs text-slate-400">Care Midwife</p>
                <p className="font-semibold text-ink">{p.midwife || '—'}</p>
              </div>
            </div>
          </div>
          <div className="mt-4 h-2 w-full overflow-hidden rounded-full bg-slate-100">
            <div className="h-full rounded-full bg-brand-600" style={{ width: `${progressPct}%` }} />
          </div>
        </Card>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="space-y-6 lg:col-span-2">
            <Card>
              <div className="mb-4 flex items-center justify-between">
                <h3 className="font-semibold text-ink">Current Vitals</h3>
                <p className="text-xs text-slate-400">Last updated: {formatDate(p.lastCheckup)}</p>
              </div>
              <div className="grid gap-4 sm:grid-cols-3">
                {vitals.map((v) => (
                  <VitalCard key={v.label} {...v} />
                ))}
              </div>
            </Card>

            <Card>
              <div className="mb-4 flex items-center justify-between">
                <h3 className="font-semibold text-ink">Laboratory & Imaging</h3>
                <Button variant="secondary" size="sm" icon={Upload} iconPosition="left" onClick={handleUploadClick} type="button">
                  Upload Report
                </Button>
                <input ref={fileInputRef} type="file" className="hidden" onChange={handleFileChange} />
              </div>
              <p className="mb-2 text-sm font-semibold text-slate-500">Latest Reports</p>
              <div className="divide-y divide-slate-100">
                {(p.labReports || []).length === 0 && (
                  <p className="py-3 text-sm text-slate-400">No lab or imaging reports uploaded yet.</p>
                )}
                {(p.labReports || []).map((report, i) => (
                  <div key={i} className="flex items-center justify-between py-2 text-sm">
                    <span className="text-ink">{report.name}</span>
                    <span className="text-xs text-slate-400">
                      {formatDate(report.date)} · Sent by {report.uploadedBy}
                    </span>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-xs text-slate-400">
                Files are stored for this session only in this frontend demo — connect a backend to persist uploads permanently.
              </p>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <h3 className="mb-4 font-semibold text-ink">Medical Timeline</h3>
              <div className="space-y-6">
                {medicalTimeline.map((item, i) => (
                  <TimelineItem key={item.title} {...item} isLast={i === medicalTimeline.length - 1} />
                ))}
              </div>
            </Card>

            <Card>
              <h3 className="mb-3 font-semibold text-ink">Immunization</h3>
              <div className="space-y-3">
                {immunizations.map((item) => (
                  <div key={item.name} className="flex items-center justify-between text-sm">
                    <span className="font-medium text-ink">{item.name}</span>
                    <span className="text-xs text-slate-400">{item.status}</span>
                  </div>
                ))}
              </div>
            </Card>

            <Card>
              <h3 className="mb-3 font-semibold text-ink">Active Prescriptions</h3>
              <div className="space-y-4">
                {prescriptions.map((rx) => (
                  <div key={rx.name} className="rounded-xl bg-slate-50 p-3">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-semibold text-ink">{rx.name}</p>
                      <Badge tone="brand">{rx.freq}</Badge>
                    </div>
                    <p className="mt-1 text-xs text-slate-500">{rx.dosage}</p>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="text-xs text-slate-400">Refills: {rx.refills}</span>
                      <button className="flex items-center gap-1 text-xs font-semibold text-brand-600">
                        <RotateCw size={12} /> Request Refill
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </PatientLayout>
  )
}
