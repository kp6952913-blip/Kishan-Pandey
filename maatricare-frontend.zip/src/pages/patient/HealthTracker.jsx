import React, { useMemo, useState } from 'react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import { Play, Check } from 'lucide-react'
import PatientLayout from '../../layouts/PatientLayout.jsx'
import Card from '../../components/common/Card.jsx'
import Button from '../../components/common/Button.jsx'
import Badge from '../../components/common/Badge.jsx'
import DailyStatTile from '../../components/patient/DailyStatTile.jsx'
import { doctorNote } from '../../data/mockData.js'
import { useAppData } from '../../context/AppDataContext.jsx'
import { getWeekGroup } from '../../utils/pregnancy.js'

const SYMPTOM_OPTIONS = ['Nausea', 'Headache', 'Fatigue', 'Backache', 'Swelling', 'Dizziness', 'Abdominal Discomfort']
const MOODS = ['Great', 'Good', 'Okay', 'Low']

export default function HealthTracker() {
  const { currentPatient, addHealthLog, healthLogsForPatient } = useAppData()
  const week = currentPatient?.pregnancyWeek || 1
  const weekGroup = getWeekGroup(week)

  const logs = currentPatient ? healthLogsForPatient(currentPatient.id) : []
  const latest = logs[0]

  const [weight, setWeight] = useState('')
  const [bp, setBp] = useState('')
  const [heartRate, setHeartRate] = useState('')
  const [bloodSugar, setBloodSugar] = useState('')
  const [mood, setMood] = useState('Good')
  const [energyLevel, setEnergyLevel] = useState(7)
  const [sleepQuality, setSleepQuality] = useState('')
  const [symptoms, setSymptoms] = useState(currentPatient?.currentSymptoms || [])
  const [saved, setSaved] = useState(false)

  function toggleSymptom(s) {
    setSymptoms((prev) => (prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]))
  }

  function handleSave() {
    if (!currentPatient) return
    addHealthLog(currentPatient.id, {
      weight: weight || currentPatient.weight,
      bloodPressure: bp || currentPatient.vitals?.bloodPressure,
      heartRate: heartRate || currentPatient.vitals?.heartRate,
      bloodSugar: bloodSugar || currentPatient.vitals?.bloodSugar,
      mood,
      energyLevel,
      sleepQuality,
      symptoms,
    })
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const weightChart = useMemo(() => {
    const arr = [...logs].reverse().map((l, i) => ({
      week: new Date(l.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      lbs: Number(l.weight) || 0,
    }))
    return arr.length ? arr : [{ week: 'No data yet', lbs: 0 }]
  }, [logs])

  const bpChart = useMemo(() => {
    const arr = [...logs].reverse().map((l) => ({
      day: new Date(l.date).toLocaleDateString('en-US', { weekday: 'short' }),
      systolic: Number(String(l.bloodPressure || '0/0').split('/')[0]) || 0,
    }))
    return arr.length ? arr : [{ day: 'No data yet', systolic: 0 }]
  }, [logs])

  const displayWeight = latest?.weight || currentPatient?.weight
  const displayBP = latest?.bloodPressure || currentPatient?.vitals?.bloodPressure
  const displayHR = latest?.heartRate || currentPatient?.vitals?.heartRate
  const displayMood = latest?.mood || 'Good'

  return (
    <PatientLayout>
      <div className="space-y-6">
        <div>
          <h1 className="font-serif text-3xl font-bold text-ink">Health Tracker</h1>
          <p className="mt-2 max-w-2xl text-slate-500">
            Monitor your vital statistics, track daily symptoms, and log your baby's movements to
            ensure a healthy progression through Week {week}.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <h3 className="font-semibold text-ink">Daily Check-in</h3>
              <Badge tone="brand">Mood: {displayMood}</Badge>
            </div>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <DailyStatTile label="Current Weight" value={displayWeight ? `${displayWeight} kg` : '—'} />
              <DailyStatTile label="Blood Pressure" value={displayBP || '—'} />
              <DailyStatTile label="Heart Rate" value={displayHR ? `${displayHR} bpm` : '—'} />
              <DailyStatTile label="Baby Movements" value="Normal" />
            </div>

            <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <label className="block">
                <span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-400">Weight (kg)</span>
                <input value={weight} onChange={(e) => setWeight(e.target.value)} type="number" placeholder={String(currentPatient?.weight || '')} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-brand-400 focus:outline-none" />
              </label>
              <label className="block">
                <span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-400">Blood Pressure</span>
                <input value={bp} onChange={(e) => setBp(e.target.value)} placeholder={currentPatient?.vitals?.bloodPressure || '120/80'} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-brand-400 focus:outline-none" />
              </label>
              <label className="block">
                <span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-400">Heart Rate</span>
                <input value={heartRate} onChange={(e) => setHeartRate(e.target.value)} type="number" placeholder={String(currentPatient?.vitals?.heartRate || '')} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-brand-400 focus:outline-none" />
              </label>
              <label className="block">
                <span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-400">Blood Sugar</span>
                <input value={bloodSugar} onChange={(e) => setBloodSugar(e.target.value)} type="number" placeholder={String(currentPatient?.vitals?.bloodSugar || '')} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-brand-400 focus:outline-none" />
              </label>
            </div>

            <div className="mt-4 flex items-center justify-between rounded-xl bg-brand-50 p-4">
              <div>
                <p className="text-sm font-semibold text-ink">Baby Movements</p>
                <p className="text-xs text-slate-500">Start a kick counter session</p>
              </div>
              <Button size="sm" icon={Play} iconPosition="left" type="button">
                Log Kicks
              </Button>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-4">
              <div className="rounded-xl bg-slate-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Energy Level</p>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={energyLevel}
                  onChange={(e) => setEnergyLevel(Number(e.target.value))}
                  className="mt-2 w-full accent-brand-600"
                />
                <p className="mt-1 text-lg font-bold text-ink">{energyLevel} / 10</p>
              </div>
              <div className="rounded-xl bg-slate-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Sleep Quality</p>
                <input
                  value={sleepQuality}
                  onChange={(e) => setSleepQuality(e.target.value)}
                  placeholder="e.g. 6.5 hrs"
                  className="mt-2 w-full rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-sm focus:border-brand-400 focus:outline-none"
                />
              </div>
            </div>

            <div className="mt-4">
              <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-slate-400">Mood</p>
              <div className="flex flex-wrap gap-2">
                {MOODS.map((m) => (
                  <button
                    type="button"
                    key={m}
                    onClick={() => setMood(m)}
                    className={`rounded-full px-3 py-1.5 text-xs font-semibold ${mood === m ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-500'}`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-4">
              <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                Today's Symptoms
              </p>
              <div className="flex flex-wrap gap-2">
                {SYMPTOM_OPTIONS.map((s) => (
                  <label
                    key={s}
                    className={`flex cursor-pointer items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium ${
                      symptoms.includes(s) ? 'border-brand-300 bg-brand-50 text-brand-700' : 'border-slate-200 text-slate-500'
                    }`}
                  >
                    <input type="checkbox" className="hidden" checked={symptoms.includes(s)} onChange={() => toggleSymptom(s)} />
                    {s}
                  </label>
                ))}
              </div>
              <p className="mt-1 text-xs text-slate-400">Select any symptoms you're experiencing today — none is fine too.</p>
            </div>

            <Button className="mt-5 w-full" type="button" onClick={handleSave} icon={saved ? Check : undefined} iconPosition="left">
              {saved ? 'Log Updated' : 'Update Daily Log'}
            </Button>
          </Card>

          <Card>
            <p className="text-xs font-semibold uppercase tracking-wide text-brand-600">Care Team Note</p>
            <p className="mt-2 text-sm text-slate-600">"{doctorNote}"</p>
            <div className="mt-6 border-t border-slate-100 pt-4">
              <p className="text-sm font-semibold text-ink">Week {week} Insights</p>
              <p className="mt-1 text-sm text-slate-500">{weekGroup.babyDevelopment}</p>
            </div>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <h3 className="font-semibold text-ink">Weight Progression</h3>
            <p className="text-sm text-slate-400">Based on your logged daily check-ins</p>
            <div className="mt-4 h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weightChart} margin={{ left: -20, right: 10, top: 10 }}>
                  <CartesianGrid vertical={false} stroke="#eef1f8" />
                  <XAxis dataKey="week" tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                  <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                  <Tooltip />
                  <Line type="monotone" dataKey="lbs" stroke="#2f66f5" strokeWidth={2.5} dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card>
            <h3 className="font-semibold text-ink">BP Trends</h3>
            <p className="text-sm text-slate-400">Systolic reading, from your logged check-ins</p>
            <div className="mt-4 h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={bpChart} margin={{ left: -20, right: 10, top: 10 }}>
                  <CartesianGrid vertical={false} stroke="#eef1f8" />
                  <XAxis dataKey="day" tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                  <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                  <Tooltip />
                  <Line type="monotone" dataKey="systolic" stroke="#2fe0c0" strokeWidth={2.5} dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>
      </div>
    </PatientLayout>
  )
}
