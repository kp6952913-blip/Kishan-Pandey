import React, { useMemo, useState } from 'react'
import PatientLayout from '../../layouts/PatientLayout.jsx'
import DashboardHero from '../../components/patient/DashboardHero.jsx'
import GlanceCard from '../../components/patient/GlanceCard.jsx'
import QuickAccessTile from '../../components/patient/QuickAccessTile.jsx'
import WeekUpdateModal from '../../components/patient/WeekUpdateModal.jsx'
import { quickAccess } from '../../data/mockData.js'
import { useAppData } from '../../context/AppDataContext.jsx'
import { formatDate, daysUntil, getWeekGroup } from '../../utils/pregnancy.js'

export default function PatientHome() {
  const { currentPatient, appointmentsForPatient } = useAppData()
  const [showWeekUpdate, setShowWeekUpdate] = useState(false)

  const week = currentPatient?.pregnancyWeek || 1
  const weekGroup = getWeekGroup(week)

  const nextAppt = useMemo(() => {
    if (!currentPatient) return null
    return appointmentsForPatient(currentPatient.id)
      .filter((a) => new Date(a.date) >= new Date(new Date().toDateString()))
      .sort((a, b) => new Date(a.date) - new Date(b.date))[0]
  }, [currentPatient, appointmentsForPatient])

  const remaining = daysUntil(currentPatient?.dueDate)

  const atAGlance = [
    {
      label: 'Due Date',
      icon: 'CalendarHeart',
      value: `Estimated: ${formatDate(currentPatient?.dueDate)}`,
      sub: remaining !== null ? `${remaining} days` : '',
    },
    {
      label: 'Next Visit',
      icon: 'Stethoscope',
      value: nextAppt ? nextAppt.staffName : 'None scheduled',
      sub: nextAppt ? `${formatDate(nextAppt.date)} · ${nextAppt.time || ''}` : 'Book a visit to see it here',
      highlight: true,
    },
    {
      label: 'Weight Tracking',
      icon: 'Scale',
      value: currentPatient?.weight ? `${currentPatient.weight} kg` : '—',
      sub: 'Current recorded weight',
    },
    {
      label: 'Daily Tip',
      icon: 'Droplet',
      value: 'Stay Hydrated',
      sub: 'Aim for 8–12 cups of water today. Proper hydration helps fetal circulation.',
    },
  ]

  return (
    <PatientLayout>
      <div className="space-y-8">
        <DashboardHero
          coupleNames={currentPatient ? `${currentPatient.name}${currentPatient.partnerName ? ' & ' + currentPatient.partnerName : ''}` : 'Guest'}
          week={week}
          babySize={weekGroup.babySize}
          onReadUpdate={() => setShowWeekUpdate(true)}
        />

        <section>
          <h3 className="mb-4 font-semibold text-ink">At a Glance</h3>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {atAGlance.map((item) => (
              <GlanceCard key={item.label} {...item} />
            ))}
          </div>
        </section>

        <section>
          <h3 className="mb-4 font-semibold text-ink">Quick Access</h3>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {quickAccess.map((item) => (
              <QuickAccessTile key={item.label} {...item} />
            ))}
          </div>
        </section>
      </div>

      <WeekUpdateModal open={showWeekUpdate} onClose={() => setShowWeekUpdate(false)} week={week} />
    </PatientLayout>
  )
}
