import React, { useEffect, useMemo, useState } from 'react'
import { FileText, Search, Download, CheckCircle2, AlertTriangle } from 'lucide-react'
import PatientLayout from '../../layouts/PatientLayout.jsx'
import Card from '../../components/common/Card.jsx'
import Button from '../../components/common/Button.jsx'
import Badge from '../../components/common/Badge.jsx'
import { useAppData } from '../../context/AppDataContext.jsx'
import { formatDate } from '../../utils/pregnancy.js'

export default function MedicalReports() {
  const { medicalReports, fetchMedicalReports, downloadMedicalReport } = useAppData()
  const [search, setSearch] = useState('')
  const [selectedId, setSelectedId] = useState(null)
  const [loading, setLoading] = useState(true)
  const [downloading, setDownloading] = useState(false)
  const [error, setError] = useState('')

  // Always re-fetch from MongoDB on page load/refresh rather than trusting
  // whatever was already in context.
  useEffect(() => {
    let active = true
    ;(async () => {
      setLoading(true)
      try {
        await fetchMedicalReports()
      } catch (e) {
        if (active) setError(e.message)
      } finally {
        if (active) setLoading(false)
      }
    })()
    return () => { active = false }
  }, [fetchMedicalReports])

  const filtered = useMemo(() => {
    if (!search.trim()) return medicalReports
    const q = search.toLowerCase()
    return medicalReports.filter(
      (r) => r.title.toLowerCase().includes(q) || r.reportType.toLowerCase().includes(q) || formatDate(r.createdAt).toLowerCase().includes(q)
    )
  }, [medicalReports, search])

  const selected = useMemo(
    () => filtered.find((r) => r.id === selectedId) || filtered[0] || null,
    [filtered, selectedId]
  )

  async function handleDownload(report) {
    setDownloading(true)
    setError('')
    try {
      await downloadMedicalReport(report.id, `${report.title.replace(/\s+/g, '-')}.pdf`)
    } catch (e) {
      setError(e.message)
    } finally {
      setDownloading(false)
    }
  }

  const findings = selected ? selected.summary.split(/\n+/).map((s) => s.trim()).filter(Boolean) : []

  return (
    <PatientLayout showSearch>
      <div className="grid gap-6 lg:grid-cols-[360px_1fr]">
        <Card padded={false} className="overflow-hidden">
          <div className="flex items-center justify-between border-b border-slate-100 p-5">
            <h2 className="font-serif text-xl font-bold text-ink">Report History</h2>
          </div>
          <div className="p-4">
            <div className="relative">
              <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by test name or date…"
                className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 pl-9 pr-3 text-sm text-ink placeholder:text-slate-400 focus:border-brand-300 focus:outline-none"
              />
            </div>
          </div>

          <div className="max-h-[65vh] space-y-2 overflow-y-auto px-4 pb-4">
            {loading && <p className="p-4 text-center text-sm text-slate-400">Loading reports…</p>}

            {!loading && filtered.length === 0 && (
              <p className="rounded-xl border border-dashed border-slate-200 p-6 text-center text-sm text-slate-400">
                No medical reports available yet.
              </p>
            )}

            {!loading && filtered.map((report) => {
              const active = selected?.id === report.id
              return (
                <button
                  key={report.id}
                  type="button"
                  onClick={() => setSelectedId(report.id)}
                  className={`w-full rounded-2xl border p-4 text-left transition-colors ${
                    active ? 'border-brand-600 bg-brand-600 text-white shadow-soft' : 'border-slate-100 hover:bg-slate-50'
                  }`}
                >
                  <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${active ? 'bg-white/20' : 'bg-brand-50 text-brand-700'}`}>
                    <FileText size={16} className={active ? 'text-white' : ''} />
                  </div>
                  <p className={`mt-2 font-semibold ${active ? 'text-white' : 'text-ink'}`}>{report.title}</p>
                  <p className={`text-xs ${active ? 'text-white/80' : 'text-slate-400'}`}>{formatDate(report.createdAt)}</p>
                  <Badge tone={report.status === 'Requires Review' ? 'alert' : 'success'} className={active ? 'mt-2 bg-white/20 text-white' : 'mt-2'}>
                    {report.status === 'Requires Review' ? 'REQUIRES REVIEW' : 'NORMAL'}
                  </Badge>
                </button>
              )
            })}
          </div>
        </Card>

        <Card>
          {error && <div className="mb-4 rounded-xl border border-rose-100 bg-rose-50 px-3 py-2 text-sm text-rose-600">{error}</div>}

          {!selected && !loading && (
            <div className="flex h-full flex-col items-center justify-center gap-2 py-20 text-center text-slate-400">
              <FileText size={32} />
              <p className="text-sm">Select a report from history to view its details.</p>
            </div>
          )}

          {selected && (
            <>
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div className="mb-3 flex items-center gap-2">
                    <Badge tone="brand">{selected.reportType.toUpperCase()}</Badge>
                    <span className="text-xs text-slate-400">{formatDate(selected.createdAt)}</span>
                  </div>
                  <h1 className="font-serif text-2xl font-bold text-ink sm:text-3xl">{selected.title}</h1>
                  <p className="mt-2 max-w-xl text-sm text-slate-500">
                    Provided by {selected.staffName ? `${selected.staffName} · ${selected.staffProfession}` : 'your care team'}.
                  </p>
                </div>
                <Button icon={Download} iconPosition="left" onClick={() => handleDownload(selected)} disabled={!selected.hasPdf || downloading}>
                  {downloading ? 'Downloading…' : 'Download PDF'}
                </Button>
              </div>

              <div className="mt-6 border-t border-slate-100 pt-6">
                <h3 className="mb-3 flex items-center gap-2 font-semibold text-ink">
                  <span className="h-4 w-1 rounded-full bg-brand-600" /> Key Findings
                </h3>
                <div className="space-y-3">
                  {findings.map((line, i) => (
                    <div key={i} className="flex items-start gap-3 rounded-xl border border-slate-100 p-4">
                      {selected.status === 'Requires Review' ? (
                        <AlertTriangle size={18} className="mt-0.5 shrink-0 text-amber-500" />
                      ) : (
                        <CheckCircle2 size={18} className="mt-0.5 shrink-0 text-emerald-500" />
                      )}
                      <p className="text-sm text-slate-600">{line}</p>
                    </div>
                  ))}
                </div>
              </div>

              {!selected.hasPdf && (
                <p className="mt-6 text-xs text-slate-400">No PDF attachment was included with this report.</p>
              )}
            </>
          )}
        </Card>
      </div>
    </PatientLayout>
  )
}
