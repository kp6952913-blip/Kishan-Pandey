import React from 'react'
import { Siren, Phone, MapPin } from 'lucide-react'
import PatientLayout from '../../layouts/PatientLayout.jsx'
import Card from '../../components/common/Card.jsx'
import Badge from '../../components/common/Badge.jsx'
import EmergencyStep from '../../components/patient/EmergencyStep.jsx'
import { emergencyTimeline, criticalVitals, quickDial } from '../../data/mockData.js'

export default function SOSEmergency() {
  return (
    <PatientLayout>
      <div className="space-y-6">
        <Card className="border-rose-100 bg-rose-50">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-rose-600 text-white">
                <Siren size={22} />
              </span>
              <div>
                <p className="text-lg font-bold text-rose-700">Emergency Protocol Active</p>
                <p className="text-sm text-rose-600">3 Contacts notified · Help en route</p>
              </div>
            </div>
            <div className="rounded-xl bg-white px-4 py-2 text-center">
              <p className="text-xs text-slate-400">Elapsed</p>
              <p className="text-lg font-bold text-rose-600">00:04:26</p>
            </div>
          </div>
        </Card>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-semibold text-ink">Emergency Status Timeline</h3>
              <Badge tone="alert" dot>
                Ambulance En Route
              </Badge>
            </div>
            <div>
              {emergencyTimeline.map((step, i) => (
                <EmergencyStep key={step.title} {...step} isLast={i === emergencyTimeline.length - 1} />
              ))}
            </div>

            <div className="mt-4 rounded-xl bg-slate-900 p-4 text-white">
              <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-rose-300">
                <MapPin size={14} /> Broadcasting Live Location
              </p>
              <p className="mt-1 text-sm">142 Oakwood Drive, Sector 4</p>
              <p className="mt-1 text-xs text-slate-400">Ambulance is 4 minutes away</p>
            </div>
          </Card>

          <div className="space-y-6">
            <Card>
              <h3 className="font-semibold text-ink">Critical Vitals ID</h3>
              <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-xs text-slate-400">Week</p>
                  <p className="font-semibold text-ink">{criticalVitals.week}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400">Blood Group</p>
                  <p className="font-semibold text-ink">{criticalVitals.bloodGroup}</p>
                </div>
              </div>
              <div className="mt-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Allergies</p>
                <div className="mt-1 flex flex-wrap gap-2">
                  {criticalVitals.allergies.map((a) => (
                    <Badge key={a} tone="alert">
                      {a}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="mt-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                  Medical Conditions
                </p>
                <p className="mt-1 text-sm text-slate-600">{criticalVitals.conditions.join(', ')}</p>
              </div>
              <div className="mt-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                  Current Medicines
                </p>
                <p className="mt-1 text-sm text-slate-600">{criticalVitals.medicines.join(', ')}</p>
              </div>
            </Card>

            <Card>
              <h3 className="mb-3 font-semibold text-ink">Quick Dial</h3>
              <div className="space-y-3">
                {quickDial.map((contact) => (
                  <div key={contact.name} className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-semibold text-ink">{contact.name}</p>
                      <p className="text-xs text-slate-400">{contact.role}</p>
                    </div>
                    <button className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-600 text-white">
                      <Phone size={15} />
                    </button>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </PatientLayout>
  )
}
