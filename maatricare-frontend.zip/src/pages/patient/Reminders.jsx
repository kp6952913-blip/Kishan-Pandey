import React, { useMemo, useState } from 'react'
import PatientLayout from '../../layouts/PatientLayout.jsx'
import Card from '../../components/common/Card.jsx'
import Icon from '../../components/common/Icon.jsx'
import ReminderSummaryCard from '../../components/patient/ReminderSummaryCard.jsx'
import ScheduleItem from '../../components/patient/ScheduleItem.jsx'
import { quickAddActions } from '../../data/mockData.js'
import { useAppData } from '../../context/AppDataContext.jsx'

const tabs = ['Daily', 'Weekly', 'Monthly']
const quickAddIcons = ['Pill', 'GlassWater', 'Dumbbell', 'Apple', 'Plus', 'Bell']

export default function Reminders() {
  const [tab, setTab] = useState('Daily')
  const { currentPatient, remindersForPatient, toggleReminder } = useAppData()

  const todaysSchedule = currentPatient ? remindersForPatient(currentPatient.id) : []
  const completedCount = todaysSchedule.filter((r) => r.completed).length
  const pct = todaysSchedule.length ? Math.round((completedCount / todaysSchedule.length) * 100) : 0

  const reminderSummary = useMemo(
    () => [
      { label: 'Today', value: `${todaysSchedule.length} Tasks`, sub: `${completedCount} Completed · ${pct}%` },
      { label: 'Tomorrow', value: '3 Tasks', sub: 'Includes 1 Doctor Visit' },
      { label: 'This Week', value: '12 Tasks', sub: '4 Vaccinations pending' },
      { label: 'Completed', value: `${pct}%`, sub: pct >= 80 ? 'Great job this week!' : 'Keep going!' },
    ],
    [todaysSchedule, completedCount, pct]
  )

  return (
    <PatientLayout>
      <div className="space-y-6">
        <div>
          <h1 className="font-serif text-3xl font-bold text-ink">Reminder Center</h1>
          <p className="mt-2 text-slate-500">Manage your daily care routine and upcoming milestones.</p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {reminderSummary.map((item) => (
            <ReminderSummaryCard key={item.label} {...item} />
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-semibold text-ink">Today's Schedule</h3>
              <div className="flex rounded-lg bg-slate-100 p-1">
                {tabs.map((t) => (
                  <button
                    key={t}
                    onClick={() => setTab(t)}
                    className={`rounded-md px-3 py-1 text-xs font-semibold transition-colors ${
                      tab === t ? 'bg-white text-ink shadow-sm' : 'text-slate-500'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-3">
              {todaysSchedule.map((item) => (
                <ScheduleItem
                  key={item.id}
                  {...item}
                  onComplete={() => currentPatient && toggleReminder(currentPatient.id, item.id)}
                />
              ))}
              {todaysSchedule.length === 0 && (
                <p className="py-6 text-center text-sm text-slate-400">No reminders for today.</p>
              )}
            </div>
          </Card>

          <Card>
            <h3 className="mb-4 font-semibold text-ink">Quick Add</h3>
            <div className="grid grid-cols-2 gap-3">
              {quickAddActions.map((action, i) => (
                <button
                  key={action}
                  className="flex flex-col items-center gap-2 rounded-xl border border-slate-100 p-4 text-center hover:bg-slate-50"
                >
                  <Icon name={quickAddIcons[i]} size={20} className="text-brand-600" />
                  <span className="text-xs font-medium text-slate-600">{action}</span>
                </button>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </PatientLayout>
  )
}
