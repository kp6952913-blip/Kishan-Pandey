import React, { useMemo, useState } from 'react'
import { Video, RotateCw, MapPin } from 'lucide-react'
import PatientLayout from '../../layouts/PatientLayout.jsx'
import Card from '../../components/common/Card.jsx'
import Button from '../../components/common/Button.jsx'
import Badge from '../../components/common/Badge.jsx'
import AppointmentSummaryCard from '../../components/patient/AppointmentSummaryCard.jsx'
import BookVisitModal from '../../components/patient/BookVisitModal.jsx'
import { recentNotes } from '../../data/mockData.js'
import { useAppData } from '../../context/AppDataContext.jsx'
import { formatDate, titleForProfession } from '../../utils/pregnancy.js'

const tabs = ['Upcoming', 'Past', 'Cancelled']

export default function Appointments() {
  const [tab, setTab] = useState('Upcoming')
  const [showBooking, setShowBooking] = useState(false)
  const { currentPatient, appointmentsForPatient } = useAppData()

  const myAppointments = currentPatient ? appointmentsForPatient(currentPatient.id) : []
  const now = new Date(new Date().toDateString())

  const upcoming = useMemo(
    () => myAppointments.filter((a) => new Date(a.date) >= now).sort((a, b) => new Date(a.date) - new Date(b.date)),
    [myAppointments]
  )
  const past = useMemo(
    () => myAppointments.filter((a) => new Date(a.date) < now).sort((a, b) => new Date(b.date) - new Date(a.date)),
    [myAppointments]
  )

  const listForTab = tab === 'Upcoming' ? upcoming : tab === 'Past' ? past : []
  const nextAppointment = upcoming[0]

  const summary = [
    { label: 'Upcoming', value: String(upcoming.length), sub: nextAppointment ? `Next: ${formatDate(nextAppointment.date)}` : 'None scheduled' },
    { label: 'Past Visits', value: String(past.length), sub: 'Recorded in your history' },
    { label: 'Total Booked', value: String(myAppointments.length), sub: 'All time' },
    { label: 'Total Health Score', value: '94/100', sub: 'Excellent vitals trend' },
  ]

  return (
    <PatientLayout showSearch>
      <div className="space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="font-serif text-3xl font-bold text-ink">Appointments</h1>
            <p className="mt-2 max-w-xl text-slate-500">
              Manage your upcoming checkups, review past visits, and stay on top of your maternal
              health schedule.
            </p>
          </div>
          <Button onClick={() => setShowBooking(true)}>Book Visit</Button>
        </div>

        <div className="flex flex-wrap gap-2">
          {tabs.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`rounded-full px-4 py-1.5 text-sm font-semibold transition-colors ${
                tab === t ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-500'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {summary.map((item) => (
            <AppointmentSummaryCard key={item.label} {...item} />
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <h3 className="mb-3 font-semibold text-ink">{tab} Appointments</h3>
            <div className="space-y-3">
              {listForTab.length === 0 && (
                <p className="rounded-xl border border-dashed border-slate-200 p-6 text-center text-sm text-slate-400">
                  {tab === 'Cancelled' ? 'No cancelled appointments.' : `No ${tab.toLowerCase()} appointments yet.`}
                </p>
              )}
              {listForTab.map((a) => (
                <div key={a.id} className="rounded-xl border border-slate-100 p-4">
                  <div className="flex items-center gap-2">
                    <Badge tone={tab === 'Upcoming' ? 'brand' : 'success'}>{a.status}</Badge>
                    <span className="text-xs text-slate-400">• {formatDate(a.date)}</span>
                  </div>
                  <p className="mt-2 font-semibold text-ink">{titleForProfession(a.staffProfession)} {a.staffName}</p>
                  <p className="text-xs text-slate-400">{a.staffProfession} · {a.time}</p>
                </div>
              ))}
            </div>

            <div className="mt-6 border-t border-slate-100 pt-6">
              <h3 className="mb-3 font-semibold text-ink">Recent Medical Notes</h3>
              {recentNotes.map((note) => (
                <div key={note.title} className="rounded-xl border border-slate-100 p-4">
                  <div className="flex items-center gap-2">
                    <Badge tone="success">{note.status}</Badge>
                    <span className="text-xs text-slate-400">• {note.date}</span>
                  </div>
                  <p className="mt-2 font-semibold text-ink">{note.title}</p>
                  <p className="text-xs text-slate-400">{note.provider}</p>
                  <p className="mt-2 text-sm text-slate-500">{note.note}</p>
                  <button className="mt-2 text-xs font-semibold text-brand-600">{note.attachment}</button>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <h3 className="font-semibold text-ink">Next Appointment</h3>
            {nextAppointment ? (
              <>
                <p className="mt-3 font-semibold text-ink">{titleForProfession(nextAppointment.staffProfession)} {nextAppointment.staffName}</p>
                <p className="text-sm text-slate-500">{nextAppointment.staffProfession}</p>
                <p className="mt-1 text-sm font-medium text-brand-600">
                  {formatDate(nextAppointment.date)} · {nextAppointment.time}
                </p>

                <div className="mt-4 flex gap-2">
                  <Button size="sm" icon={Video} iconPosition="left" className="flex-1">
                    Join Video Call
                  </Button>
                  <Button size="sm" variant="secondary" icon={RotateCw} iconPosition="left">
                    Reschedule
                  </Button>
                </div>

                <div className="mt-5 rounded-xl bg-slate-50 p-3">
                  <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-slate-400">
                    <MapPin size={14} /> Location
                  </p>
                  <p className="mt-1 text-sm font-semibold text-ink">MaatriCare Women's Pavilion</p>
                  <p className="text-xs text-slate-500">1245 Medical Center Dr, Suite 300</p>
                </div>
              </>
            ) : (
              <p className="mt-3 text-sm text-slate-400">No upcoming appointments. Use "Book Visit" to schedule one.</p>
            )}
          </Card>
        </div>
      </div>

      {currentPatient && (
        <BookVisitModal open={showBooking} onClose={() => setShowBooking(false)} patient={currentPatient} />
      )}
    </PatientLayout>
  )
}
