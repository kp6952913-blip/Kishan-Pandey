import React, { useState } from 'react'
import { Search, Send } from 'lucide-react'
import PatientLayout from '../../layouts/PatientLayout.jsx'
import Card from '../../components/common/Card.jsx'
import Badge from '../../components/common/Badge.jsx'
import ConversationItem from '../../components/patient/ConversationItem.jsx'
import MessageBubble from '../../components/patient/MessageBubble.jsx'
import { careTeam, conversations, chatMessages } from '../../data/mockData.js'

export default function Messages() {
  const [draft, setDraft] = useState('')

  return (
    <PatientLayout>
      <div className="space-y-6">
        <div>
          <h1 className="font-serif text-3xl font-bold text-ink">Messages</h1>
          <p className="mt-2 text-slate-500">
            Conversations are end-to-end encrypted and stored securely in your medical record.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card padded={false} className="p-4 lg:col-span-1">
            <div className="relative mb-4">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search messages..."
                className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-sm focus:border-brand-400 focus:outline-none"
              />
            </div>

            <p className="mb-2 px-1 text-xs font-semibold uppercase tracking-wide text-slate-400">
              Care Team Online
            </p>
            <div className="mb-4 flex gap-4 overflow-x-auto px-1 pb-2">
              {careTeam.map((member) => (
                <div key={member.name} className="flex flex-col items-center gap-1 text-center">
                  <span className="relative flex h-10 w-10 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">
                    {member.name.split(' ').map((n) => n[0]).slice(0, 2).join('')}
                    {member.online && (
                      <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-white bg-emerald-500" />
                    )}
                  </span>
                  <span className="max-w-[64px] truncate text-[11px] text-slate-500">
                    {member.name.split(' ')[0]}
                  </span>
                </div>
              ))}
            </div>

            <div className="space-y-1">
              {conversations.map((c) => (
                <ConversationItem key={c.name} {...c} />
              ))}
            </div>
          </Card>

          <Card padded={false} className="flex flex-col lg:col-span-2">
            <div className="flex items-center justify-between border-b border-slate-100 p-4">
              <div>
                <p className="font-semibold text-ink">Dr. Sarah Evans</p>
                <Badge tone="success" dot>
                  Active Now
                </Badge>
              </div>
              <span className="text-xs text-slate-400">Today</span>
            </div>

            <div className="flex-1 space-y-4 overflow-y-auto p-4">
              {chatMessages.map((msg, i) => (
                <MessageBubble key={i} {...msg} />
              ))}
            </div>

            <div className="flex items-center gap-3 border-t border-slate-100 p-4">
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                type="text"
                placeholder="Type a message..."
                className="flex-1 rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-brand-400 focus:outline-none"
              />
              <button className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-600 text-white">
                <Send size={16} />
              </button>
            </div>
          </Card>
        </div>
      </div>
    </PatientLayout>
  )
}
