import React from 'react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import PatientLayout from '../../layouts/PatientLayout.jsx'
import Card from '../../components/common/Card.jsx'
import Badge from '../../components/common/Badge.jsx'
import TrimesterItem from '../../components/patient/TrimesterItem.jsx'
import { useAppData } from '../../context/AppDataContext.jsx'
import {
  getTrimester,
  getWeekGroup,
  estimateBabyGrowth,
  weightProgressionSeries,
} from '../../utils/pregnancy.js'

const TRIMESTER_META = [
  { num: 1, range: 'Weeks 1–13', title: 'First Trimester', note: 'Foundation & first heartbeat.' },
  { num: 2, range: 'Weeks 14–27', title: 'Second Trimester', note: 'Movement & hearing develop.' },
  { num: 3, range: 'Weeks 28–40', title: 'Third Trimester', note: 'Preparation for birth.' },
]

export default function GrowthJourney() {
  const { currentPatient } = useAppData()
  const week = currentPatient?.pregnancyWeek || 1
  const trimester = getTrimester(week)
  const weekGroup = getWeekGroup(week)
  const growth = estimateBabyGrowth(week)
  const progression = weightProgressionSeries(week)

  const trimesters = TRIMESTER_META.map((t) => ({ ...t, current: t.num === trimester }))

  return (
    <PatientLayout>
      <div className="space-y-8">
        <div>
          <Badge tone="teal" className="mb-3">
            Growth Journey
          </Badge>
          <h1 className="font-serif text-3xl font-bold text-ink">Watching You Grow Every Week</h1>
          <p className="mt-2 max-w-2xl text-slate-500">
            Track your baby's incredible development from the very first moments to the final
            preparations for birth. Every milestone is a celebration.
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-3">
          {trimesters.map((t) => (
            <TrimesterItem key={t.title} {...t} />
          ))}
        </div>

        <Card>
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-ink">The Active Trimester</h3>
            <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">{weekGroup.range} · Week {week}</span>
          </div>

          <div className="mt-6 grid gap-8 lg:grid-cols-2">
            <div>
              <p className="text-sm font-semibold text-slate-500">Baby's Size</p>
              <p className="mt-1 font-serif text-2xl font-bold text-ink">{weekGroup.babySize}</p>
              <div className="mt-3 flex gap-6 text-sm text-slate-600">
                <div>
                  <p className="text-lg font-bold text-brand-600">~{growth.lengthIn} in</p>
                  <p className="text-xs text-slate-400">Length</p>
                </div>
                <div>
                  <p className="text-lg font-bold text-brand-600">~{growth.weightLb} lbs</p>
                  <p className="text-xs text-slate-400">Weight</p>
                </div>
              </div>
              <p className="mt-4 text-sm text-slate-500">{weekGroup.babyDevelopment}</p>
            </div>

            <div>
              <p className="mb-3 text-sm font-semibold text-slate-500">Key Developments</p>
              <div className="space-y-3">
                {weekGroup.milestones.map((m) => (
                  <div key={m} className="rounded-xl bg-slate-50 p-3">
                    <p className="text-xs font-bold uppercase tracking-wide text-brand-600">Milestone</p>
                    <p className="mt-1 text-sm text-slate-600">{m}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-8 border-t border-slate-100 pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-ink">Weight Progression Estimate</p>
                <p className="text-sm text-slate-400">Typical growth curve through week {week}</p>
              </div>
              <p className="text-lg font-bold text-brand-600">{growth.weightLb} lbs</p>
            </div>
            <div className="mt-4 h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={progression} margin={{ left: -20, right: 10, top: 10 }}>
                  <CartesianGrid vertical={false} stroke="#eef1f8" />
                  <XAxis dataKey="week" tickLine={false} axisLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
                  <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
                  <Tooltip />
                  <Line type="monotone" dataKey="lbs" stroke="#2f66f5" strokeWidth={2.5} dot={{ r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </Card>
      </div>
    </PatientLayout>
  )
}
