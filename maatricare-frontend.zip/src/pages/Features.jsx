import React from "react";
import Navbar from "../components/landing/Navbar";
import FeaturesSection from "../components/landing/FeaturesSection";
import Footer from "../components/landing/Footer";

export default function Features() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main className="pt-8">
        <FeaturesSection />
      </main>
      <Footer />
    </div>
  );
}