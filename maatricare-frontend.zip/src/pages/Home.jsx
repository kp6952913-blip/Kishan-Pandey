import React from 'react'
import Navbar from '../components/landing/Navbar.jsx'
import Hero from '../components/landing/Hero.jsx'
import StatsBar from '../components/landing/StatsBar.jsx'
import FeaturesSection from '../components/landing/FeaturesSection.jsx'
import Footer from '../components/landing/Footer.jsx'

export default function Home() {
  return (
    <div className="min-h-screen bg-white flex flex-col justify-between">
      <Navbar />
      <main>
        <Hero />
        <StatsBar />
        <FeaturesSection />
      </main>
      <Footer />
    </div>
  )
}