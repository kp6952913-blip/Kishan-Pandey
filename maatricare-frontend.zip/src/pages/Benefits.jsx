import React from 'react'
import Navbar from '../components/landing/Navbar.jsx'
import BenefitsSection from '../components/landing/BenefitsSection.jsx'
import Footer from '../components/landing/Footer.jsx'

export default function Benefits() {
  return (
    <div className="min-h-screen bg-white flex flex-col justify-between">
      <Navbar />
      <main className="py-12">
        <BenefitsSection />
      </main>
      <Footer />
    </div>
  )
}