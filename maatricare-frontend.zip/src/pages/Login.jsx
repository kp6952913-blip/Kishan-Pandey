import React from 'react'
import MainLayout from '../layouts/MainLayout.jsx'
import AuthSidePanel from '../components/auth/AuthSidePanel.jsx'
import LoginForm from '../components/auth/LoginForm.jsx'

export default function Login() {
  return (
    <MainLayout>
      <section className="bg-gradient-to-br from-brand-50 via-white to-brand-50 py-12 sm:py-20">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 sm:px-6 lg:grid-cols-2 lg:items-center lg:px-8">
          <AuthSidePanel />
          <LoginForm />
        </div>
      </section>
    </MainLayout>
  )
}
