import pregnancyWeeks from '../data/pregnancyWeeks.json'

/** Weeks 1–13 → 1st, 14–27 → 2nd, 28–40 → 3rd */
export function getTrimester(week) {
  const w = Number(week) || 0
  if (w <= 13) return 1
  if (w <= 27) return 2
  return 3
}

export function getTrimesterLabel(week) {
  const t = getTrimester(week)
  return t === 1 ? 'First Trimester' : t === 2 ? 'Second Trimester' : 'Third Trimester'
}

/** Returns the pregnancyWeeks.json group that contains the given week. */
export function getWeekGroup(week) {
  const w = Math.min(40, Math.max(1, Number(week) || 1))
  return (
    pregnancyWeeks.find((g) => w >= g.startWeek && w <= g.endWeek) ||
    pregnancyWeeks[pregnancyWeeks.length - 1]
  )
}

/**
 * Estimate baby length/weight for an exact week by linearly interpolating
 * between the anchor values of each week-range group (each anchor represents
 * the group's end week).
 */
export function estimateBabyGrowth(week) {
  const w = Math.min(40, Math.max(1, Number(week) || 1))
  const anchors = [{ week: 0, lengthCm: 0, weightG: 0 }, ...pregnancyWeeks.map((g) => ({
    week: g.endWeek,
    lengthCm: g.babyLengthCm,
    weightG: g.babyWeightG,
  }))]

  let lower = anchors[0]
  let upper = anchors[anchors.length - 1]
  for (let i = 0; i < anchors.length - 1; i++) {
    if (w >= anchors[i].week && w <= anchors[i + 1].week) {
      lower = anchors[i]
      upper = anchors[i + 1]
      break
    }
  }

  const span = upper.week - lower.week || 1
  const ratio = (w - lower.week) / span
  const lengthCm = lower.lengthCm + (upper.lengthCm - lower.lengthCm) * ratio
  const weightG = lower.weightG + (upper.weightG - lower.weightG) * ratio

  return {
    week: w,
    lengthCm: Math.round(lengthCm * 10) / 10,
    weightG: Math.round(weightG),
    lengthIn: Math.round((lengthCm / 2.54) * 10) / 10,
    weightLb: Math.round((weightG / 453.6) * 100) / 100,
  }
}

/** Weight progression series (one point per completed week-group anchor, up to current week). */
export function weightProgressionSeries(week) {
  const w = Math.min(40, Math.max(1, Number(week) || 1))
  return pregnancyWeeks
    .filter((g) => g.startWeek <= w)
    .map((g) => {
      const capWeek = Math.min(g.endWeek, w)
      const est = estimateBabyGrowth(capWeek)
      return { week: `Wk ${capWeek}`, lbs: est.weightLb }
    })
}

export function calculateBMI(weightKg, heightCm) {
  const h = Number(heightCm) / 100
  if (!h || !weightKg) return null
  return Math.round((Number(weightKg) / (h * h)) * 10) / 10
}

export function calculateDueDateFromWeek(week) {
  const w = Number(week) || 0
  const daysRemaining = (40 - w) * 7
  const due = new Date()
  due.setDate(due.getDate() + daysRemaining)
  return due.toISOString().slice(0, 10)
}

export function formatDate(dateStr) {
  if (!dateStr) return '—'
  const d = new Date(dateStr)
  if (isNaN(d)) return dateStr
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
}

export function daysUntil(dateStr) {
  if (!dateStr) return null
  const target = new Date(dateStr)
  const now = new Date()
  const diff = Math.ceil((target - now) / (1000 * 60 * 60 * 24))
  return diff
}

/** e.g. "Elena Jimenez" -> "EJ" */
export function initialsOf(name = '') {
  return name
    .split(' ')
    .filter(Boolean)
    .map((n) => n[0])
    .join('')
    .slice(0, 2)
    .toUpperCase()
}

/** Maps a staff profession to the honorific used in "Welcome, {title} {name}" */
export function titleForProfession(profession = '') {
  const p = profession.toLowerCase()
  if (p.includes('obstetrician') || p.includes('doctor') || p === 'ob/gyn') return 'Dr.'
  if (p.includes('midwife')) return 'Midwife'
  if (p.includes('nurse')) return 'Nurse'
  return profession
}
