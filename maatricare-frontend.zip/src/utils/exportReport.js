/**
 * Generates the hospital's Daily Report as a print-ready document and opens the
 * browser print dialog (users can choose "Save as PDF" as the destination).
 * This avoids requiring a bundled PDF-generation dependency while still producing
 * a real, downloadable PDF from live application data.
 */
export function exportDailyReportPDF({ staffName, stats, highRisk, recentRegistrations, todaysAppointments }) {
  const today = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })

  const win = window.open('', '_blank', 'width=800,height=1000')
  if (!win) {
    alert('Please allow pop-ups to export the daily report as a PDF.')
    return
  }

  const rows = (items, cols) =>
    items
      .map(
        (item) =>
          `<tr>${cols.map((c) => `<td style="padding:6px 10px;border-bottom:1px solid #eee;">${item[c] ?? '—'}</td>`).join('')}</tr>`
      )
      .join('')

  win.document.write(`
    <html>
      <head>
        <title>MaatriCare Daily Report — ${today}</title>
        <style>
          body { font-family: Arial, Helvetica, sans-serif; color: #0b1330; padding: 32px; }
          h1 { font-size: 22px; margin-bottom: 4px; }
          h2 { font-size: 15px; margin-top: 28px; margin-bottom: 8px; color: #1a4be0; }
          p.sub { color: #64748b; margin-top: 0; }
          table { width: 100%; border-collapse: collapse; font-size: 13px; }
          th { text-align: left; padding: 6px 10px; background: #eef4ff; color: #1a4be0; font-size: 11px; text-transform: uppercase; }
          .kpi-grid { display: flex; gap: 16px; flex-wrap: wrap; margin-top: 12px; }
          .kpi { border: 1px solid #eee; border-radius: 10px; padding: 12px 16px; min-width: 140px; }
          .kpi .label { font-size: 11px; text-transform: uppercase; color: #94a3b8; }
          .kpi .value { font-size: 20px; font-weight: bold; }
          footer { margin-top: 40px; font-size: 11px; color: #94a3b8; }
        </style>
      </head>
      <body>
        <h1>MaatriCare — Hospital Daily Report</h1>
        <p class="sub">${today} · Prepared by ${staffName}</p>

        <div class="kpi-grid">
          ${stats.map((s) => `<div class="kpi"><div class="label">${s.label}</div><div class="value">${s.value}</div></div>`).join('')}
        </div>

        <h2>Today's Appointments (${todaysAppointments.length})</h2>
        <table>
          <thead><tr><th>Patient</th><th>Staff</th><th>Time</th></tr></thead>
          <tbody>${rows(todaysAppointments.map((a) => ({ patient: a.patientName, staff: a.staffName, time: a.time })), ['patient', 'staff', 'time']) || '<tr><td style="padding:8px;color:#94a3b8">No appointments scheduled today.</td></tr>'}</tbody>
        </table>

        <h2>High-Risk Patients (${highRisk.length})</h2>
        <table>
          <thead><tr><th>Name</th><th>ID</th><th>Week</th><th>Blood Pressure</th></tr></thead>
          <tbody>${rows(highRisk.map((p) => ({ name: p.name, id: p.id, week: p.pregnancyWeek, bp: p.vitals?.bloodPressure })), ['name', 'id', 'week', 'bp']) || '<tr><td style="padding:8px;color:#94a3b8">No high-risk patients today.</td></tr>'}</tbody>
        </table>

        <h2>Recent Registrations</h2>
        <table>
          <thead><tr><th>Name</th><th>ID</th><th>Week</th><th>Registered</th></tr></thead>
          <tbody>${rows(recentRegistrations.map((p) => ({ name: p.name, id: p.id, week: p.pregnancyWeek, registered: new Date(p.createdAt).toLocaleDateString() })), ['name', 'id', 'week', 'registered'])}</tbody>
        </table>

        <footer>Generated automatically by MaatriCare on ${new Date().toLocaleString()}. For internal hospital use only.</footer>
      </body>
    </html>
  `)
  win.document.close()
  win.focus()
  setTimeout(() => {
    win.print()
  }, 350)
}
