import React, { createContext, useContext, useEffect, useMemo, useState, useCallback } from 'react'
import { api } from '../api/apiClient.js'
import { calculateBMI } from '../utils/pregnancy.js'
import {
  createMedicalReport as apiCreateMedicalReport,
  fetchMyMedicalReports,
  fetchPatientMedicalReports,
  downloadMedicalReportPdf as apiDownloadMedicalReportPdf,
} from '../api/medicalReports.js'

const AppDataContext = createContext(null)

const defaultReminders = (patientId) => [
  { id: `${patientId}-r1`, time: '08:00 AM', type: 'Medicine', title: 'Prenatal Vitamins', detail: 'Take with food. Dosage: 1 Tablet.', completed: false },
  { id: `${patientId}-r2`, time: '09:00 AM', type: 'Hydration', title: 'Morning Hydration', detail: 'Drink 500ml of water.', completed: false },
  { id: `${patientId}-r3`, time: '02:30 PM', type: 'Appointment', title: 'Ultrasound Scan', detail: 'Remember to bring previous reports.', completed: false },
]

export function AppDataProvider({ children }) {
  const [staff, setStaff] = useState([])
  const [patients, setPatients] = useState([])
  const [appointments, setAppointments] = useState([])
  const [medicalReports, setMedicalReports] = useState([])
  const [healthLogs, setHealthLogs] = useState({})
  const [reminders, setReminders] = useState({})
  const [currentStaff, setCurrentStaff] = useState(null)
  const [currentPatient, setCurrentPatient] = useState(null)
  const [authLoading, setAuthLoading] = useState(true)
  const [dataLoading, setDataLoading] = useState(false)

  const refreshData = useCallback(async (role) => {
    setDataLoading(true)
    try {
      const staffResult = await api.get('/staff')
      setStaff(staffResult.data || [])

      if (role === 'staff') {
        const [patientsResult, apptResult] = await Promise.all([
          api.get('/patients'),
          api.get('/appointments/my'),
        ])
        setPatients(patientsResult.data || [])
        setAppointments(apptResult.data || [])
      } else if (role === 'patient') {
        const [patientResult, apptResult, logsResult, reminderResult, reportsResult] = await Promise.all([
          api.get('/patients/me'),
          api.get('/appointments/my'),
          api.get('/health-logs/me'),
          api.get('/reminders/my'),
          fetchMyMedicalReports(),
        ])
        setCurrentPatient(patientResult.data)
        setPatients(patientResult.data ? [patientResult.data] : [])
        setAppointments(apptResult.data || [])
        setHealthLogs({ [patientResult.data.id]: logsResult.data || [] })
        setReminders({ [patientResult.data.id]: reminderResult.data || defaultReminders(patientResult.data.id) })
        setMedicalReports(reportsResult.data || [])
      }
    } finally {
      setDataLoading(false)
    }
  }, [])

  useEffect(() => {
    let active = true
    ;(async () => {
      try {
        const result = await api.get('/auth/me')
        if (!active) return
        const { user, role } = result.data
        if (role === 'staff') setCurrentStaff(user)
        if (role === 'patient') setCurrentPatient(user)
        await refreshData(role)
      } catch {
        if (active) {
          setCurrentStaff(null)
          setCurrentPatient(null)
        }
      } finally {
        if (active) setAuthLoading(false)
      }
    })()
    return () => { active = false }
  }, [refreshData])

  const staffLogin = useCallback(async (email, password) => {
    try {
      const result = await api.post('/auth/staff/login', { email, password })
      setCurrentStaff(result.data.user)
      setCurrentPatient(null)
      await refreshData('staff')
      return { ok: true, staff: result.data.user }
    } catch (error) {
      return { ok: false, error: error.message }
    }
  }, [refreshData])

  const patientLogin = useCallback(async (email, password) => {
    try {
      const result = await api.post('/auth/patient/login', { email, password })
      setCurrentPatient(result.data.user)
      setCurrentStaff(null)
      await refreshData('patient')
      return { ok: true, patient: result.data.user }
    } catch (error) {
      return { ok: false, error: error.message }
    }
  }, [refreshData])

  const logout = useCallback(async () => {
    try { await api.post('/auth/logout', {}) } catch { /* already logged out */ }
    setCurrentStaff(null)
    setCurrentPatient(null)
    setPatients([])
    setAppointments([])
    setHealthLogs({})
    setReminders({})
  }, [])

  const registerPatient = useCallback(async (form) => {
    try {
      const bmi = form.bmi || calculateBMI(form.weight, form.height) || ''
      const result = await api.post('/patients', { ...form, bmi })
      setPatients((prev) => [result.data, ...prev])
      return { ok: true, patient: result.data }
    } catch (error) {
      return { ok: false, error: error.message }
    }
  }, [])

  const updatePatient = useCallback(async (patientId, updates) => {
    try {
      const result = await api.patch(`/patients/${patientId}`, updates)
      setPatients((prev) => prev.map((p) => p.id === patientId ? result.data : p))
      if (currentPatient?.id === patientId) setCurrentPatient(result.data)
      return result.data
    } catch (error) {
      throw error
    }
  }, [currentPatient])

  const addLabReport = useCallback(async (patientId, report) => {
    const result = await api.post(`/patients/${patientId}/lab-reports`, report)
    setPatients((prev) => prev.map((p) => p.id === patientId ? result.data : p))
    if (currentPatient?.id === patientId) setCurrentPatient(result.data)
    return result.data
  }, [currentPatient])

  const bookAppointment = useCallback(async (appointment) => {
    try {
      const result = await api.post('/appointments', appointment)
      setAppointments((prev) => [result.data, ...prev])
      return result.data
    } catch (error) {
      throw error
    }
  }, [])

  // Re-fetches the logged-in patient's medical reports from MongoDB (used on
  // page load/refresh rather than relying on previously loaded state).
  const fetchMedicalReports = useCallback(async () => {
    const result = await fetchMyMedicalReports()
    setMedicalReports(result.data || [])
    return result.data || []
  }, [])

  // Staff: fetch the report history already sent to a specific patient.
  const fetchReportsForPatient = useCallback(async (patientId) => {
    const result = await fetchPatientMedicalReports(patientId)
    return result.data || []
  }, [])

  // Staff: create + send a new medical report (message + PDF) to a patient.
  const sendMedicalReport = useCallback(async (input) => {
    const result = await apiCreateMedicalReport(input)
    return result.data
  }, [])

  const downloadMedicalReport = useCallback(async (reportId, fileName) => {
    await apiDownloadMedicalReportPdf(reportId, fileName)
  }, [])

  const appointmentsForPatient = useCallback(
    (patientId) => appointments.filter((a) => a.patientId === patientId),
    [appointments]
  )

  const appointmentsForStaff = useCallback(
    (staffId) => appointments.filter((a) => a.staffId === staffId),
    [appointments]
  )

  const addHealthLog = useCallback(async (patientId, log) => {
    const result = await api.post(`/health-logs/${patientId}`, log)
    setHealthLogs((prev) => ({ ...prev, [patientId]: [result.data, ...(prev[patientId] || [])] }))
    if (result.patient) {
      setCurrentPatient(result.patient)
      setPatients((prev) => prev.map((p) => p.id === patientId ? result.patient : p))
    }
    return result.data
  }, [])

  const healthLogsForPatient = useCallback((patientId) => healthLogs[patientId] || [], [healthLogs])

  const remindersForPatient = useCallback(
    (patientId) => reminders[patientId] || defaultReminders(patientId),
    [reminders]
  )

  const toggleReminder = useCallback(async (patientId, reminderId) => {
    const current = reminders[patientId] || defaultReminders(patientId)
    const item = current.find((r) => r.id === reminderId)
    if (!item) return
    const result = await api.patch(`/reminders/${reminderId}`, { completed: !item.completed })
    setReminders((prev) => ({ ...prev, [patientId]: current.map((r) => r.id === reminderId ? result.data : r) }))
  }, [reminders])

  const registrationTrend = useMemo(() => {
    const now = new Date()
    const months = []
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
      months.push({ key: `${d.getFullYear()}-${d.getMonth()}`, month: d.toLocaleString('en-US', { month: 'short' }) })
    }
    const counts = Object.fromEntries(months.map((m) => [m.key, 0]))
    patients.forEach((p) => {
      const d = new Date(p.createdAt)
      const key = `${d.getFullYear()}-${d.getMonth()}`
      if (key in counts) counts[key] += 1
    })
    return months.map((m) => ({ month: m.month, patients: counts[m.key] }))
  }, [patients])

  const highRiskPatients = useMemo(() => patients.filter((p) => p.riskLevel === 'High Risk' || p.risk === 'High Risk'), [patients])
  const todaysAppointments = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10)
    return appointments.filter((a) => a.date === today && a.status !== 'Cancelled')
  }, [appointments])

  const value = {
    staff, patients, appointments, medicalReports, currentStaff, currentPatient,
    isStaffAuthed: !!currentStaff, isPatientAuthed: !!currentPatient,
    authLoading, dataLoading,
    staffLogin, patientLogin, logout,
    registerPatient, updatePatient, addLabReport,
    bookAppointment, appointmentsForPatient, appointmentsForStaff,
    fetchMedicalReports, fetchReportsForPatient, sendMedicalReport, downloadMedicalReport,
    addHealthLog, healthLogsForPatient,
    remindersForPatient, toggleReminder,
    registrationTrend, highRiskPatients, todaysAppointments,
  }

  return <AppDataContext.Provider value={value}>{children}</AppDataContext.Provider>
}

export function useAppData() {
  const ctx = useContext(AppDataContext)
  if (!ctx) throw new Error('useAppData must be used within AppDataProvider')
  return ctx
}
