import React from 'react'
import * as Icons from 'lucide-react'

/**
 * Renders a lucide-react icon by its string name, e.g. <Icon name="Activity" />.
 * Keeps mock data (data/mockData.js) free of JSX/component imports.
 */
export default function Icon({ name, size = 20, className = '', strokeWidth = 2 }) {
  const LucideIcon = Icons[name]
  if (!LucideIcon) return null
  return <LucideIcon size={size} className={className} strokeWidth={strokeWidth} />
}
