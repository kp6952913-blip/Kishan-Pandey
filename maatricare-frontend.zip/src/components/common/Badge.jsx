import React from 'react'

const tones = {
  default: 'bg-slate-100 text-slate-600',
  brand: 'bg-brand-50 text-brand-700',
  success: 'bg-emerald-50 text-emerald-600',
  alert: 'bg-rose-50 text-rose-600',
  warning: 'bg-amber-50 text-amber-700',
  teal: 'bg-care-teal/15 text-care-tealDark',
}

export default function Badge({ children, tone = 'default', dot = false, className = '' }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ${tones[tone]} ${className}`}
    >
      {dot && <span className="h-1.5 w-1.5 rounded-full bg-current" />}
      {children}
    </span>
  )
}
