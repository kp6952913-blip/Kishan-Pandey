import React from 'react'

export default function SectionTitle({ eyebrow, title, description, align = 'center' }) {
  const alignment = align === 'center' ? 'text-center mx-auto' : 'text-left'
  return (
    <div className={`max-w-2xl ${alignment} mb-12`}>
      {eyebrow && (
        <p className="mb-3 text-sm font-semibold uppercase tracking-wide text-brand-600">{eyebrow}</p>
      )}
      <h2 className="font-serif text-3xl sm:text-4xl font-bold text-ink">{title}</h2>
      {description && <p className="mt-4 text-slate-500">{description}</p>}
    </div>
  )
}
