import React from 'react'

export default function Card({ children, className = '', padded = true, ...props }) {
  return (
    <div
      className={`rounded-2xl border border-slate-100 bg-white shadow-soft ${padded ? 'p-5 sm:p-6' : ''} ${className}`}
      {...props}
    >
      {children}
    </div>
  )
}
