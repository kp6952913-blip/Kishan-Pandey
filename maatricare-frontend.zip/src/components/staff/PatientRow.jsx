import React from 'react'
import Badge from '../common/Badge.jsx'

const riskTone = {
  'High Risk': 'alert',
  Routine: 'brand',
  Monitor: 'teal',
}

const statusColor = {
  ADMITTED: 'text-emerald-600',
  STABLE: 'text-slate-500',
  DISCHARGED: 'text-brand-600',
}

export default function PatientRow({ patient }) {
  const { initials, name, id, week, risk, lastCheckup, lastNote, nextAppt, nextApptTime, status } = patient
  return (
    <tr className="border-b border-slate-100 text-sm last:border-0">
      <td className="py-4 pr-4">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-brand-100 text-sm font-semibold text-brand-700">
            {initials}
          </span>
          <div>
            <p className="font-semibold text-ink">{name}</p>
            <p className="text-xs text-slate-400">ID: {id}</p>
          </div>
        </div>
      </td>
      <td className="py-4 pr-4 text-slate-600">{week}</td>
      <td className="py-4 pr-4">
        <Badge tone={riskTone[risk] || 'default'} dot>
          {risk}
        </Badge>
      </td>
      <td className="py-4 pr-4 text-slate-600">
        <p>{lastCheckup}</p>
        <p className="text-xs text-slate-400">{lastNote}</p>
      </td>
      <td className="py-4 pr-4 text-slate-600">
        <p className="font-medium text-ink">{nextAppt}</p>
        <p className="text-xs text-slate-400">{nextApptTime}</p>
      </td>
      <td className={`py-4 text-right text-xs font-bold uppercase tracking-wide ${statusColor[status]}`}>
        {status}
      </td>
    </tr>
  )
}
