import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { LogOut } from 'lucide-react'
import Icon from '../common/Icon.jsx'
import { staffNav } from '../../data/mockData.js'
import { useAppData } from '../../context/AppDataContext.jsx'
import logo from '../../assets/logo.png'

export default function StaffSidebar() {
  const { logout } = useAppData()
  const navigate = useNavigate()

  function handleLogout() {
    logout()
    navigate('/login', { state: { portal: 'hospital' } })
  }

  return (
    <aside className="hidden w-64 shrink-0 flex-col border-r border-slate-100 bg-white lg:flex">
      <div className="flex items-center gap-2 px-6 py-6">
        <img src={logo} alt="MaatriCare" className="h-8 w-8 object-contain" />
        <span className="text-base font-bold text-brand-700">MaatriCare Staff</span>
      </div>

      <nav className="flex-1 space-y-1 px-3">
        {staffNav.map((item) => (
          <NavLink
            key={item.label}
            to={item.to}
            end={item.to === '/staff'}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-brand-600 text-white'
                  : item.danger
                  ? 'text-rose-600 hover:bg-rose-50'
                  : 'text-slate-600 hover:bg-slate-50'
              }`
            }
          >
            <Icon name={item.icon} size={18} />
            {item.label}
          </NavLink>
        ))}
      </nav>

      <div className="border-t border-slate-100 px-3 py-4">
        <button
          onClick={handleLogout}
          className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-600 hover:bg-rose-50 hover:text-rose-600"
        >
          <LogOut size={18} />
          Log Out
        </button>
      </div>
    </aside>
  )
}
