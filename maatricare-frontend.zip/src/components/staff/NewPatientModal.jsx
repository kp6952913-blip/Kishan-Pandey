import React, { useState } from 'react'
import Modal from '../common/Modal.jsx'
import Button from '../common/Button.jsx'
import { useAppData } from '../../context/AppDataContext.jsx'
import { calculateBMI, calculateDueDateFromWeek } from '../../utils/pregnancy.js'

const SYMPTOM_OPTIONS = ['Nausea', 'Headache', 'Fatigue', 'Backache', 'Swelling', 'Dizziness', 'Abdominal Discomfort']

const emptyForm = {
  name: '', email: '', password: '', confirmPassword: '',
  age: '', dob: '', phone: '', address: '', bloodGroup: '', height: '', weight: '',
  pregnancyWeek: '', dueDate: '', previousPregnancies: '', previousBirths: '',
  previousComplications: '', medicalConditions: '', allergies: '', medications: '',
  partnerName: '', partnerPhone: '', partnerEmail: '', emergencyContact: '',
  riskLevel: 'Routine', currentSymptoms: [],
  doctor: '', midwife: '', nurse: '',
  bloodPressure: '', hemoglobin: '', bloodSugar: '', heartRate: '',
  babyName: '', babyWeight: '', babyHeight: '',
}

function Field({ label, children, required }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
        {label} {required && <span className="text-rose-500">*</span>}
      </span>
      {children}
    </label>
  )
}

const inputCls =
  'w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-brand-400 focus:outline-none'

export default function NewPatientModal({ open, onClose }) {
  const { registerPatient, staff } = useAppData()
  const [form, setForm] = useState(emptyForm)
  const [errors, setErrors] = useState({})
  const [success, setSuccess] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  const doctors = staff.filter((s) => s.profession === 'Obstetrician')
  const midwives = staff.filter((s) => s.profession === 'Midwife')
  const nurses = staff.filter((s) => s.profession === 'Nurse')

  function set(key, value) {
    setForm((f) => ({ ...f, [key]: value }))
  }

  function toggleSymptom(symptom) {
    setForm((f) => ({
      ...f,
      currentSymptoms: f.currentSymptoms.includes(symptom)
        ? f.currentSymptoms.filter((s) => s !== symptom)
        : [...f.currentSymptoms, symptom],
    }))
  }

  function validate() {
    const e = {}
    if (!form.name.trim()) e.name = 'Full name is required.'
    if (!/^\S+@\S+\.\S+$/.test(form.email)) e.email = 'Enter a valid email address.'
    if (form.password.length < 6) e.password = 'Password must be at least 6 characters.'
    if (form.password !== form.confirmPassword) e.confirmPassword = 'Passwords do not match.'
    if (form.age && (form.age < 12 || form.age > 60)) e.age = 'Enter a valid age.'
    if (!form.pregnancyWeek || form.pregnancyWeek < 1 || form.pregnancyWeek > 40)
      e.pregnancyWeek = 'Pregnancy week must be between 1 and 40.'
    if (form.height && (form.height < 100 || form.height > 220)) e.height = 'Enter a valid height in cm.'
    if (form.weight && (form.weight < 30 || form.weight > 250)) e.weight = 'Enter a valid weight in kg.'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  async function handleSubmit(e) {
    e.preventDefault()
    if (!validate()) return

    const dueDate = form.dueDate || calculateDueDateFromWeek(form.pregnancyWeek)
    const bmi = calculateBMI(form.weight, form.height)

    setSubmitting(true)
    const result = await registerPatient({ ...form, dueDate, bmi })
    setSubmitting(false)
    if (!result.ok) {
      setErrors({ email: result.error })
      return
    }
    setSuccess(true)
    setTimeout(() => {
      setSuccess(false)
      setForm(emptyForm)
      onClose()
    }, 1100)
  }

  function handleClose() {
    setForm(emptyForm)
    setErrors({})
    setSuccess(false)
    onClose()
  }

  return (
    <Modal
      open={open}
      onClose={handleClose}
      title="New Patient Registration"
      subtitle="Complete maternal & pregnancy intake for a new patient."
      maxWidth="max-w-4xl"
      footer={
        <>
          <Button variant="secondary" onClick={handleClose} type="button">
            Cancel
          </Button>
          <Button type="submit" form="new-patient-form">
            {submitting ? 'Registering…' : 'Register Patient'}
          </Button>
        </>
      }
    >
      {success ? (
        <div className="flex flex-col items-center justify-center gap-2 py-10 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
            ✓
          </span>
          <p className="font-semibold text-ink">Patient registered successfully.</p>
          <p className="text-sm text-slate-500">The dashboard and patient list have been updated.</p>
        </div>
      ) : (
        <form id="new-patient-form" onSubmit={handleSubmit} className="space-y-8">
          <section>
            <h4 className="mb-3 text-sm font-bold text-brand-700">Patient Information</h4>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <Field label="Full Name" required>
                <input className={inputCls} value={form.name} onChange={(e) => set('name', e.target.value)} />
                {errors.name && <p className="mt-1 text-xs text-rose-500">{errors.name}</p>}
              </Field>
              <Field label="Email / Gmail" required>
                <input type="email" className={inputCls} value={form.email} onChange={(e) => set('email', e.target.value)} />
                {errors.email && <p className="mt-1 text-xs text-rose-500">{errors.email}</p>}
              </Field>
              <Field label="Age">
                <input type="number" className={inputCls} value={form.age} onChange={(e) => set('age', e.target.value)} />
                {errors.age && <p className="mt-1 text-xs text-rose-500">{errors.age}</p>}
              </Field>
              <Field label="Password" required>
                <input type="password" className={inputCls} value={form.password} onChange={(e) => set('password', e.target.value)} />
                {errors.password && <p className="mt-1 text-xs text-rose-500">{errors.password}</p>}
              </Field>
              <Field label="Confirm Password" required>
                <input type="password" className={inputCls} value={form.confirmPassword} onChange={(e) => set('confirmPassword', e.target.value)} />
                {errors.confirmPassword && <p className="mt-1 text-xs text-rose-500">{errors.confirmPassword}</p>}
              </Field>
              <Field label="Date of Birth">
                <input type="date" className={inputCls} value={form.dob} onChange={(e) => set('dob', e.target.value)} />
              </Field>
              <Field label="Phone Number">
                <input className={inputCls} value={form.phone} onChange={(e) => set('phone', e.target.value)} />
              </Field>
              <Field label="Blood Group">
                <select className={inputCls} value={form.bloodGroup} onChange={(e) => set('bloodGroup', e.target.value)}>
                  <option value="">Select</option>
                  {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((bg) => (
                    <option key={bg} value={bg}>{bg}</option>
                  ))}
                </select>
              </Field>
              <Field label="Address">
                <input className={inputCls} value={form.address} onChange={(e) => set('address', e.target.value)} />
              </Field>
              <Field label="Height (cm)">
                <input type="number" className={inputCls} value={form.height} onChange={(e) => set('height', e.target.value)} />
                {errors.height && <p className="mt-1 text-xs text-rose-500">{errors.height}</p>}
              </Field>
              <Field label="Weight (kg)">
                <input type="number" className={inputCls} value={form.weight} onChange={(e) => set('weight', e.target.value)} />
                {errors.weight && <p className="mt-1 text-xs text-rose-500">{errors.weight}</p>}
              </Field>
              <Field label="BMI (auto-calculated)">
                <input className={`${inputCls} bg-slate-50`} disabled value={calculateBMI(form.weight, form.height) || ''} />
              </Field>
            </div>
          </section>

          <section>
            <h4 className="mb-3 text-sm font-bold text-brand-700">Pregnancy History</h4>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <Field label="Previous Pregnancies">
                <input type="number" min="0" className={inputCls} value={form.previousPregnancies} onChange={(e) => set('previousPregnancies', e.target.value)} />
              </Field>
              <Field label="Previous Births">
                <input type="number" min="0" className={inputCls} value={form.previousBirths} onChange={(e) => set('previousBirths', e.target.value)} />
              </Field>
              <Field label="Previous Complications">
                <input className={inputCls} value={form.previousComplications} onChange={(e) => set('previousComplications', e.target.value)} />
              </Field>
              <Field label="Existing Medical Conditions">
                <input className={inputCls} value={form.medicalConditions} onChange={(e) => set('medicalConditions', e.target.value)} />
              </Field>
              <Field label="Allergies">
                <input className={inputCls} value={form.allergies} onChange={(e) => set('allergies', e.target.value)} />
              </Field>
              <Field label="Current Medications">
                <input className={inputCls} value={form.medications} onChange={(e) => set('medications', e.target.value)} />
              </Field>
            </div>
          </section>

          <section>
            <h4 className="mb-3 text-sm font-bold text-brand-700">Husband / Partner Information</h4>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <Field label="Partner Name">
                <input className={inputCls} value={form.partnerName} onChange={(e) => set('partnerName', e.target.value)} />
              </Field>
              <Field label="Partner Phone">
                <input className={inputCls} value={form.partnerPhone} onChange={(e) => set('partnerPhone', e.target.value)} />
              </Field>
              <Field label="Partner Email">
                <input type="email" className={inputCls} value={form.partnerEmail} onChange={(e) => set('partnerEmail', e.target.value)} />
              </Field>
              <Field label="Emergency Contact">
                <input className={inputCls} value={form.emergencyContact} onChange={(e) => set('emergencyContact', e.target.value)} placeholder="Name · Phone" />
              </Field>
            </div>
          </section>

          <section>
            <h4 className="mb-3 text-sm font-bold text-brand-700">Current Pregnancy</h4>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <Field label="Pregnancy Week (1–40)" required>
                <input type="number" min="1" max="40" className={inputCls} value={form.pregnancyWeek} onChange={(e) => set('pregnancyWeek', e.target.value)} />
                {errors.pregnancyWeek && <p className="mt-1 text-xs text-rose-500">{errors.pregnancyWeek}</p>}
              </Field>
              <Field label="Estimated Due Date">
                <input type="date" className={inputCls} value={form.dueDate} onChange={(e) => set('dueDate', e.target.value)} />
              </Field>
              <Field label="Risk Level">
                <select className={inputCls} value={form.riskLevel} onChange={(e) => set('riskLevel', e.target.value)}>
                  {['Routine', 'Monitor', 'High Risk'].map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </Field>
              <Field label="Assigned Doctor">
                <select className={inputCls} value={form.doctor} onChange={(e) => set('doctor', e.target.value)}>
                  <option value="">Select doctor</option>
                  {doctors.map((d) => <option key={d.id} value={d.name}>{d.name}</option>)}
                </select>
              </Field>
              <Field label="Assigned Midwife">
                <select className={inputCls} value={form.midwife} onChange={(e) => set('midwife', e.target.value)}>
                  <option value="">Select midwife</option>
                  {midwives.map((d) => <option key={d.id} value={d.name}>{d.name}</option>)}
                </select>
              </Field>
              <Field label="Assigned Nurse">
                <select className={inputCls} value={form.nurse} onChange={(e) => set('nurse', e.target.value)}>
                  <option value="">Select nurse</option>
                  {nurses.map((d) => <option key={d.id} value={d.name}>{d.name}</option>)}
                </select>
              </Field>
            </div>
            <div className="mt-4">
              <span className="mb-2 block text-xs font-semibold uppercase tracking-wide text-slate-500">Current Symptoms</span>
              <div className="flex flex-wrap gap-2">
                {SYMPTOM_OPTIONS.map((s) => (
                  <label key={s} className={`flex cursor-pointer items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium ${form.currentSymptoms.includes(s) ? 'border-brand-300 bg-brand-50 text-brand-700' : 'border-slate-200 text-slate-500'}`}>
                    <input type="checkbox" className="hidden" checked={form.currentSymptoms.includes(s)} onChange={() => toggleSymptom(s)} />
                    {s}
                  </label>
                ))}
              </div>
            </div>
          </section>

          <section>
            <h4 className="mb-3 text-sm font-bold text-brand-700">Maternal Vitals</h4>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <Field label="Blood Pressure">
                <input className={inputCls} placeholder="120/80" value={form.bloodPressure} onChange={(e) => set('bloodPressure', e.target.value)} />
              </Field>
              <Field label="Hemoglobin (g/dL)">
                <input type="number" step="0.1" className={inputCls} value={form.hemoglobin} onChange={(e) => set('hemoglobin', e.target.value)} />
              </Field>
              <Field label="Blood Sugar (mg/dL)">
                <input type="number" className={inputCls} value={form.bloodSugar} onChange={(e) => set('bloodSugar', e.target.value)} />
              </Field>
              <Field label="Heart Rate (bpm)">
                <input type="number" className={inputCls} value={form.heartRate} onChange={(e) => set('heartRate', e.target.value)} />
              </Field>
            </div>
          </section>

          <section>
            <h4 className="mb-3 text-sm font-bold text-brand-700">Baby Information (if known)</h4>
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Baby / Child Name">
                <input className={inputCls} value={form.babyName} onChange={(e) => set('babyName', e.target.value)} />
              </Field>
              <Field label="Estimated Fetal Weight">
                <input className={inputCls} value={form.babyWeight} onChange={(e) => set('babyWeight', e.target.value)} />
              </Field>
              <Field label="Estimated Fetal Height">
                <input className={inputCls} value={form.babyHeight} onChange={(e) => set('babyHeight', e.target.value)} />
              </Field>
            </div>
          </section>
        </form>
      )}
    </Modal>
  )
}
