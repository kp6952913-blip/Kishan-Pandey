import React from 'react'
import { Search, SlidersHorizontal, ChevronDown } from 'lucide-react'

const filters = ['Trimester: All', 'Risk Level: High', 'Location: Ward A']

export default function PatientFilters({ value = '', onChange }) {
  return (
    <div className="space-y-4">
      <div className="relative">
        <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={value}
          onChange={(e) => onChange?.(e.target.value)}
          placeholder="Search by name, ID, or condition..."
          className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pl-10 pr-4 text-sm text-slate-600 placeholder:text-slate-400 focus:border-brand-400 focus:outline-none"
        />
      </div>
      <div className="flex flex-wrap items-center gap-3">
        {filters.map((filter) => (
          <button
            key={filter}
            className="flex items-center gap-1.5 rounded-full bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-600"
          >
            {filter}
            <ChevronDown size={14} />
          </button>
        ))}
        <button className="flex items-center gap-1.5 text-xs font-semibold text-brand-600">
          <SlidersHorizontal size={14} />
          More Filters
        </button>
      </div>
    </div>
  )
}
