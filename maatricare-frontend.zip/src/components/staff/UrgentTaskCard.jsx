import React from 'react'

export default function UrgentTaskCard({ title, description, cta, tone }) {
  const isAlert = tone === 'alert'
  return (
    <div
      className={`rounded-xl border p-4 ${
        isAlert ? 'border-rose-100 bg-rose-50' : 'border-brand-100 bg-brand-50'
      }`}
    >
      <div className="flex items-start gap-2">
        <span className={`mt-1 h-2 w-2 shrink-0 rounded-full ${isAlert ? 'bg-rose-500' : 'bg-brand-500'}`} />
        <div>
          <p className="text-sm font-semibold text-ink">{title}</p>
          <p className="mt-1 text-sm text-slate-500">{description}</p>
          <button
            className={`mt-2 text-xs font-bold uppercase tracking-wide ${
              isAlert ? 'text-rose-600' : 'text-brand-600'
            }`}
          >
            {cta}
          </button>
        </div>
      </div>
    </div>
  )
}
