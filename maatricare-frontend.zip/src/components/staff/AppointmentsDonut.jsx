import React, { useMemo } from 'react'
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts'
import Card from '../common/Card.jsx'
import { useAppData } from '../../context/AppDataContext.jsx'

export default function AppointmentsDonut() {
  const { todaysAppointments } = useAppData()
  const breakdown = useMemo(() => {
    const upcoming = todaysAppointments.filter((a) => a.status === 'Upcoming').length
    const completed = todaysAppointments.filter((a) => a.status === 'Completed').length
    const cancelled = todaysAppointments.filter((a) => a.status === 'Cancelled').length
    return [
      { label: 'Upcoming', value: upcoming, color: '#0f766e' },
      { label: 'Completed', value: completed, color: '#10b981' },
      { label: 'Cancelled', value: cancelled, color: '#f43f5e' },
    ].filter((x) => x.value > 0)
  }, [todaysAppointments])
  const data = breakdown.length ? breakdown : [{ label: 'No appointments', value: 1, color: '#cbd5e1' }]
  const total = todaysAppointments.length

  return (
    <Card>
      <h3 className="font-semibold text-ink">Today's Appointments</h3>
      <p className="text-sm text-slate-400">Your scheduled visits for today</p>
      <div className="relative mx-auto mt-4 h-44 w-44">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={data} dataKey="value" nameKey="label" innerRadius={55} outerRadius={80} paddingAngle={2} startAngle={90} endAngle={-270}>
              {data.map((entry) => <Cell key={entry.label} fill={entry.color} />)}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <p className="text-2xl font-bold text-ink">{total}</p>
          <p className="text-xs text-slate-400">Total</p>
        </div>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3">
        {breakdown.map((item) => <div key={item.label} className="flex items-center gap-2 text-sm text-slate-600"><span className="h-2.5 w-2.5 rounded-full" style={{ background: item.color }} />{item.label} ({item.value})</div>)}
        {!breakdown.length && <p className="col-span-2 text-sm text-slate-400">No appointments scheduled today.</p>}
      </div>
    </Card>
  )
}
