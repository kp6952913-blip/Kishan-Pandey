import React from 'react'
import Card from '../common/Card.jsx'
import Icon from '../common/Icon.jsx'

const toneStyles = {
  up: 'text-emerald-600',
  alert: 'text-rose-600',
  default: 'text-slate-400',
}

export default function KpiCard({ label, value, delta, sub, icon, tone = 'default' }) {
  const isAlert = tone === 'alert'
  return (
    <Card
      className={`flex flex-col gap-3 ${isAlert ? 'border-rose-100 bg-rose-50' : ''}`}
    >
      <div className="flex items-center justify-between">
        <span
          className={`flex h-9 w-9 items-center justify-center rounded-lg ${
            isAlert ? 'bg-rose-100 text-rose-600' : 'bg-brand-50 text-brand-600'
          }`}
        >
          <Icon name={icon} size={18} />
        </span>
        <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">{label}</span>
      </div>
      <div className="flex items-baseline gap-2">
        <p className={`text-2xl font-bold ${isAlert ? 'text-rose-600' : 'text-ink'}`}>{value}</p>
        {delta && <span className={`text-xs font-semibold ${toneStyles[tone]}`}>{delta}</span>}
        {sub && <span className="text-xs text-slate-400">{sub}</span>}
      </div>
    </Card>
  )
}
