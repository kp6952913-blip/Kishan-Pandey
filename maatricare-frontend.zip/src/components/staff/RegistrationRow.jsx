import React from 'react'
import Badge from '../common/Badge.jsx'

export default function RegistrationRow({ name, id, week, nextAppt, status }) {
  const tone = status === 'High Risk' ? 'alert' : 'teal'
  return (
    <div className="flex items-center justify-between gap-4 py-3">
      <div className="flex items-center gap-3">
        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-brand-100 text-sm font-semibold text-brand-700">
          {name
            .split(' ')
            .map((n) => n[0])
            .join('')
            .slice(0, 2)}
        </span>
        <div>
          <p className="text-sm font-semibold text-ink">{name}</p>
          <p className="text-xs text-slate-400">
            ID: {id} • {week} Weeks
          </p>
        </div>
      </div>
      <div className="text-right">
        <p className="text-xs text-slate-400">Next Appt</p>
        <p className="text-sm font-medium text-ink">{nextAppt}</p>
      </div>
      <Badge tone={tone}>{status}</Badge>
    </div>
  )
}
