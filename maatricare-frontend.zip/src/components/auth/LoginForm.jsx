import React, { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { Mail, Lock, Eye, EyeOff, ArrowRight, ShieldCheck, AlertCircle } from 'lucide-react'
import Button from '../common/Button.jsx'
import { useAppData } from '../../context/AppDataContext.jsx'

export default function LoginForm() {
  const location = useLocation()
  const [role, setRole] = useState(location.state?.portal || 'couple')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')
  const navigate = useNavigate()
  const { staffLogin, patientLogin } = useAppData()
  const [submitting, setSubmitting] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setSubmitting(true)

    if (role === 'hospital') {
      const result = await staffLogin(email, password)
      if (!result.ok) {
        setError(result.error)
        setSubmitting(false)
        return
      }
      navigate('/staff')
    } else {
      const result = await patientLogin(email, password)
      if (!result.ok) {
        setError(result.error)
        setSubmitting(false)
        return
      }
      navigate('/portal')
    }
    setSubmitting(false)
  }

  return (
    <div className="rounded-3xl border border-slate-100 bg-white p-8 shadow-soft sm:p-10">
      <h2 className="font-serif text-2xl font-bold text-ink">Log in</h2>
      <p className="mt-1 text-sm text-slate-500">Please enter your credentials to continue.</p>

      <div className="mt-6 flex rounded-xl bg-slate-100 p-1">
        {['couple', 'hospital'].map((option) => (
          <button
            key={option}
            type="button"
            onClick={() => {
              setRole(option)
              setError('')
            }}
            className={`flex-1 rounded-lg py-2 text-sm font-semibold capitalize transition-colors ${
              role === option ? 'bg-white text-ink shadow-sm' : 'text-slate-500'
            }`}
          >
            {option}
          </button>
        ))}
      </div>

      {error && (
        <div className="mt-5 flex items-start gap-2 rounded-xl border border-rose-100 bg-rose-50 px-3 py-2.5 text-sm text-rose-600">
          <AlertCircle size={16} className="mt-0.5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="mt-6 space-y-5">
        <div>
          <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
            Email Address
          </label>
          <div className="relative">
            <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.com"
              className="w-full rounded-xl border border-slate-200 py-2.5 pl-9 pr-3 text-sm focus:border-brand-400 focus:outline-none"
            />
          </div>
        </div>

        <div>
          <div className="mb-1.5 flex items-center justify-between">
            <label className="block text-xs font-semibold uppercase tracking-wide text-slate-500">
              Password
            </label>
            <a href="#" className="text-xs font-semibold text-brand-600">
              Forgot Password?
            </a>
          </div>
          <div className="relative">
            <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type={showPassword ? 'text' : 'password'}
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full rounded-xl border border-slate-200 py-2.5 pl-9 pr-9 text-sm focus:border-brand-400 focus:outline-none"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
        </div>

        <Button type="submit" size="lg" className="w-full" icon={ArrowRight}>
          {submitting ? 'Signing In…' : 'Sign In'}
        </Button>
      </form>

      <div className="mt-6 rounded-xl bg-slate-50 p-3 text-xs text-slate-500">
        <p className="font-semibold text-slate-600">Demo credentials</p>
        {role === 'hospital' ? (
          <p className="mt-1">sarah@midcare.com / doctor123</p>
        ) : (
          <p className="mt-1">sarahj@midcare.com / patient123</p>
        )}
      </div>

      <p className="mt-4 flex items-center justify-center gap-1.5 text-xs text-slate-400">
        <ShieldCheck size={14} /> HIPAA Compliant Platform
      </p>
    </div>
  )
}
