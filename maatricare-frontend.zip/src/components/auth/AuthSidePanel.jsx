import React from 'react'
import Badge from '../common/Badge.jsx'

export default function AuthSidePanel() {
  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-100 to-brand-200 p-8 sm:p-10">
      <Badge tone="brand" className="mb-6 bg-white/70">
        Secure Access
      </Badge>
      <h1 className="font-serif text-3xl font-bold text-ink sm:text-4xl">Welcome back to MaatriCare</h1>
      <p className="mt-4 max-w-sm text-slate-600">
        Manage appointments, view health timelines, and stay connected with your care team in a
        secure, compliant environment.
      </p>

      <div className="mt-8 overflow-hidden rounded-2xl shadow-soft">
        <div className="relative flex h-48 items-end bg-gradient-to-br from-brand-300 to-brand-500 p-4">
          <div className="text-white">
            <p className="font-semibold">Empathetic Care, Powered by Data</p>
            <p className="text-sm text-brand-50">Access your comprehensive pregnancy dashboard.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
