import React from 'react'
import { Navigate } from 'react-router-dom'
import { useAppData } from '../../context/AppDataContext.jsx'

export function StaffRoute({ children }) {
  const { isStaffAuthed, authLoading } = useAppData()
  if (authLoading) return <div className="min-h-screen grid place-items-center text-sm text-slate-500">Loading your session…</div>
  if (!isStaffAuthed) return <Navigate to="/login" replace state={{ portal: 'hospital' }} />
  return children
}

export function PatientRoute({ children }) {
  const { isPatientAuthed, authLoading } = useAppData()
  if (authLoading) return <div className="min-h-screen grid place-items-center text-sm text-slate-500">Loading your session…</div>
  if (!isPatientAuthed) return <Navigate to="/login" replace state={{ portal: 'couple' }} />
  return children
}
