import React, { useState } from "react";
import { 
  Heart, ShieldAlert, MessageSquare, Activity, 
  Clock, ShieldCheck, Database, Award, ArrowRight, Sparkles 
} from "lucide-react";

export default function BenefitsSection() {
  const [activeTab, setActiveTab] = useState("patients");

  const patientBenefits = [
    {
      icon: Heart,
      title: "Peace of Mind Every Week",
      description: "Track fetal growth, symptoms, and vitals with clean, easy-to-read charts.",
      badge: "Real-time Tracking",
    },
    {
      icon: ShieldAlert,
      title: "1-Tap Emergency SOS",
      description: "Instantly route GPS coordinates and critical health data to emergency dispatch.",
      badge: "24/7 Safety",
    },
    {
      icon: MessageSquare,
      title: "Direct Care Team Chat",
      description: "Message your assigned OB/GYN or midwife directly with end-to-end privacy.",
      badge: "Encrypted",
    },
    {
      icon: Activity,
      title: "Smart Health Alerts",
      description: "Log blood pressure and sugar levels to flag early risk signs automatically.",
      badge: "Proactive Care",
    },
  ];

  const hospitalBenefits = [
    {
      icon: Clock,
      title: "Reduced Admin Load",
      description: "Automate onboarding, checkup reminders, and follow-ups effortlessly.",
      badge: "Efficiency",
    },
    {
      icon: ShieldCheck,
      title: "AI-Powered Triage",
      description: "Automatically prioritize high-risk patients to streamline doctor workflows.",
      badge: "Smart Triage",
    },
    {
      icon: Database,
      title: "EHR Integration",
      description: "Sync bi-directionally via HL7/FHIR with systems like Epic and Cerner.",
      badge: "Interoperable",
    },
    {
      icon: Award,
      title: "HIPAA Compliant",
      description: "Built from the ground up with 256-bit encryption and strict access controls.",
      badge: "Enterprise Security",
    },
  ];

  const currentBenefits = activeTab === "patients" ? patientBenefits : hospitalBenefits;

  return (
    <section className="py-20 bg-slate-50 border-t border-slate-100 relative overflow-hidden" id="benefits">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center space-x-2 bg-blue-50 border border-blue-200 px-3.5 py-1.5 rounded-full text-xs font-semibold text-blue-700">
            <Sparkles className="w-4 h-4 text-blue-600" />
            <span>Why Choose MaatriCare</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Transforming Maternal Healthcare
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Designed to bridge the gap between expecting mothers and clinical care teams.
          </p>

          {/* Toggle */}
          <div className="pt-4 flex justify-center">
            <div className="bg-slate-200/80 p-1.5 rounded-2xl flex space-x-2 border border-slate-300/60 shadow-inner">
              <button
                onClick={() => setActiveTab("patients")}
                className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${
                  activeTab === "patients"
                    ? "bg-white text-blue-600 shadow-md"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                For Patients & Families
              </button>
              <button
                onClick={() => setActiveTab("hospitals")}
                className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${
                  activeTab === "hospitals"
                    ? "bg-white text-blue-600 shadow-md"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                For Hospitals & Providers
              </button>
            </div>
          </div>
        </div>

        {/* Benefits Grid */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {currentBenefits.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between group"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors duration-300 flex items-center justify-center">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] font-bold tracking-wider uppercase px-2.5 py-1 rounded-md bg-slate-100 text-slate-600">
                      {item.badge}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                    {item.title}
                  </h3>

                  <p className="text-slate-600 text-sm leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="pt-6 mt-4 border-t border-slate-100 flex items-center text-xs font-bold text-blue-600">
                  <span>Learn more</span>
                  <ArrowRight className="w-4 h-4 ml-1 transform group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}