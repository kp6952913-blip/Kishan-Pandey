import React from 'react'
import SectionTitle from '../common/SectionTitle.jsx'
import FeatureCard from './FeatureCard.jsx'
import { features } from '../../data/mockData.js'

export default function FeaturesSection() {
  return (
    <section id="features" className="bg-slate-50 py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionTitle
          eyebrow="Platform"
          title="Comprehensive Care, Unified."
          description="MaatriCare bridges the gap between clinical excellence and home-based monitoring, providing a single source of truth for providers and peace of mind for parents-to-be."
        />
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <FeatureCard key={feature.title} {...feature} />
          ))}
        </div>
      </div>
    </section>
  )
}
