import React from 'react'
import { ArrowRight } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import Card from '../common/Card.jsx'
import Icon from '../common/Icon.jsx'

export default function FeatureCard({ title, description, icon }) {
  const navigate = useNavigate()

  return (
    <Card className="text-left transition-shadow hover:shadow-lg">
      <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-50 text-brand-600">
        <Icon name={icon} size={22} />
      </span>

      <h3 className="mt-5 text-lg font-semibold text-ink">
        {title}
      </h3>

      <p className="mt-2 text-sm text-slate-500">
        {description}
      </p>

      <button
        onClick={() => navigate('/login')}
        className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-brand-600"
      >
        Learn more <ArrowRight size={14} />
      </button>
    </Card>
  )
}