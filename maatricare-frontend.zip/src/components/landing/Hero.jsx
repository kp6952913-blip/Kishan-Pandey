import React from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, Heart, Star } from 'lucide-react'
import Button from '../common/Button.jsx'
import Badge from '../common/Badge.jsx'

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-brand-50 via-white to-brand-100">
      <div className="mx-auto grid max-w-7xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:items-center lg:px-8 lg:py-24">
        <div>
          <Badge tone="brand" className="mb-6">
            Enterprise-Grade Healthcare
          </Badge>
          <h1 className="font-serif text-4xl font-bold leading-tight text-ink sm:text-5xl">
            A National Standard <br />
            for <span className="text-brand-600">Pregnancy Care.</span>
          </h1>
          <p className="mt-6 max-w-xl text-slate-500">
            MaatriCare provides hospitals and expectant couples with a seamless, secure, and intuitive
            platform to manage the entire maternal health journey.
          </p>
          <p className="mt-2 max-w-xl font-medium text-slate-700">
            Data-driven care, designed for human connection.
          </p>

          <div className="mt-8 flex flex-wrap gap-4">
            <Button as={Link} to="/login" size="lg" icon={ArrowRight}>
              Schedule a Demo
            </Button>
            <Button as="a" href="#features" variant="secondary" size="lg">
              Explore Features
            </Button>
          </div>

          <div className="mt-10 flex items-center gap-4 border-t border-slate-200 pt-6">
            <div className="flex -space-x-3">
              {[1, 2, 3].map((i) => (
                <div
                  key={i}
                  className="h-9 w-9 rounded-full border-2 border-white bg-brand-200"
                  aria-hidden="true"
                />
              ))}
            </div>
            <div>
              <div className="flex text-amber-400">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={14} fill="currentColor" strokeWidth={0} />
                ))}
              </div>
              <p className="text-sm text-slate-500">Trusted by 500+ Hospitals</p>
            </div>
          </div>
        </div>

        <div className="relative">
          <div className="aspect-[4/3] w-full rounded-3xl bg-gradient-to-br from-brand-200 to-brand-400 shadow-soft" />
          <div className="absolute bottom-6 left-6 flex items-center gap-3 rounded-2xl bg-white px-4 py-3 shadow-soft">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-care-teal/20 text-care-tealDark">
              <Heart size={18} fill="currentColor" />
            </span>
            <div>
              <p className="text-xs text-slate-400">Vitals Sync Complete</p>
              <p className="text-sm font-bold text-ink">120 BPM</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
