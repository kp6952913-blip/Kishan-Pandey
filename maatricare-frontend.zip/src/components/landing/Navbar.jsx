import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { Menu, X, UserRound } from 'lucide-react'
import Button from '../common/Button.jsx'
import logo from '../../assets/logo.png'

// Updated to use router page paths instead of hash scroll anchors
const links = [
  { label: 'Features', path: '/' },
  { label: 'Benefits', path: '/benefits' },
  { label: 'FAQ', path: '/faq' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)

  return (
    <header className="sticky top-0 z-40 border-b border-slate-100 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2">
          <img src={logo} alt="MaatriCare" className="h-9 w-9 object-contain" />
          <span className="text-lg font-bold text-brand-700">MaatriCare</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden items-center gap-8 md:flex">
          {links.map((link) => (
            <Link 
              key={link.label} 
              to={link.path} 
              className="text-sm font-medium text-slate-600 hover:text-brand-700"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Desktop CTA & Login */}
        <div className="hidden items-center gap-3 md:flex">
          <Button as={Link} to="/login" size="sm">
            Login
          </Button>
          <Link
            to="/login"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-600 text-white"
          >
            <UserRound size={16} />
          </Link>
        </div>

        {/* Mobile Hamburger Toggle */}
        <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Toggle menu">
          {open ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Drawer Menu */}
      {open && (
        <div className="border-t border-slate-100 bg-white px-4 pb-4 md:hidden">
          <nav className="flex flex-col gap-3 pt-3">
            {links.map((link) => (
              <Link 
                key={link.label} 
                to={link.path} 
                onClick={() => setOpen(false)}
                className="text-sm font-medium text-slate-600 hover:text-brand-700"
              >
                {link.label}
              </Link>
            ))}
            <Button as={Link} to="/login" size="sm" className="mt-2 w-full" onClick={() => setOpen(false)}>
              Login
            </Button>
          </nav>
        </div>
      )}
    </header>
  )
}