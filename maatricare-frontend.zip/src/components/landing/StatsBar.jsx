import React from 'react'
import { stats } from '../../data/mockData.js'

export default function StatsBar() {
  return (
    <section className="bg-brand-600">
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-8 px-4 py-12 text-center text-white sm:px-6 lg:grid-cols-4 lg:px-8">
        {stats.map((stat) => (
          <div key={stat.label}>
            <p className="font-serif text-3xl font-bold sm:text-4xl">{stat.value}</p>
            <p className="mt-2 text-xs font-semibold uppercase tracking-wide text-brand-100">
              {stat.label}
            </p>
          </div>
        ))}
      </div>
    </section>
  )
}
