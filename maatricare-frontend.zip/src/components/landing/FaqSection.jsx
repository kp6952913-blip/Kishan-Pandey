import React, { useState } from "react";
import { ChevronDown, Search, HelpCircle, MessageCircle } from "lucide-react";

export default function FaqSection() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [openId, setOpenId] = useState("faq-1");
  const [searchQuery, setSearchQuery] = useState("");

  const faqs = [
    {
      id: "faq-1",
      category: "patient",
      question: "How does the SOS Emergency feature work?",
      answer:
        "Tapping the SOS button immediately transmits your live GPS coordinates, medical record summary, and blood type directly to hospital emergency dispatch while placing an urgent call to your doctor.",
    },
    {
      id: "faq-2",
      category: "general",
      question: "Is patient health data secure and HIPAA compliant?",
      answer:
        "Yes. MaatriCare implements 256-bit encryption for all records, vitals logs, and messages in complete compliance with HIPAA and global medical privacy standards.",
    },
    {
      id: "faq-3",
      category: "hospital",
      question: "Can MaatriCare integrate with our current EHR system?",
      answer:
        "Yes, MaatriCare supports modern HL7/FHIR interfaces for fast bi-directional sync with major EHR systems like Epic, Cerner, and Athenahealth.",
    },
    {
      id: "faq-4",
      category: "patient",
      question: "Can my partner or family member access my profile?",
      answer:
        "Yes! You can invite secondary care users with custom permissions so they can follow baby progress, view checkup schedules, and receive emergency alerts.",
    },
    {
      id: "faq-5",
      category: "hospital",
      question: "How long does onboarding take for clinics?",
      answer:
        "Most healthcare networks complete integration, workflow customization, and clinical staff onboarding within 2 to 4 weeks.",
    },
  ];

  const filteredFaqs = faqs.filter((faq) => {
    const matchesCategory = activeCategory === "all" || faq.category === activeCategory || faq.category === "general";
    const matchesSearch =
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <section className="py-20 bg-white border-t border-slate-100" id="faq">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center space-x-2 bg-teal-50 border border-teal-200 px-3 py-1 rounded-full text-xs font-semibold text-teal-700">
            <HelpCircle className="w-4 h-4 text-teal-600" />
            <span>Got Questions?</span>
          </div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            Frequently Asked Questions
          </h2>
        </div>

        {/* Search & Categories */}
        <div className="mt-8 space-y-4">
          <div className="relative">
            <Search className="w-5 h-5 absolute left-4 top-3.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search questions (e.g., SOS, EHR integration, privacy)..."
              className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="flex justify-center space-x-2">
            {["all", "patient", "hospital"].map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-1.5 rounded-xl text-xs font-bold capitalize transition-all ${
                  activeCategory === cat
                    ? "bg-slate-900 text-white shadow-sm"
                    : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                }`}
              >
                {cat === "all" ? "All Questions" : `For ${cat}s`}
              </button>
            ))}
          </div>
        </div>

        {/* FAQ List */}
        <div className="mt-8 space-y-3">
          {filteredFaqs.map((faq) => {
            const isOpen = openId === faq.id;
            return (
              <div
                key={faq.id}
                className={`border rounded-2xl transition-all overflow-hidden ${
                  isOpen ? "border-blue-500 bg-blue-50/20" : "border-slate-200 bg-white"
                }`}
              >
                <button
                  onClick={() => setOpenId(isOpen ? null : faq.id)}
                  className="w-full px-6 py-4 flex items-center justify-between text-left font-bold text-slate-900 text-sm sm:text-base"
                >
                  <span>{faq.question}</span>
                  <ChevronDown className={`w-5 h-5 transition-transform ${isOpen ? "rotate-180 text-blue-600" : "text-slate-400"}`} />
                </button>

                {isOpen && (
                  <div className="px-6 pb-5 text-slate-600 text-sm leading-relaxed border-t border-slate-100 pt-3">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Contact Strip */}
        <div className="mt-12 bg-slate-50 rounded-2xl p-5 border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <MessageCircle className="w-6 h-6 text-teal-600" />
            <div>
              <h4 className="font-bold text-slate-900 text-sm">Still have questions?</h4>
              <p className="text-slate-500 text-xs">Our clinical team is available to assist you.</p>
            </div>
          </div>
          <button className="bg-slate-900 hover:bg-slate-800 text-white font-bold px-4 py-2 rounded-xl text-xs whitespace-nowrap">
            Contact Support
          </button>
        </div>

      </div>
    </section>
  );
}