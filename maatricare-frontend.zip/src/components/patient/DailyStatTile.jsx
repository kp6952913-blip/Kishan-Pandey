import React from 'react'

export default function DailyStatTile({ label, value, sub }) {
  return (
    <div className="rounded-xl bg-slate-50 p-4 text-center">
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">{label}</p>
      <p className="mt-2 text-lg font-bold text-ink">{value}</p>
      {sub && <p className="text-xs text-emerald-600">{sub}</p>}
    </div>
  )
}
