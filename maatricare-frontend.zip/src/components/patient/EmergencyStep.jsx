import React from 'react'
import { Check } from 'lucide-react'

export default function EmergencyStep({ time, title, detail, isLast }) {
  const done = Boolean(time)
  return (
    <div className="relative flex gap-4 pb-6 last:pb-0">
      {!isLast && <span className="absolute left-[11px] top-6 h-full w-px bg-slate-200" />}
      <span
        className={`z-10 flex h-6 w-6 shrink-0 items-center justify-center rounded-full ${
          done ? 'bg-emerald-500 text-white' : 'bg-slate-200 text-slate-400'
        }`}
      >
        {done ? <Check size={14} /> : null}
      </span>
      <div>
        <div className="flex items-center gap-2">
          <p className="font-semibold text-ink">{title}</p>
          {time && <span className="text-xs font-semibold text-slate-400">{time}</span>}
        </div>
        <p className="mt-1 text-sm text-slate-500">{detail}</p>
      </div>
    </div>
  )
}
