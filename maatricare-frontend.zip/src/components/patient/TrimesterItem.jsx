import React from 'react'

export default function TrimesterItem({ range, title, note, current }) {
  return (
    <div
      className={`rounded-2xl border p-4 ${
        current ? 'border-brand-200 bg-brand-50' : 'border-slate-100 bg-white'
      }`}
    >
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">{range}</p>
      <p className={`mt-1 font-semibold ${current ? 'text-brand-700' : 'text-ink'}`}>{title}</p>
      <p className="mt-1 text-sm text-slate-500">{note}</p>
      {current && (
        <span className="mt-2 inline-block rounded-full bg-brand-600 px-2.5 py-0.5 text-xs font-semibold text-white">
          Current
        </span>
      )}
    </div>
  )
}
