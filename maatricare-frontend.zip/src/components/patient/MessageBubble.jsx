import React from 'react'
import { Paperclip } from 'lucide-react'
import Button from '../common/Button.jsx'

export default function MessageBubble({ from, time, text, attachment, cta }) {
  const isMe = from === 'me'
  return (
    <div className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-md ${isMe ? 'items-end' : 'items-start'} flex flex-col gap-1`}>
        <div
          className={`rounded-2xl px-4 py-3 text-sm ${
            isMe ? 'bg-brand-600 text-white' : 'bg-slate-100 text-ink'
          }`}
        >
          {text}
          {attachment && (
            <div
              className={`mt-2 flex items-center gap-2 rounded-lg px-2 py-1.5 text-xs ${
                isMe ? 'bg-white/20' : 'bg-white'
              }`}
            >
              <Paperclip size={12} /> {attachment}
            </div>
          )}
          {cta && (
            <Button size="sm" variant={isMe ? 'secondary' : 'primary'} className="mt-2">
              {cta}
            </Button>
          )}
        </div>
        <span className="px-1 text-[11px] text-slate-400">{time}</span>
      </div>
    </div>
  )
}
