import React from 'react'
import Card from '../common/Card.jsx'

export default function AppointmentSummaryCard({ label, value, sub }) {
  return (
    <Card>
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">{label}</p>
      <p className="mt-2 text-2xl font-bold text-ink">{value}</p>
      <p className="mt-1 text-xs text-slate-500">{sub}</p>
    </Card>
  )
}
