import React from 'react'

export default function ConversationItem({ name, preview, time, active }) {
  return (
    <button
      className={`flex w-full items-center gap-3 rounded-xl p-3 text-left transition-colors ${
        active ? 'bg-brand-50' : 'hover:bg-slate-50'
      }`}
    >
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand-100 text-sm font-semibold text-brand-700">
        {name
          .split(' ')
          .map((n) => n[0])
          .slice(0, 2)
          .join('')}
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <p className="truncate text-sm font-semibold text-ink">{name}</p>
          <span className="shrink-0 text-xs text-slate-400">{time}</span>
        </div>
        <p className="truncate text-xs text-slate-500">{preview}</p>
      </div>
    </button>
  )
}
