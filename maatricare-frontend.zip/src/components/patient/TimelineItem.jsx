import React from 'react'

export default function TimelineItem({ date, title, provider, note, isLast }) {
  return (
    <div className="relative pl-6">
      {!isLast && <span className="absolute left-[5px] top-4 h-full w-px bg-slate-200" />}
      <span className="absolute left-0 top-1.5 h-2.5 w-2.5 rounded-full bg-brand-600" />
      <p className="text-xs font-semibold uppercase tracking-wide text-brand-600">{date}</p>
      <p className="mt-1 font-semibold text-ink">{title}</p>
      <p className="text-xs text-slate-400">{provider}</p>
      <p className="mt-1 text-sm text-slate-500">{note}</p>
    </div>
  )
}
