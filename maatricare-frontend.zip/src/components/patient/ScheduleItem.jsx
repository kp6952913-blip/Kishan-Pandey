import React from 'react'
import Button from '../common/Button.jsx'
import Badge from '../common/Badge.jsx'

const typeTone = {
  Medicine: 'brand',
  Hydration: 'teal',
  Appointment: 'warning',
}

export default function ScheduleItem({ time, type, title, detail, completed, onComplete }) {
  return (
    <div className={`flex flex-wrap items-center justify-between gap-4 rounded-xl border p-4 ${completed ? 'border-slate-100 bg-slate-50' : 'border-slate-100'}`}>
      <div className="flex items-start gap-3">
        <Badge tone={completed ? 'default' : typeTone[type] || 'default'}>{type}</Badge>
        <div>
          <p className={`font-semibold ${completed ? 'text-slate-400 line-through' : 'text-ink'}`}>{title}</p>
          <p className="text-sm text-slate-500">{detail}</p>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <span className="text-sm font-semibold text-slate-500">{time}</span>
        {type === 'Appointment' ? (
          <Button size="sm" variant="secondary">View Details</Button>
        ) : (
          <Button
            size="sm"
            variant={completed ? 'secondary' : 'primary'}
            className={completed ? 'bg-white text-slate-400' : ''}
            onClick={onComplete}
          >
            {completed ? 'Completed' : 'Mark Complete'}
          </Button>
        )}
      </div>
    </div>
  )
}
