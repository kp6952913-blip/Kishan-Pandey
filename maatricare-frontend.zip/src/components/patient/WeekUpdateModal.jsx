import React from 'react'
import Modal from '../common/Modal.jsx'
import Badge from '../common/Badge.jsx'
import { getWeekGroup, getTrimesterLabel } from '../../utils/pregnancy.js'

export default function WeekUpdateModal({ open, onClose, week }) {
  if (!week) return null
  const group = getWeekGroup(week)

  return (
    <Modal open={open} onClose={onClose} title={`Week ${week} Update`} subtitle={`${group.range} · ${getTrimesterLabel(week)}`}>
      <div className="space-y-5">
        <div className="flex items-center gap-3 rounded-xl bg-brand-50 p-4">
          <span className="text-2xl">👶</span>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-brand-600">Baby's Size</p>
            <p className="font-serif text-lg font-bold text-ink">{group.babySize}</p>
          </div>
        </div>

        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Baby Development</p>
          <p className="mt-1 text-sm text-slate-600">{group.babyDevelopment}</p>
        </div>

        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Changes For You</p>
          <p className="mt-1 text-sm text-slate-600">{group.maternalChanges}</p>
        </div>

        <div>
          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Milestones This Range</p>
          <div className="flex flex-wrap gap-2">
            {group.milestones.map((m) => (
              <Badge key={m} tone="brand">{m}</Badge>
            ))}
          </div>
        </div>

        <div>
          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Common Symptoms</p>
          <div className="flex flex-wrap gap-2">
            {group.commonSymptoms.map((s) => (
              <Badge key={s} tone="default">{s}</Badge>
            ))}
          </div>
        </div>

        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">General Care</p>
          <p className="mt-1 text-sm text-slate-600">{group.careInfo}</p>
        </div>

        <div className="rounded-xl border border-amber-100 bg-amber-50 p-4">
          <p className="text-xs font-semibold uppercase tracking-wide text-amber-700">Discuss With Your Provider</p>
          <p className="mt-1 text-sm text-amber-800">{group.talkToProvider}</p>
        </div>
      </div>
    </Modal>
  )
}
