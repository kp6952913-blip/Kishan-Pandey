import React from 'react'
import Card from '../common/Card.jsx'
import Icon from '../common/Icon.jsx'

export default function GlanceCard({ label, icon, value, sub, highlight }) {
  return (
    <Card className={highlight ? 'bg-care-teal/15' : ''}>
      <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
        <Icon name={icon} size={16} className={highlight ? 'text-care-tealDark' : 'text-brand-500'} />
        {label}
      </div>
      <p className="mt-3 text-sm font-bold text-ink">{value}</p>
      <p className="mt-1 text-xs text-slate-500">{sub}</p>
    </Card>
  )
}
