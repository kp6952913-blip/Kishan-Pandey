import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { LogOut } from 'lucide-react'
import Icon from '../common/Icon.jsx'
import { patientNav } from '../../data/mockData.js'
import { useAppData } from '../../context/AppDataContext.jsx'
import logo from '../../assets/logo.png'

export default function PatientSidebar() {
  const { logout } = useAppData()
  const navigate = useNavigate()

  function handleLogout() {
    logout()
    navigate('/login', { state: { portal: 'couple' } })
  }

  return (
    <aside className="hidden w-64 shrink-0 flex-col border-r border-slate-100 bg-white lg:flex">
      <div className="flex items-center gap-2 px-6 py-6">
        <img src={logo} alt="MaatriCare" className="h-8 w-8 object-contain" />
        <span className="text-base font-bold text-care-tealDark">MaatriCare Me</span>
      </div>

      <nav className="flex-1 space-y-1 px-3">
        {patientNav.map((item) => (
          <NavLink
            key={item.label}
            to={item.to}
            end={item.to === '/portal'}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-care-teal/20 text-care-tealDark'
                  : item.danger
                  ? 'text-rose-600 hover:bg-rose-50'
                  : 'text-slate-600 hover:bg-slate-50'
              }`
            }
          >
            <Icon name={item.icon} size={18} />
            {item.label}
          </NavLink>
        ))}
      </nav>

      <div className="border-t border-slate-100 px-3 py-4">
        <button
          onClick={handleLogout}
          className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-600 hover:bg-rose-50 hover:text-rose-600"
        >
          <LogOut size={18} />
          Log Out
        </button>
      </div>
    </aside>
  )
}
