import React from 'react'
import { PersonStanding, Heart, Search } from 'lucide-react'
import Badge from '../common/Badge.jsx'
import { useAppData } from '../../context/AppDataContext.jsx'
import { getTrimester } from '../../utils/pregnancy.js'

export default function PatientTopbar({ showSearch = false }) {
  const { currentPatient } = useAppData()
  const week = currentPatient?.pregnancyWeek
  const trimester = week ? getTrimester(week) : null
  const coupleName = currentPatient ? `${currentPatient.name}${currentPatient.partnerName ? ' & ' + currentPatient.partnerName : ''}` : 'Guest'

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 bg-white px-4 py-4 sm:px-6 lg:px-8">
      <Badge tone="teal">
        <PersonStanding size={14} /> {week ? `Week ${week} • Trimester ${trimester}` : 'Welcome'}
      </Badge>

      {showSearch && (
        <div className="relative hidden max-w-sm flex-1 sm:block">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search records..."
            className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-sm text-slate-600 placeholder:text-slate-400 focus:border-brand-400 focus:outline-none"
          />
        </div>
      )}

      <div className="flex items-center gap-3">
        <p className="text-sm font-semibold text-ink">{coupleName}</p>
        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-care-teal/20 text-care-tealDark">
          <Heart size={16} />
        </span>
      </div>
    </div>
  )
}
