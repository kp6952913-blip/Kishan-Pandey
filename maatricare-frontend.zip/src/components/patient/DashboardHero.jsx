import React from 'react'
import { ArrowRight } from 'lucide-react'
import Badge from '../common/Badge.jsx'
import Button from '../common/Button.jsx'

export default function DashboardHero({ coupleNames = 'Guest', week = 1, babySize = '', onReadUpdate }) {
  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-500 to-brand-700 p-6 text-white shadow-soft sm:p-8">
      <div className="max-w-md">
        <Badge tone="teal" className="mb-4">
          Dashboard Home
        </Badge>
        <p className="text-brand-100">Welcome back, {coupleNames}</p>
        <h2 className="mt-2 font-serif text-2xl font-bold sm:text-3xl">Week {week}</h2>
        <p className="mt-2 text-brand-50">
          {babySize ? `Your baby is roughly the size of ${/^[aeiou]/i.test(babySize) ? 'an' : 'a'} ${babySize.toLowerCase()}.` : 'Track your baby\'s growth week by week.'}
        </p>
        <Button variant="teal" className="mt-6" icon={ArrowRight} onClick={onReadUpdate}>
          Read Week {week} Update
        </Button>
      </div>
    </div>
  )
}
