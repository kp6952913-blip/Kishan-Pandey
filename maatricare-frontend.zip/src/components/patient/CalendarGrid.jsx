import React from 'react'

const weekDays = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT']

export default function CalendarGrid({ label, days }) {
  // Simplified October 2024 layout starting on Tuesday Oct 1.
  const leadingBlanks = 2
  const daysInMonth = 31
  const cells = [...Array(leadingBlanks).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => i + 1)]

  function eventFor(day) {
    return days.find((d) => d.day === day)
  }

  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <p className="font-semibold text-ink">{label}</p>
      </div>
      <div className="grid grid-cols-7 gap-1 text-center text-xs font-semibold text-slate-400">
        {weekDays.map((d) => (
          <span key={d}>{d}</span>
        ))}
      </div>
      <div className="mt-2 grid grid-cols-7 gap-1">
        {cells.map((day, i) => {
          const event = day ? eventFor(day) : null
          return (
            <div
              key={i}
              className={`flex min-h-[54px] flex-col rounded-lg border p-1 text-xs ${
                day ? 'border-slate-100' : 'border-transparent'
              } ${event?.active ? 'border-brand-300 bg-brand-50' : 'bg-white'}`}
            >
              {day && <span className="font-semibold text-slate-500">{day}</span>}
              {event && (
                <span className="mt-1 line-clamp-2 rounded bg-brand-100 px-1 text-[10px] font-medium text-brand-700">
                  {event.event}
                </span>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
