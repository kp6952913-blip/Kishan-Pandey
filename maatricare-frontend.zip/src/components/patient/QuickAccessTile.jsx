import React from 'react'
import { Link } from 'react-router-dom'
import Icon from '../common/Icon.jsx'

export default function QuickAccessTile({ label, icon, to, danger }) {
  return (
    <Link
      to={to}
      className={`flex flex-col items-center gap-3 rounded-2xl border p-6 text-center transition-shadow hover:shadow-soft ${
        danger ? 'border-rose-100 bg-rose-50' : 'border-slate-100 bg-white'
      }`}
    >
      <span
        className={`flex h-11 w-11 items-center justify-center rounded-full ${
          danger ? 'bg-rose-600 text-white' : 'bg-brand-50 text-brand-600'
        }`}
      >
        <Icon name={icon} size={20} />
      </span>
      <span className={`text-sm font-semibold ${danger ? 'text-rose-600' : 'text-ink'}`}>{label}</span>
    </Link>
  )
}
