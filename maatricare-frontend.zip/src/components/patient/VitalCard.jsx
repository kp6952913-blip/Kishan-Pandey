import React from 'react'
import Card from '../common/Card.jsx'
import Icon from '../common/Icon.jsx'

export default function VitalCard({ label, value, unit, status, icon }) {
  return (
    <Card>
      <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
        <Icon name={icon} size={16} className="text-brand-500" />
        {label}
      </div>
      <p className="mt-2 text-xl font-bold text-ink">
        {value} <span className="text-sm font-medium text-slate-400">{unit}</span>
      </p>
      <p className="mt-1 text-xs text-emerald-600">{status}</p>
    </Card>
  )
}
