# MidCare Frontend

This is the React/Vite/Tailwind frontend after integration with the Node.js + MongoDB backend.

## Run

1. Install dependencies:

```bash
npm install
```

2. Create `.env` from `.env.example`:

```bash
cp .env.example .env
```

3. Set `VITE_API_URL` to the running backend API, for example:

```env
VITE_API_URL=http://localhost:5000/api
```

4. Start the frontend:

```bash
npm run dev
```

## Important

This frontend no longer uses `patients.json` or `hospitalStaff.json` for dynamic data and does not use localStorage as the application database. Dynamic data is retrieved through the Node.js API.

The Node.js/MongoDB backend is provided separately.
