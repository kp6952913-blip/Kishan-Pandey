import React from 'react'
import { Paperclip, Check, CheckCheck } from 'lucide-react'

export default function MessageBubble({ from, time, text, attachment, read }) {
  const isMe = from === 'me'
  return (
    <div className={`flex ${isMe ? 'justify-end' : 'justify-start'} animate-message-in`}>
      <div className={`flex max-w-[85%] flex-col gap-1 sm:max-w-md ${isMe ? 'items-end' : 'items-start'}`}>
        <div
          className={`rounded-2xl px-4 py-2.5 text-sm leading-relaxed shadow-sm transition-colors ${
            isMe
              ? 'rounded-br-md bg-brand-600 text-white'
              : 'rounded-bl-md bg-slate-100 text-ink'
          }`}
        >
          {text}
          {attachment && (
            <div
              className={`mt-2 flex items-center gap-2 rounded-lg px-2 py-1.5 text-xs transition-colors ${
                isMe ? 'bg-white/20 hover:bg-white/30' : 'bg-white hover:bg-slate-50'
              }`}
            >
              <Paperclip size={12} /> {attachment}
            </div>
          )}
        </div>
        <span className="flex items-center gap-1 px-1 text-[11px] text-slate-400">
          {time}
          {isMe && (read ? <CheckCheck size={13} className="text-brand-500" /> : <Check size={13} />)}
        </span>
      </div>
    </div>
  )
}
