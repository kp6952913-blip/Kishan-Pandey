import React from 'react'

export default function ConversationItem({ name, preview, time, unread = 0, active, onClick }) {
  return (
    <button
      onClick={onClick}
      aria-current={active ? 'true' : undefined}
      className={`group flex w-full items-center gap-3 rounded-xl p-3 text-left transition-all duration-150 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 ${
        active ? 'bg-brand-50 shadow-sm' : 'hover:bg-slate-50 active:bg-slate-100'
      }`}
    >
      <span
        className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-sm font-semibold transition-colors ${
          active ? 'bg-brand-600 text-white' : 'bg-brand-100 text-brand-700'
        }`}
      >
        {name
          .split(' ')
          .map((n) => n[0])
          .slice(0, 2)
          .join('')}
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <p className={`truncate text-sm font-semibold ${active ? 'text-brand-700' : 'text-ink'}`}>{name}</p>
          <span className="shrink-0 text-xs text-slate-400">{time}</span>
        </div>
        <div className="flex items-center justify-between gap-2">
          <p className={`truncate text-xs ${unread > 0 ? 'font-medium text-ink' : 'text-slate-500'}`}>{preview}</p>
          {unread > 0 && (
            <span className="flex h-4 min-w-4 shrink-0 items-center justify-center rounded-full bg-brand-600 px-1 text-[10px] font-semibold text-white">
              {unread}
            </span>
          )}
        </div>
      </div>
    </button>
  )
}
