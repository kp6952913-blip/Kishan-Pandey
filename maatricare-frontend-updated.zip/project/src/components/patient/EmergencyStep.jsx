import React from 'react'
import { Check } from 'lucide-react'

/**
 * A single step in the emergency status timeline.
 *
 * `active`  – step has been reached, renders green ("done").
 * `pulse`   – adds a brief, professional glow/scale animation (used for the
 *             final stage the moment it activates).
 * Falls back to the original `time`-based done state when `active` isn't
 * explicitly provided, so existing usage keeps working unchanged.
 */
export default function EmergencyStep({ time, title, detail, isLast, active, pulse }) {
  const done = active ?? Boolean(time)
  return (
    <div className="relative flex gap-4 pb-6 last:pb-0">
      {!isLast && (
        <span
          className={`absolute left-[11px] top-6 h-full w-px transition-colors duration-500 ${
            done ? 'bg-emerald-400' : 'bg-slate-200'
          }`}
        />
      )}
      <span
        className={`z-10 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 transition-all duration-300 ${
          done
            ? 'border-emerald-500 bg-emerald-500 text-white shadow-[0_0_0_4px_rgba(16,185,129,0.15)]'
            : 'border-slate-200 bg-slate-100 text-slate-400'
        } ${pulse ? 'animate-emergency-final' : ''}`}
      >
        {done ? <Check size={14} /> : null}
      </span>
      <div className={`rounded-xl transition-colors duration-300 ${pulse ? 'animate-emergency-glow' : ''}`}>
        <div className="flex items-center gap-2">
          <p className={`font-semibold transition-colors duration-300 ${done ? 'text-emerald-700' : 'text-ink'}`}>
            {title}
          </p>
          {time && <span className="text-xs font-semibold text-slate-400">{time}</span>}
        </div>
        <p className="mt-1 text-sm text-slate-500">{detail}</p>
      </div>
    </div>
  )
}
