import React from 'react'
import { Phone } from 'lucide-react'
import StaffLayout from '../../layouts/StaffLayout.jsx'
import Card from '../../components/common/Card.jsx'
import Icon from '../../components/common/Icon.jsx'
import Badge from '../../components/common/Badge.jsx'

export default function StaffEmergency() {
  return (
    <StaffLayout>
      <div className="space-y-6">
        <div>
          <h1 className="font-serif text-2xl font-bold text-ink sm:text-3xl">Emergency Services</h1>
          <p className="mt-1 max-w-xl text-sm text-slate-500">
            Hospital-side emergency response management.
          </p>
        </div>

        <Card className="mx-auto max-w-xl text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-amber-50 text-amber-500">
            <Icon name="AlertTriangle" size={26} />
          </div>

          <h2 className="mt-4 text-lg font-bold text-ink">Currently Unavailable</h2>
          <Badge tone="warning" className="mt-2">
            Resource &amp; system integration pending
          </Badge>

          <p className="mx-auto mt-4 max-w-sm text-sm leading-relaxed text-slate-500">
            This emergency management feature is temporarily unavailable due to resource and
            system integration limitations. Please use the available hospital communication
            channels for urgent assistance.
          </p>

          <div className="mt-6 flex items-center justify-center gap-2 rounded-xl bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-600">
            <Phone size={15} />
            Hospital Emergency Line: Ext. 911
          </div>
        </Card>
      </div>
    </StaffLayout>
  )
}
