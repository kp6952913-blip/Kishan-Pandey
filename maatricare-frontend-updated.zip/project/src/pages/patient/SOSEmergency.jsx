import React, { useEffect, useRef, useState } from 'react'
import { Siren, Phone, MapPin, RotateCcw } from 'lucide-react'
import PatientLayout from '../../layouts/PatientLayout.jsx'
import Card from '../../components/common/Card.jsx'
import Badge from '../../components/common/Badge.jsx'
import EmergencyStep from '../../components/patient/EmergencyStep.jsx'
import { emergencyTimeline, criticalVitals, quickDial } from '../../data/mockData.js'

const TOTAL_SECONDS = 5 * 60 // 5:00 countdown
const FINAL_STAGE_TRIGGER = 12 // seconds remaining
// How far into the countdown (elapsed seconds) each of the first three
// stages progressively turns green.
const STAGE_THRESHOLDS = [0, 5, 15]

function formatCountdown(totalSeconds) {
  const m = Math.floor(totalSeconds / 60)
  const s = totalSeconds % 60
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
}

export default function SOSEmergency() {
  const [status, setStatus] = useState('idle') // idle | active | complete
  const [remaining, setRemaining] = useState(TOTAL_SECONDS)
  const [finalJustActivated, setFinalJustActivated] = useState(false)
  const intervalRef = useRef(null)
  const finalPulseTimeoutRef = useRef(null)
  const wasFinalActiveRef = useRef(false)

  const elapsed = TOTAL_SECONDS - remaining
  const finalActive = status !== 'idle' && remaining <= FINAL_STAGE_TRIGGER

  useEffect(() => {
    // Trigger the quick pulse animation exactly once, the moment the final
    // stage becomes active — not on every re-render / not on a loop.
    if (finalActive && !wasFinalActiveRef.current) {
      setFinalJustActivated(true)
      clearTimeout(finalPulseTimeoutRef.current)
      finalPulseTimeoutRef.current = setTimeout(() => setFinalJustActivated(false), 1400)
    }
    wasFinalActiveRef.current = finalActive
  }, [finalActive])

  useEffect(() => {
    // Clean up any running interval / timeout on unmount.
    return () => {
      clearInterval(intervalRef.current)
      clearTimeout(finalPulseTimeoutRef.current)
    }
  }, [])

  function activateSiren() {
    if (status === 'active') return // already running — never stack intervals
    clearInterval(intervalRef.current)
    setStatus('active')
    setRemaining(TOTAL_SECONDS)
    wasFinalActiveRef.current = false

    intervalRef.current = setInterval(() => {
      setRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(intervalRef.current)
          setStatus('complete')
          return 0
        }
        return prev - 1
      })
    }, 1000)
  }

  function resetEmergency() {
    clearInterval(intervalRef.current)
    clearTimeout(finalPulseTimeoutRef.current)
    wasFinalActiveRef.current = false
    setFinalJustActivated(false)
    setStatus('idle')
    setRemaining(TOTAL_SECONDS)
  }

  const firstThreeSteps = emergencyTimeline.slice(0, 3)
  const finalStep = emergencyTimeline[emergencyTimeline.length - 1]

  return (
    <PatientLayout>
      <div className="space-y-6">
        {/* Header / Siren control */}
        <Card
          className={`transition-colors duration-300 ${
            status === 'idle'
              ? 'border-slate-100'
              : status === 'complete'
              ? 'border-emerald-100 bg-emerald-50'
              : 'border-rose-100 bg-rose-50'
          }`}
        >
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span
                className={`flex h-12 w-12 items-center justify-center rounded-full text-white transition-colors duration-300 ${
                  status === 'complete' ? 'bg-emerald-600' : 'bg-rose-600'
                }`}
              >
                <Siren size={22} />
              </span>
              <div>
                <p className={`text-lg font-bold ${status === 'complete' ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {status === 'idle' && 'Emergency Protocol Ready'}
                  {status === 'active' && 'Emergency Response Activated'}
                  {status === 'complete' && 'Emergency Response Complete'}
                </p>
                <p className={`text-sm ${status === 'complete' ? 'text-emerald-600' : 'text-rose-600'}`}>
                  {status === 'idle' && 'Press the siren button below if you need immediate help.'}
                  {status === 'active' && 'Contacts notified · Help en route'}
                  {status === 'complete' && 'Your emergency contacts and care team have been alerted.'}
                </p>
              </div>
            </div>

            {status !== 'idle' && (
              <div className="rounded-xl bg-white px-4 py-2 text-center">
                <p className="text-xs text-slate-400">{status === 'complete' ? 'Final Time' : 'Time Remaining'}</p>
                <p
                  className={`text-lg font-bold tabular-nums ${
                    status === 'complete' ? 'text-emerald-600' : 'text-rose-600'
                  }`}
                  aria-live="polite"
                >
                  {formatCountdown(remaining)}
                </p>
              </div>
            )}
          </div>

          {status === 'idle' && (
            <div className="mt-5 flex flex-col items-center gap-3 rounded-2xl border border-dashed border-rose-200 bg-white/60 py-8">
              <button
                onClick={activateSiren}
                aria-label="Activate emergency siren"
                className="group relative flex h-24 w-24 items-center justify-center rounded-full bg-rose-600 text-white shadow-lg shadow-rose-200 transition-transform duration-150 hover:scale-105 hover:bg-rose-700 active:scale-95 focus:outline-none focus-visible:ring-4 focus-visible:ring-rose-300"
              >
                <span className="absolute inset-0 animate-ring-expand rounded-full bg-rose-500/40" />
                <Siren size={34} className="relative" />
              </button>
              <p className="text-sm font-bold uppercase tracking-wide text-rose-600">Activate Siren</p>
              <p className="max-w-xs text-center text-xs text-slate-500">
                This will immediately notify your care team and emergency contacts.
              </p>
            </div>
          )}

          {status !== 'idle' && (
            <div className="mt-4 flex justify-end">
              <button
                onClick={resetEmergency}
                className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-400"
              >
                <RotateCcw size={13} />
                Reset Emergency
              </button>
            </div>
          )}
        </Card>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-semibold text-ink">Emergency Status Timeline</h3>
              <Badge tone={status === 'complete' ? 'success' : status === 'active' ? 'alert' : 'default'} dot>
                {status === 'idle' && 'Standing By'}
                {status === 'active' && 'Ambulance En Route'}
                {status === 'complete' && 'Response Complete'}
              </Badge>
            </div>

            <div>
              {firstThreeSteps.map((step, i) => (
                <EmergencyStep
                  key={step.title}
                  title={step.title}
                  detail={step.detail}
                  active={status !== 'idle' && elapsed >= STAGE_THRESHOLDS[i]}
                  isLast={false}
                />
              ))}
              <EmergencyStep
                title={finalStep.title}
                detail={status === 'complete' ? 'Emergency team has arrived and confirmed response complete.' : finalStep.detail}
                active={finalActive}
                pulse={finalJustActivated}
                isLast
              />
            </div>

            <div className="mt-4 rounded-xl bg-slate-900 p-4 text-white">
              <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-rose-300">
                <MapPin size={14} /> Broadcasting Live Location
              </p>
              <p className="mt-1 text-sm">142 Oakwood Drive, Sector 4</p>
              <p className="mt-1 text-xs text-slate-400">
                {status === 'complete' ? 'Emergency team has arrived.' : 'Ambulance is 4 minutes away'}
              </p>
            </div>
          </Card>

          <div className="space-y-6">
            <Card>
              <h3 className="font-semibold text-ink">Critical Vitals ID</h3>
              <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-xs text-slate-400">Week</p>
                  <p className="font-semibold text-ink">{criticalVitals.week}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400">Blood Group</p>
                  <p className="font-semibold text-ink">{criticalVitals.bloodGroup}</p>
                </div>
              </div>
              <div className="mt-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Allergies</p>
                <div className="mt-1 flex flex-wrap gap-2">
                  {criticalVitals.allergies.map((a) => (
                    <Badge key={a} tone="alert">
                      {a}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="mt-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                  Medical Conditions
                </p>
                <p className="mt-1 text-sm text-slate-600">{criticalVitals.conditions.join(', ')}</p>
              </div>
              <div className="mt-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                  Current Medicines
                </p>
                <p className="mt-1 text-sm text-slate-600">{criticalVitals.medicines.join(', ')}</p>
              </div>
            </Card>

            <Card>
              <h3 className="mb-3 font-semibold text-ink">Quick Dial</h3>
              <div className="space-y-3">
                {quickDial.map((contact) => (
                  <div key={contact.name} className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-semibold text-ink">{contact.name}</p>
                      <p className="text-xs text-slate-400">{contact.role}</p>
                    </div>
                    <button
                      aria-label={`Call ${contact.name}`}
                      className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-600 text-white transition-transform duration-150 hover:bg-brand-700 active:scale-90"
                    >
                      <Phone size={15} />
                    </button>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </PatientLayout>
  )
}
