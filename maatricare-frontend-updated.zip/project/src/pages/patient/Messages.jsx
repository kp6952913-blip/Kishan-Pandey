import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Search, Send, MessageSquareText } from 'lucide-react'
import PatientLayout from '../../layouts/PatientLayout.jsx'
import Card from '../../components/common/Card.jsx'
import Badge from '../../components/common/Badge.jsx'
import ConversationItem from '../../components/patient/ConversationItem.jsx'
import MessageBubble from '../../components/patient/MessageBubble.jsx'
import { careTeam, conversations, chatMessagesByConversation } from '../../data/mockData.js'

function formatTime(date) {
  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
}

export default function Messages() {
  const [activeName, setActiveName] = useState(conversations[0]?.name ?? null)
  const [search, setSearch] = useState('')
  const [draft, setDraft] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [messagesByConv, setMessagesByConv] = useState(chatMessagesByConversation)
  const [justSent, setJustSent] = useState(false)
  const scrollRef = useRef(null)
  const textareaRef = useRef(null)

  const activeConversation = conversations.find((c) => c.name === activeName) ?? null
  const activeMessages = activeName ? messagesByConv[activeName] ?? [] : []
  const activeMember = careTeam.find((m) => m.name === activeName)

  const filteredConversations = useMemo(() => {
    const q = search.trim().toLowerCase()
    if (!q) return conversations
    return conversations.filter(
      (c) => c.name.toLowerCase().includes(q) || c.preview.toLowerCase().includes(q)
    )
  }, [search])

  // Brief, lightweight loading state whenever the selected conversation changes.
  useEffect(() => {
    if (!activeName) return
    setIsLoading(true)
    const t = setTimeout(() => setIsLoading(false), 280)
    return () => clearTimeout(t)
  }, [activeName])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [activeMessages, isLoading])

  function handleSelectConversation(name) {
    if (name === activeName) return
    setActiveName(name)
  }

  function handleSend() {
    const text = draft.trim()
    if (!text || !activeName) return

    setMessagesByConv((prev) => ({
      ...prev,
      [activeName]: [
        ...(prev[activeName] ?? []),
        { from: 'me', time: formatTime(new Date()), text, read: false },
      ],
    }))
    setDraft('')
    setJustSent(true)
    setTimeout(() => setJustSent(false), 320)
    textareaRef.current?.focus()
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  return (
    <PatientLayout>
      <div className="space-y-6">
        <div>
          <h1 className="font-serif text-3xl font-bold text-ink">Messages</h1>
          <p className="mt-2 text-slate-500">
            Conversations are end-to-end encrypted and stored securely in your medical record.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card padded={false} className="p-4 lg:col-span-1">
            <div className="relative mb-4">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search messages..."
                className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-sm transition-colors focus:border-brand-400 focus:bg-white focus:outline-none"
              />
            </div>

            <p className="mb-2 px-1 text-xs font-semibold uppercase tracking-wide text-slate-400">
              Care Team Online
            </p>
            <div className="mb-4 flex gap-4 overflow-x-auto px-1 pb-2 scrollbar-thin">
              {careTeam.map((member) => (
                <div key={member.name} className="flex flex-col items-center gap-1 text-center">
                  <span className="relative flex h-10 w-10 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">
                    {member.name.split(' ').map((n) => n[0]).slice(0, 2).join('')}
                    {member.online && (
                      <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-white bg-emerald-500" />
                    )}
                  </span>
                  <span className="max-w-[64px] truncate text-[11px] text-slate-500">
                    {member.name.split(' ')[0]}
                  </span>
                </div>
              ))}
            </div>

            <div className="space-y-1 max-h-[420px] overflow-y-auto scrollbar-thin lg:max-h-none">
              {filteredConversations.length === 0 && (
                <p className="px-2 py-6 text-center text-sm text-slate-400">No conversations match your search.</p>
              )}
              {filteredConversations.map((c) => (
                <ConversationItem
                  key={c.name}
                  {...c}
                  active={c.name === activeName}
                  onClick={() => handleSelectConversation(c.name)}
                />
              ))}
            </div>
          </Card>

          <Card padded={false} className="flex h-[32rem] flex-col lg:col-span-2">
            {activeConversation ? (
              <>
                <div className="flex items-center justify-between border-b border-slate-100 p-4">
                  <div>
                    <p className="font-semibold text-ink">{activeConversation.name}</p>
                    <Badge tone={activeMember?.online ? 'success' : 'default'} dot>
                      {activeMember?.online ? 'Active Now' : activeMember?.role ?? 'Offline'}
                    </Badge>
                  </div>
                  <span className="text-xs text-slate-400">Today</span>
                </div>

                <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto p-4 scrollbar-thin">
                  {isLoading ? (
                    <div className="space-y-4">
                      {[0, 1, 2].map((i) => (
                        <div key={i} className={`flex ${i % 2 ? 'justify-end' : 'justify-start'}`}>
                          <div className="h-12 w-2/3 max-w-xs animate-pulse rounded-2xl bg-slate-100" />
                        </div>
                      ))}
                    </div>
                  ) : activeMessages.length === 0 ? (
                    <div className="flex h-full flex-col items-center justify-center gap-2 text-center text-slate-400">
                      <MessageSquareText size={32} className="text-slate-300" />
                      <p className="text-sm font-medium text-slate-500">No messages yet</p>
                      <p className="max-w-[220px] text-xs">
                        Say hello — your message will be sent securely to {activeConversation.name}.
                      </p>
                    </div>
                  ) : (
                    activeMessages.map((msg, i) => <MessageBubble key={i} {...msg} />)
                  )}
                </div>

                <div className="flex items-end gap-3 border-t border-slate-100 p-4">
                  <textarea
                    ref={textareaRef}
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    onKeyDown={handleKeyDown}
                    rows={1}
                    placeholder="Type a message..."
                    className="max-h-32 flex-1 resize-none rounded-xl border border-slate-200 px-4 py-2.5 text-sm transition-colors focus:border-brand-400 focus:outline-none"
                  />
                  <button
                    onClick={handleSend}
                    disabled={!draft.trim()}
                    aria-label="Send message"
                    className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl transition-all duration-150 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 ${
                      draft.trim()
                        ? 'bg-brand-600 text-white hover:bg-brand-700 active:scale-90'
                        : 'cursor-not-allowed bg-slate-100 text-slate-300'
                    }`}
                  >
                    <Send size={16} className={justSent ? 'animate-send-fly' : ''} />
                  </button>
                </div>
              </>
            ) : (
              <div className="flex h-full flex-col items-center justify-center gap-2 text-center text-slate-400">
                <MessageSquareText size={32} className="text-slate-300" />
                <p className="text-sm font-medium text-slate-500">Select a conversation to get started</p>
              </div>
            )}
          </Card>
        </div>
      </div>
    </PatientLayout>
  )
}
