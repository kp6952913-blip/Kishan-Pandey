import React from 'react'
import { Routes, Route } from 'react-router-dom'

import Home from './pages/Home.jsx' // Holds Hero + Stats + Features
import Benefits from './pages/Benefits.jsx' // Dedicated Benefits Page
import FaqPage from './pages/FaqPage.jsx' // Dedicated FAQ Page
import Login from './pages/Login.jsx'

import StaffDashboard from './pages/staff/StaffDashboard.jsx'
import StaffPatients from './pages/staff/StaffPatients.jsx'
import StaffAppointments from './pages/staff/StaffAppointments.jsx'
import StaffReports from './pages/staff/StaffReports.jsx'
import StaffEmergency from './pages/staff/StaffEmergency.jsx'

import PatientHome from './pages/patient/PatientHome.jsx'
import GrowthJourney from './pages/patient/GrowthJourney.jsx'
import PatientProfile from './pages/patient/PatientProfile.jsx'
import Reminders from './pages/patient/Reminders.jsx'
import HealthTracker from './pages/patient/HealthTracker.jsx'
import Appointments from './pages/patient/Appointments.jsx'
import MedicalReports from './pages/patient/MedicalReports.jsx'
import Messages from './pages/patient/Messages.jsx'
import SOSEmergency from './pages/patient/SOSEmergency.jsx'

import { AppDataProvider } from './context/AppDataContext.jsx'
import { StaffRoute, PatientRoute } from './components/auth/ProtectedRoute.jsx'

export default function App() {
  return (
    <AppDataProvider>
      <Routes>
        {/* Public Marketing Site Routes */}
        <Route path="/" element={<Home />} />
        <Route path="/benefits" element={<Benefits />} />
        <Route path="/faq" element={<FaqPage />} />
        <Route path="/login" element={<Login />} />

        {/* Staff / Hospital Portal — protected */}
        <Route path="/staff" element={<StaffRoute><StaffDashboard /></StaffRoute>} />
        <Route path="/staff/patients" element={<StaffRoute><StaffPatients /></StaffRoute>} />
        <Route path="/staff/delivery" element={<StaffRoute><StaffDashboard /></StaffRoute>} />
        <Route path="/staff/reports" element={<StaffRoute><StaffReports /></StaffRoute>} />
        <Route path="/staff/emergency" element={<StaffRoute><StaffEmergency /></StaffRoute>} />
        <Route path="/staff/appointments" element={<StaffRoute><StaffAppointments /></StaffRoute>} />

        {/* Patient / "MaatriCare Me" Portal — protected */}
        <Route path="/portal" element={<PatientRoute><PatientHome /></PatientRoute>} />
        <Route path="/portal/baby" element={<PatientRoute><GrowthJourney /></PatientRoute>} />
        <Route path="/portal/profile" element={<PatientRoute><PatientProfile /></PatientRoute>} />
        <Route path="/portal/reminders" element={<PatientRoute><Reminders /></PatientRoute>} />
        <Route path="/portal/health" element={<PatientRoute><HealthTracker /></PatientRoute>} />
        <Route path="/portal/appointments" element={<PatientRoute><Appointments /></PatientRoute>} />
        <Route path="/portal/reports" element={<PatientRoute><MedicalReports /></PatientRoute>} />
        <Route path="/portal/messages" element={<PatientRoute><Messages /></PatientRoute>} />
        <Route path="/portal/sos" element={<PatientRoute><SOSEmergency /></PatientRoute>} />
      </Routes>
    </AppDataProvider>
  )
}