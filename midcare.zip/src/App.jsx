import React from 'react'
import { Routes, Route } from 'react-router-dom'

import Home from './pages/Home.jsx'
import Login from './pages/Login.jsx'

import StaffDashboard from './pages/staff/StaffDashboard.jsx'
import StaffPatients from './pages/staff/StaffPatients.jsx'

import PatientHome from './pages/patient/PatientHome.jsx'
import GrowthJourney from './pages/patient/GrowthJourney.jsx'
import PatientProfile from './pages/patient/PatientProfile.jsx'
import Reminders from './pages/patient/Reminders.jsx'
import HealthTracker from './pages/patient/HealthTracker.jsx'
import Appointments from './pages/patient/Appointments.jsx'
import Messages from './pages/patient/Messages.jsx'
import SOSEmergency from './pages/patient/SOSEmergency.jsx'

export default function App() {
  return (
    <Routes>
      {/* Public marketing site */}
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />

      {/* Staff / hospital portal */}
      <Route path="/staff" element={<StaffDashboard />} />
      <Route path="/staff/patients" element={<StaffPatients />} />
      {/* EMR, Vaccinations, Delivery, Reports, Emergency reuse the dashboard shell for now */}
      <Route path="/staff/emr" element={<StaffDashboard />} />
      <Route path="/staff/vaccinations" element={<StaffDashboard />} />
      <Route path="/staff/delivery" element={<StaffDashboard />} />
      <Route path="/staff/reports" element={<StaffDashboard />} />
      <Route path="/staff/emergency" element={<StaffDashboard />} />
      <Route path="/staff/appointments" element={<StaffDashboard />} />

      {/* Patient / "MidCare Me" portal */}
      <Route path="/portal" element={<PatientHome />} />
      <Route path="/portal/baby" element={<GrowthJourney />} />
      <Route path="/portal/profile" element={<PatientProfile />} />
      <Route path="/portal/reminders" element={<Reminders />} />
      <Route path="/portal/health" element={<HealthTracker />} />
      <Route path="/portal/appointments" element={<Appointments />} />
      <Route path="/portal/messages" element={<Messages />} />
      <Route path="/portal/sos" element={<SOSEmergency />} />
    </Routes>
  )
}
