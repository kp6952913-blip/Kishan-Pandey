import React from 'react'
import { Download, Plus } from 'lucide-react'
import StaffLayout from '../../layouts/StaffLayout.jsx'
import Button from '../../components/common/Button.jsx'
import Card from '../../components/common/Card.jsx'
import KpiCard from '../../components/staff/KpiCard.jsx'
import RegistrationChart from '../../components/staff/RegistrationChart.jsx'
import AppointmentsDonut from '../../components/staff/AppointmentsDonut.jsx'
import RegistrationRow from '../../components/staff/RegistrationRow.jsx'
import UrgentTaskCard from '../../components/staff/UrgentTaskCard.jsx'
import { staffKpis, recentRegistrations, urgentTasks } from '../../data/mockData.js'

export default function StaffDashboard() {
  return (
    <StaffLayout>
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="font-serif text-2xl font-bold text-ink sm:text-3xl">Welcome back, Dr. Wilson.</h1>
          <p className="mt-1 max-w-xl text-sm text-slate-500">
            Here's an overview of the hospital's maternal care metrics for today. You have{' '}
            <span className="font-semibold text-rose-600">12 high-risk alerts</span> requiring your attention.
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="secondary" icon={Download} iconPosition="left">
            Export Daily Report
          </Button>
          <Button icon={Plus} iconPosition="left">
            New Patient
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {staffKpis.map((kpi) => (
          <KpiCard key={kpi.label} {...kpi} />
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <RegistrationChart />
        <AppointmentsDonut />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="font-semibold text-ink">Recent Registrations</h3>
            <button className="text-sm font-semibold text-brand-600">View All</button>
          </div>
          <div className="divide-y divide-slate-100">
            {recentRegistrations.map((reg) => (
              <RegistrationRow key={reg.id} {...reg} />
            ))}
          </div>
        </Card>

        <Card>
          <h3 className="mb-3 flex items-center gap-2 font-semibold text-rose-600">Urgent Tasks</h3>
          <div className="space-y-3">
            {urgentTasks.map((task) => (
              <UrgentTaskCard key={task.title} {...task} />
            ))}
          </div>
        </Card>
      </div>
    </div>
    </StaffLayout>
  )
}
