import React from 'react'
import { Download, Plus, ChevronLeft, ChevronRight } from 'lucide-react'
import StaffLayout from '../../layouts/StaffLayout.jsx'
import Button from '../../components/common/Button.jsx'
import Card from '../../components/common/Card.jsx'
import PatientFilters from '../../components/staff/PatientFilters.jsx'
import PatientRow from '../../components/staff/PatientRow.jsx'
import { patients } from '../../data/mockData.js'

export default function StaffPatients() {
  return (
    <StaffLayout>
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="font-serif text-2xl font-bold text-ink sm:text-3xl">Patients</h1>
          <p className="mt-1 max-w-xl text-sm text-slate-500">
            Manage and monitor your patient load. Review critical statuses and upcoming appointments.
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="secondary" icon={Download} iconPosition="left">
            Export List
          </Button>
          <Button icon={Plus} iconPosition="left">
            Add Patient
          </Button>
        </div>
      </div>

      <Card>
        <PatientFilters />
      </Card>

      <Card padded={false} className="overflow-x-auto p-5 sm:p-6">
        <table className="w-full min-w-[720px] text-left">
          <thead>
            <tr className="border-b border-slate-100 text-xs font-semibold uppercase tracking-wide text-slate-400">
              <th className="py-2 pr-4">Patient Name</th>
              <th className="py-2 pr-4">Week</th>
              <th className="py-2 pr-4">Risk Level</th>
              <th className="py-2 pr-4">Last Checkup</th>
              <th className="py-2 pr-4">Next Appt</th>
              <th className="py-2 text-right">Status / Action</th>
            </tr>
          </thead>
          <tbody>
            {patients.map((patient) => (
              <PatientRow key={patient.id} patient={patient} />
            ))}
          </tbody>
        </table>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-sm text-slate-500">
          <p>Showing 1 to {patients.length} of 124 patients</p>
          <div className="flex items-center gap-2">
            <button className="rounded-lg border border-slate-200 p-1.5 text-slate-400">
              <ChevronLeft size={16} />
            </button>
            <button className="rounded-lg bg-brand-600 px-3 py-1.5 text-white">1</button>
            <button className="rounded-lg px-3 py-1.5 text-slate-600 hover:bg-slate-50">2</button>
            <button className="rounded-lg px-3 py-1.5 text-slate-600 hover:bg-slate-50">3</button>
            <span>...</span>
            <button className="rounded-lg border border-slate-200 p-1.5 text-slate-400">
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      </Card>
    </div>
    </StaffLayout>
  )
}
