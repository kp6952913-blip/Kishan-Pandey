import React from 'react'
import MainLayout from '../layouts/MainLayout.jsx'
import Hero from '../components/landing/Hero.jsx'
import StatsBar from '../components/landing/StatsBar.jsx'
import FeaturesSection from '../components/landing/FeaturesSection.jsx'

export default function Home() {
  return (
    <MainLayout>
      <Hero />
      <StatsBar />
      <FeaturesSection />
    </MainLayout>
  )
}
