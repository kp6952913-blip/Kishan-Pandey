import React from 'react'
import PatientLayout from '../../layouts/PatientLayout.jsx'
import DashboardHero from '../../components/patient/DashboardHero.jsx'
import GlanceCard from '../../components/patient/GlanceCard.jsx'
import QuickAccessTile from '../../components/patient/QuickAccessTile.jsx'
import { atAGlance, quickAccess } from '../../data/mockData.js'

export default function PatientHome() {
  return (
    <PatientLayout>
      <div className="space-y-8">
        <DashboardHero />

        <section>
          <h3 className="mb-4 font-semibold text-ink">At a Glance</h3>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {atAGlance.map((item) => (
              <GlanceCard key={item.label} {...item} />
            ))}
          </div>
        </section>

        <section>
          <h3 className="mb-4 font-semibold text-ink">Quick Access</h3>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {quickAccess.map((item) => (
              <QuickAccessTile key={item.label} {...item} />
            ))}
          </div>
        </section>
      </div>
    </PatientLayout>
  )
}
