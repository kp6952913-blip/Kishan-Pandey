import React, { useState } from 'react'
import { Video, RotateCw, MapPin } from 'lucide-react'
import PatientLayout from '../../layouts/PatientLayout.jsx'
import Card from '../../components/common/Card.jsx'
import Button from '../../components/common/Button.jsx'
import Badge from '../../components/common/Badge.jsx'
import AppointmentSummaryCard from '../../components/patient/AppointmentSummaryCard.jsx'
import CalendarGrid from '../../components/patient/CalendarGrid.jsx'
import {
  appointmentSummary,
  calendarMonth,
  nextAppointment,
  recentNotes,
} from '../../data/mockData.js'

const tabs = ['Upcoming', 'Past', 'Cancelled']

export default function Appointments() {
  const [tab, setTab] = useState('Upcoming')

  return (
    <PatientLayout showSearch>
      <div className="space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="font-serif text-3xl font-bold text-ink">Appointments</h1>
            <p className="mt-2 max-w-xl text-slate-500">
              Manage your upcoming checkups, review past visits, and stay on top of your maternal
              health schedule.
            </p>
          </div>
          <Button>Book Visit</Button>
        </div>

        <div className="flex flex-wrap gap-2">
          {tabs.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`rounded-full px-4 py-1.5 text-sm font-semibold transition-colors ${
                tab === t ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-500'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {appointmentSummary.map((item) => (
            <AppointmentSummaryCard key={item.label} {...item} />
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <CalendarGrid label={calendarMonth.label} days={calendarMonth.days} />

            <div className="mt-6 border-t border-slate-100 pt-6">
              <h3 className="mb-3 font-semibold text-ink">Recent Medical Notes</h3>
              {recentNotes.map((note) => (
                <div key={note.title} className="rounded-xl border border-slate-100 p-4">
                  <div className="flex items-center gap-2">
                    <Badge tone="success">{note.status}</Badge>
                    <span className="text-xs text-slate-400">• {note.date}</span>
                  </div>
                  <p className="mt-2 font-semibold text-ink">{note.title}</p>
                  <p className="text-xs text-slate-400">{note.provider}</p>
                  <p className="mt-2 text-sm text-slate-500">{note.note}</p>
                  <button className="mt-2 text-xs font-semibold text-brand-600">{note.attachment}</button>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-ink">Next Appointment</h3>
              <span className="text-xs font-semibold text-brand-600">{nextAppointment.eta}</span>
            </div>
            <p className="mt-3 font-semibold text-ink">{nextAppointment.title}</p>
            <p className="text-sm text-slate-500">{nextAppointment.provider}</p>
            <p className="mt-1 text-sm font-medium text-brand-600">{nextAppointment.time}</p>

            <div className="mt-4 space-y-2">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                Preparation Checklist
              </p>
              {nextAppointment.checklist.map((item) => (
                <label key={item} className="flex items-center gap-2 text-sm text-slate-600">
                  <input type="checkbox" className="rounded border-slate-300 text-brand-600" />
                  {item}
                </label>
              ))}
            </div>

            <div className="mt-4 flex gap-2">
              <Button size="sm" icon={Video} iconPosition="left" className="flex-1">
                Join Video Call
              </Button>
              <Button size="sm" variant="secondary" icon={RotateCw} iconPosition="left">
                Reschedule
              </Button>
            </div>

            <div className="mt-5 rounded-xl bg-slate-50 p-3">
              <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-slate-400">
                <MapPin size={14} /> Location
              </p>
              <p className="mt-1 text-sm font-semibold text-ink">{nextAppointment.location.name}</p>
              <p className="text-xs text-slate-500">{nextAppointment.location.address}</p>
              <button className="mt-2 text-xs font-semibold text-brand-600">Open in Maps</button>
            </div>
          </Card>
        </div>
      </div>
    </PatientLayout>
  )
}
