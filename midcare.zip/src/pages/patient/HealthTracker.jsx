import React from 'react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import { Play } from 'lucide-react'
import PatientLayout from '../../layouts/PatientLayout.jsx'
import Card from '../../components/common/Card.jsx'
import Button from '../../components/common/Button.jsx'
import Badge from '../../components/common/Badge.jsx'
import DailyStatTile from '../../components/patient/DailyStatTile.jsx'
import { healthToday, weightChart, bpTrend, doctorNote } from '../../data/mockData.js'

export default function HealthTracker() {
  return (
    <PatientLayout>
      <div className="space-y-6">
        <div>
          <h1 className="font-serif text-3xl font-bold text-ink">Health Tracker</h1>
          <p className="mt-2 max-w-2xl text-slate-500">
            Monitor your vital statistics, track daily symptoms, and log your baby's movements to
            ensure a healthy progression through Week 24.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <h3 className="font-semibold text-ink">Daily Check-in</h3>
              <Badge tone="brand">Mood: {healthToday.mood}</Badge>
            </div>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <DailyStatTile label="Current Weight" value={healthToday.weight} />
              <DailyStatTile label="Blood Pressure" value={healthToday.bloodPressure} />
              <DailyStatTile label="Heart Rate" value={healthToday.heartRate} />
              <DailyStatTile label="Baby Movements" value={healthToday.babyMovements} />
            </div>
            <div className="mt-4 flex items-center justify-between rounded-xl bg-brand-50 p-4">
              <div>
                <p className="text-sm font-semibold text-ink">Baby Movements</p>
                <p className="text-xs text-slate-500">Start a kick counter session</p>
              </div>
              <Button size="sm" icon={Play} iconPosition="left">
                Log Kicks
              </Button>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div className="rounded-xl bg-slate-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Energy Level</p>
                <p className="mt-1 text-lg font-bold text-ink">{healthToday.energyLevel} / 10</p>
              </div>
              <div className="rounded-xl bg-slate-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Sleep Quality</p>
                <p className="mt-1 text-lg font-bold text-ink">{healthToday.sleepQuality}</p>
              </div>
            </div>
            <div className="mt-4">
              <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                Today's Symptoms
              </p>
              <div className="flex flex-wrap gap-2">
                {healthToday.symptoms.map((s) => (
                  <Badge key={s} tone="default">
                    {s}
                  </Badge>
                ))}
              </div>
            </div>
            <Button className="mt-5 w-full">Update Daily Log</Button>
          </Card>

          <Card>
            <p className="text-xs font-semibold uppercase tracking-wide text-brand-600">Dr. Chen's Note</p>
            <p className="mt-2 text-sm text-slate-600">"{doctorNote}"</p>
            <div className="mt-6 border-t border-slate-100 pt-4">
              <p className="text-sm font-semibold text-ink">Week 24 Insights</p>
              <p className="mt-1 text-sm text-slate-500">
                Your baby is now about the size of an ear of corn. You might notice their kicks
                becoming stronger and more frequent this week.
              </p>
            </div>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <h3 className="font-semibold text-ink">Weight Progression</h3>
            <p className="text-sm text-slate-400">Tracked against healthy pregnancy guidelines</p>
            <div className="mt-4 h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weightChart} margin={{ left: -20, right: 10, top: 10 }}>
                  <CartesianGrid vertical={false} stroke="#eef1f8" />
                  <XAxis dataKey="week" tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                  <YAxis domain={[125, 155]} tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                  <Tooltip />
                  <Line type="monotone" dataKey="lbs" stroke="#2f66f5" strokeWidth={2.5} dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card>
            <h3 className="font-semibold text-ink">BP Trends</h3>
            <p className="text-sm text-slate-400">Systolic reading, last 7 days</p>
            <div className="mt-4 h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={bpTrend} margin={{ left: -20, right: 10, top: 10 }}>
                  <CartesianGrid vertical={false} stroke="#eef1f8" />
                  <XAxis dataKey="day" tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                  <YAxis domain={[100, 130]} tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                  <Tooltip />
                  <Line type="monotone" dataKey="systolic" stroke="#2fe0c0" strokeWidth={2.5} dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>
      </div>
    </PatientLayout>
  )
}
