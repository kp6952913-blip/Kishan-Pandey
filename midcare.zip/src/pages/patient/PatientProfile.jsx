import React from 'react'
import { Edit3, MessageCircle, Upload, RotateCw } from 'lucide-react'
import PatientLayout from '../../layouts/PatientLayout.jsx'
import Card from '../../components/common/Card.jsx'
import Button from '../../components/common/Button.jsx'
import Badge from '../../components/common/Badge.jsx'
import VitalCard from '../../components/patient/VitalCard.jsx'
import TimelineItem from '../../components/patient/TimelineItem.jsx'
import { vitals, medicalTimeline, immunizations, prescriptions } from '../../data/mockData.js'

export default function PatientProfile() {
  return (
    <PatientLayout showSearch>
      <div className="space-y-6">
        <Card className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <span className="flex h-16 w-16 items-center justify-center rounded-full bg-brand-100 text-lg font-bold text-brand-700">
              SJ
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-ink">Sarah Jenkins</h1>
                <Badge tone="default">Patient ID: MC-84920</Badge>
              </div>
              <p className="mt-1 text-sm text-slate-500">28 Years Old · O Positive · EDD: Oct 15, 2024</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Button variant="secondary" icon={Edit3} iconPosition="left" size="sm">
              Edit Profile
            </Button>
            <Button icon={MessageCircle} iconPosition="left" size="sm">
              Message
            </Button>
          </div>
        </Card>

        <Card>
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-sm font-semibold text-slate-500">Pregnancy Progress</p>
              <p className="mt-1 text-lg font-bold text-ink">Week 24 of 40 · Trimester 2</p>
            </div>
            <div className="flex gap-6 text-sm">
              <div>
                <p className="text-xs text-slate-400">Primary OB/GYN</p>
                <p className="font-semibold text-ink">Dr. Emily Chen</p>
              </div>
              <div>
                <p className="text-xs text-slate-400">Care Midwife</p>
                <p className="font-semibold text-ink">Sarah Jenkins</p>
              </div>
            </div>
          </div>
          <div className="mt-4 h-2 w-full overflow-hidden rounded-full bg-slate-100">
            <div className="h-full rounded-full bg-brand-600" style={{ width: '60%' }} />
          </div>
        </Card>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="space-y-6 lg:col-span-2">
            <Card>
              <div className="mb-4 flex items-center justify-between">
                <h3 className="font-semibold text-ink">Current Vitals</h3>
                <p className="text-xs text-slate-400">Last updated: Today, 09:30 AM</p>
              </div>
              <div className="grid gap-4 sm:grid-cols-3">
                {vitals.map((v) => (
                  <VitalCard key={v.label} {...v} />
                ))}
              </div>
            </Card>

            <Card>
              <div className="mb-4 flex items-center justify-between">
                <h3 className="font-semibold text-ink">Laboratory & Imaging</h3>
                <Button variant="secondary" size="sm" icon={Upload} iconPosition="left">
                  Upload Report
                </Button>
              </div>
              <p className="mb-2 text-sm font-semibold text-slate-500">Latest Reports</p>
              <div className="divide-y divide-slate-100">
                <div className="flex items-center justify-between py-2 text-sm">
                  <span className="text-ink">Glucose Tolerance Test</span>
                  <span className="text-xs text-slate-400">Sep 01, 2024 · Sent by Dr. Chen</span>
                </div>
                <div className="flex items-center justify-between py-2 text-sm">
                  <span className="text-ink">Complete Blood Count (CBC)</span>
                  <span className="text-xs text-slate-400">Aug 12, 2024 · Sent by Lab</span>
                </div>
              </div>
              <button className="mt-3 text-sm font-semibold text-brand-600">View All Reports</button>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <h3 className="mb-4 font-semibold text-ink">Medical Timeline</h3>
              <div className="space-y-6">
                {medicalTimeline.map((item, i) => (
                  <TimelineItem key={item.title} {...item} isLast={i === medicalTimeline.length - 1} />
                ))}
              </div>
              <button className="mt-4 text-sm font-semibold text-brand-600">Load Older Records</button>
            </Card>

            <Card>
              <h3 className="mb-3 font-semibold text-ink">Immunization</h3>
              <div className="space-y-3">
                {immunizations.map((item) => (
                  <div key={item.name} className="flex items-center justify-between text-sm">
                    <span className="font-medium text-ink">{item.name}</span>
                    <span className="text-xs text-slate-400">{item.status}</span>
                  </div>
                ))}
              </div>
            </Card>

            <Card>
              <h3 className="mb-3 font-semibold text-ink">Active Prescriptions</h3>
              <div className="space-y-4">
                {prescriptions.map((rx) => (
                  <div key={rx.name} className="rounded-xl bg-slate-50 p-3">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-semibold text-ink">{rx.name}</p>
                      <Badge tone="brand">{rx.freq}</Badge>
                    </div>
                    <p className="mt-1 text-xs text-slate-500">{rx.dosage}</p>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="text-xs text-slate-400">Refills: {rx.refills}</span>
                      <button className="flex items-center gap-1 text-xs font-semibold text-brand-600">
                        <RotateCw size={12} /> Request Refill
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </PatientLayout>
  )
}
