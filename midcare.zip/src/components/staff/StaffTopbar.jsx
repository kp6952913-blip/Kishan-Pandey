import React from 'react'
import { Search, Bell, UserRound } from 'lucide-react'

export default function StaffTopbar({ user = { name: 'Dr. Sarah Wilson', role: 'Obstetrician' } }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-slate-100 bg-white px-4 py-4 sm:px-6 lg:px-8">
      <div className="relative w-full max-w-md">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          placeholder="Search patients or records..."
          className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 pl-9 pr-3 text-sm text-slate-600 placeholder:text-slate-400 focus:border-brand-400 focus:outline-none"
        />
      </div>

      <div className="flex items-center gap-4">
        <button className="relative text-slate-500 hover:text-brand-600">
          <Bell size={20} />
          <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-rose-500" />
        </button>
        <div className="hidden text-right sm:block">
          <p className="text-sm font-semibold text-ink">{user.name}</p>
          <p className="text-xs text-slate-400">{user.role}</p>
        </div>
        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-600 text-white">
          <UserRound size={16} />
        </span>
      </div>
    </div>
  )
}
