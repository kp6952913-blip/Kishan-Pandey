import React from 'react'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import Card from '../common/Card.jsx'
import { registrationTrend } from '../../data/mockData.js'

export default function RegistrationChart() {
  return (
    <Card className="lg:col-span-2">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-ink">Registration Trends</h3>
          <p className="text-sm text-slate-400">Monthly patient onboarding over the last 6 months</p>
        </div>
        <span className="rounded-lg bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-500">
          Last 6 Months
        </span>
      </div>
      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={registrationTrend} margin={{ left: -20, right: 10, top: 10 }}>
            <defs>
              <linearGradient id="regFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#2f66f5" stopOpacity={0.25} />
                <stop offset="100%" stopColor="#2f66f5" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} stroke="#eef1f8" />
            <XAxis dataKey="month" tickLine={false} axisLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
            <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
            <Tooltip />
            <Area type="monotone" dataKey="patients" stroke="#2f66f5" strokeWidth={2.5} fill="url(#regFill)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </Card>
  )
}
