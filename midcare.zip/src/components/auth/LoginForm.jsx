import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Mail, Lock, Eye, EyeOff, ArrowRight, ShieldCheck } from 'lucide-react'
import Button from '../common/Button.jsx'

export default function LoginForm() {
  const [role, setRole] = useState('couple')
  const [showPassword, setShowPassword] = useState(false)
  const navigate = useNavigate()

  function handleSubmit(e) {
    e.preventDefault()
    // Demo only — no real authentication is performed.
    navigate(role === 'couple' ? '/portal' : '/staff')
  }

  return (
    <div className="rounded-3xl border border-slate-100 bg-white p-8 shadow-soft sm:p-10">
      <h2 className="font-serif text-2xl font-bold text-ink">Log in</h2>
      <p className="mt-1 text-sm text-slate-500">Please enter your credentials to continue.</p>

      <div className="mt-6 flex rounded-xl bg-slate-100 p-1">
        {['couple', 'hospital'].map((option) => (
          <button
            key={option}
            type="button"
            onClick={() => setRole(option)}
            className={`flex-1 rounded-lg py-2 text-sm font-semibold capitalize transition-colors ${
              role === option ? 'bg-white text-ink shadow-sm' : 'text-slate-500'
            }`}
          >
            {option}
          </button>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="mt-6 space-y-5">
        <div>
          <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
            Email Address
          </label>
          <div className="relative">
            <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="email"
              required
              placeholder="name@example.com"
              className="w-full rounded-xl border border-slate-200 py-2.5 pl-9 pr-3 text-sm focus:border-brand-400 focus:outline-none"
            />
          </div>
        </div>

        <div>
          <div className="mb-1.5 flex items-center justify-between">
            <label className="block text-xs font-semibold uppercase tracking-wide text-slate-500">
              Password
            </label>
            <a href="#" className="text-xs font-semibold text-brand-600">
              Forgot Password?
            </a>
          </div>
          <div className="relative">
            <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type={showPassword ? 'text' : 'password'}
              required
              placeholder="••••••••"
              className="w-full rounded-xl border border-slate-200 py-2.5 pl-9 pr-9 text-sm focus:border-brand-400 focus:outline-none"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
        </div>

        <Button type="submit" size="lg" className="w-full" icon={ArrowRight}>
          Sign In
        </Button>
      </form>

      <div className="my-6 flex items-center gap-3 text-xs text-slate-400">
        <span className="h-px flex-1 bg-slate-200" />
        Or continue with
        <span className="h-px flex-1 bg-slate-200" />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <button className="flex items-center justify-center gap-2 rounded-xl border border-slate-200 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50">
          Google
        </button>
        <button className="flex items-center justify-center gap-2 rounded-xl border border-slate-200 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50">
          Apple
        </button>
      </div>

      <p className="mt-6 text-center text-sm text-slate-500">
        Don't have an account?{' '}
        <a href="#" className="font-semibold text-brand-600">
          Register here
        </a>
      </p>
      <p className="mt-4 flex items-center justify-center gap-1.5 text-xs text-slate-400">
        <ShieldCheck size={14} /> HIPAA Compliant Platform
      </p>
    </div>
  )
}
