import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { Menu, X, UserRound, Waves } from 'lucide-react'
import Button from '../common/Button.jsx'

const links = [
  { label: 'Features', href: '#features' },
  { label: 'Benefits', href: '#benefits' },
  { label: 'FAQ', href: '#faq' },
  { label: 'Contact', href: '#contact' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)

  return (
    <header className="sticky top-0 z-40 border-b border-slate-100 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-600 text-white">
            <Waves size={18} />
          </span>
          <span className="text-lg font-bold text-brand-700">MidCare</span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {links.map((link) => (
            <a key={link.label} href={link.href} className="text-sm font-medium text-slate-600 hover:text-brand-700">
              {link.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <Button as={Link} to="/login" size="sm">
            Login
          </Button>
          <Link
            to="/login"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-600 text-white"
          >
            <UserRound size={16} />
          </Link>
        </div>

        <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Toggle menu">
          {open ? <X /> : <Menu />}
        </button>
      </div>

      {open && (
        <div className="border-t border-slate-100 bg-white px-4 pb-4 md:hidden">
          <nav className="flex flex-col gap-3 pt-3">
            {links.map((link) => (
              <a key={link.label} href={link.href} className="text-sm font-medium text-slate-600">
                {link.label}
              </a>
            ))}
            <Button as={Link} to="/login" size="sm" className="mt-2 w-full">
              Login
            </Button>
          </nav>
        </div>
      )}
    </header>
  )
}
