import React from 'react'
import Button from '../common/Button.jsx'
import Badge from '../common/Badge.jsx'

const typeTone = {
  Medicine: 'brand',
  Hydration: 'teal',
  Appointment: 'warning',
}

export default function ScheduleItem({ time, type, title, detail }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-100 p-4">
      <div className="flex items-start gap-3">
        <Badge tone={typeTone[type] || 'default'}>{type}</Badge>
        <div>
          <p className="font-semibold text-ink">{title}</p>
          <p className="text-sm text-slate-500">{detail}</p>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <span className="text-sm font-semibold text-slate-500">{time}</span>
        {type === 'Appointment' ? (
          <Button size="sm" variant="secondary">View Details</Button>
        ) : (
          <>
            <Button size="sm" variant="secondary">Snooze 15m</Button>
            <Button size="sm">Mark Complete</Button>
          </>
        )}
      </div>
    </div>
  )
}
