import React from 'react'
import { NavLink } from 'react-router-dom'
import { Waves } from 'lucide-react'
import Icon from '../common/Icon.jsx'
import { patientNav } from '../../data/mockData.js'

export default function PatientSidebar() {
  return (
    <aside className="hidden w-64 shrink-0 flex-col border-r border-slate-100 bg-white lg:flex">
      <div className="flex items-center gap-2 px-6 py-6">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-care-tealDark text-white">
          <Waves size={16} />
        </span>
        <span className="text-base font-bold text-care-tealDark">MidCare Me</span>
      </div>

      <nav className="flex-1 space-y-1 px-3">
        {patientNav.map((item) => (
          <NavLink
            key={item.label}
            to={item.to}
            end={item.to === '/portal'}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-care-teal/20 text-care-tealDark'
                  : item.danger
                  ? 'text-rose-600 hover:bg-rose-50'
                  : 'text-slate-600 hover:bg-slate-50'
              }`
            }
          >
            <Icon name={item.icon} size={18} />
            {item.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  )
}
