import React from 'react'
import PatientSidebar from '../components/patient/PatientSidebar.jsx'
import PatientTopbar from '../components/patient/PatientTopbar.jsx'

export default function PatientLayout({ children, showSearch = false }) {
  return (
    <div className="flex min-h-screen bg-slate-50">
      <PatientSidebar />
      <div className="flex-1">
        <PatientTopbar showSearch={showSearch} />
        <main className="px-4 py-6 sm:px-6 lg:px-8">{children}</main>
        <p className="px-4 pb-6 text-xs text-slate-400 sm:px-6 lg:px-8">Week 24 of pregnancy</p>
      </div>
    </div>
  )
}
