import React, { createContext, useContext, useEffect, useMemo, useState, useCallback } from 'react'
import hospitalStaffSeed from '../data/hospitalStaff.json'
import patientsSeed from '../data/patients.json'
import { calculateBMI, getTrimester } from '../utils/pregnancy.js'

const AppDataContext = createContext(null)

const LS_KEYS = {
  patients: 'midcare_patients_v1',
  staff: 'midcare_staff_v1',
  appointments: 'midcare_appointments_v1',
  healthLogs: 'midcare_healthLogs_v1',
  reminders: 'midcare_reminders_v1',
  auth: 'midcare_auth_v1',
}

function loadLS(key, fallback) {
  try {
    const raw = window.localStorage.getItem(key)
    if (!raw) return fallback
    return JSON.parse(raw)
  } catch {
    return fallback
  }
}

function saveLS(key, value) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value))
  } catch {
    // ignore quota / privacy-mode errors — app still works in-memory for the session
  }
}

const defaultReminders = (patientId) => [
  { id: `${patientId}-r1`, time: '08:00 AM', type: 'Medicine', title: 'Prenatal Vitamins', detail: 'Take with food. Dosage: 1 Tablet.', completed: false },
  { id: `${patientId}-r2`, time: '09:00 AM', type: 'Hydration', title: 'Morning Hydration', detail: 'Drink 500ml of water.', completed: false },
  { id: `${patientId}-r3`, time: '02:30 PM', type: 'Appointment', title: 'Ultrasound Scan', detail: 'Remember to bring previous reports.', completed: false },
]

export function AppDataProvider({ children }) {
  const [staff, setStaff] = useState(() => loadLS(LS_KEYS.staff, hospitalStaffSeed))
  const [patients, setPatients] = useState(() => loadLS(LS_KEYS.patients, patientsSeed))
  const [appointments, setAppointments] = useState(() => loadLS(LS_KEYS.appointments, []))
  const [healthLogs, setHealthLogs] = useState(() => loadLS(LS_KEYS.healthLogs, {}))
  const [reminders, setReminders] = useState(() => loadLS(LS_KEYS.reminders, {}))
  const [auth, setAuth] = useState(() => loadLS(LS_KEYS.auth, { type: null, id: null }))

  useEffect(() => saveLS(LS_KEYS.staff, staff), [staff])
  useEffect(() => saveLS(LS_KEYS.patients, patients), [patients])
  useEffect(() => saveLS(LS_KEYS.appointments, appointments), [appointments])
  useEffect(() => saveLS(LS_KEYS.healthLogs, healthLogs), [healthLogs])
  useEffect(() => saveLS(LS_KEYS.reminders, reminders), [reminders])
  useEffect(() => saveLS(LS_KEYS.auth, auth), [auth])

  // ---------- Auth ----------
  const currentStaff = useMemo(
    () => (auth.type === 'staff' ? staff.find((s) => s.id === auth.id) || null : null),
    [auth, staff]
  )
  const currentPatient = useMemo(
    () => (auth.type === 'patient' ? patients.find((p) => p.id === auth.id) || null : null),
    [auth, patients]
  )

  const staffLogin = useCallback(
    (email, password) => {
      const match = staff.find(
        (s) => s.email.toLowerCase() === String(email).toLowerCase() && s.password === password
      )
      if (!match) return { ok: false, error: 'Incorrect email or password for hospital staff.' }
      setAuth({ type: 'staff', id: match.id })
      return { ok: true, staff: match }
    },
    [staff]
  )

  const patientLogin = useCallback(
    (email, password) => {
      const match = patients.find(
        (p) => p.email.toLowerCase() === String(email).toLowerCase() && p.password === password
      )
      if (!match) return { ok: false, error: 'Incorrect email or password for patient portal.' }
      setAuth({ type: 'patient', id: match.id })
      return { ok: true, patient: match }
    },
    [patients]
  )

  const logout = useCallback(() => setAuth({ type: null, id: null }), [])

  // ---------- Patients ----------
  const registerPatient = useCallback((form) => {
    let error = null
    setPatients((prev) => {
      if (prev.some((p) => p.email.toLowerCase() === String(form.email).toLowerCase())) {
        error = 'A patient with this email already exists.'
        return prev
      }
      const nextNum = 8924 + prev.length + 1
      const id = form.id?.trim() || `PT-${nextNum}`
      const bmi = form.bmi || calculateBMI(form.weight, form.height) || ''
      const newPatient = {
        id,
        name: form.name,
        email: form.email,
        password: form.password,
        age: form.age,
        dob: form.dob,
        phone: form.phone,
        address: form.address,
        bloodGroup: form.bloodGroup,
        height: form.height,
        weight: form.weight,
        bmi,
        pregnancyWeek: Number(form.pregnancyWeek) || 1,
        dueDate: form.dueDate,
        previousPregnancies: form.previousPregnancies || 0,
        previousBirths: form.previousBirths || 0,
        previousComplications: form.previousComplications || 'None',
        medicalConditions: form.medicalConditions || 'None',
        allergies: form.allergies || 'None',
        medications: form.medications || 'None',
        partnerName: form.partnerName,
        partnerPhone: form.partnerPhone,
        partnerEmail: form.partnerEmail,
        emergencyContact: form.emergencyContact || `${form.partnerName || ''} · ${form.partnerPhone || ''}`,
        riskLevel: form.riskLevel || 'Routine',
        currentSymptoms: form.currentSymptoms || [],
        doctor: form.doctor,
        midwife: form.midwife,
        nurse: form.nurse,
        vitals: {
          bloodPressure: form.bloodPressure || '—',
          hemoglobin: form.hemoglobin || '—',
          bloodSugar: form.bloodSugar || '—',
          heartRate: form.heartRate || '—',
        },
        baby: {
          name: form.babyName || '',
          weight: form.babyWeight || '',
          height: form.babyHeight || '',
        },
        status: 'STABLE',
        lastCheckup: new Date().toISOString().slice(0, 10),
        lastNote: 'New Registration',
        labReports: [],
        createdAt: new Date().toISOString(),
      }
      return [...prev, newPatient]
    })
    return { ok: !error, error }
  }, [])

  const updatePatient = useCallback((patientId, updates) => {
    setPatients((prev) => prev.map((p) => (p.id === patientId ? { ...p, ...updates } : p)))
  }, [])

  const addLabReport = useCallback((patientId, report) => {
    setPatients((prev) =>
      prev.map((p) =>
        p.id === patientId ? { ...p, labReports: [report, ...(p.labReports || [])] } : p
      )
    )
  }, [])

  // ---------- Appointments ----------
  const bookAppointment = useCallback((appointment) => {
    const record = {
      id: `APT-${Date.now()}`,
      status: 'Upcoming',
      createdAt: new Date().toISOString(),
      ...appointment,
    }
    setAppointments((prev) => [record, ...prev])
    return record
  }, [])

  const appointmentsForPatient = useCallback(
    (patientId) => appointments.filter((a) => a.patientId === patientId),
    [appointments]
  )

  const appointmentsForStaff = useCallback(
    (staffId) => appointments.filter((a) => a.staffId === staffId),
    [appointments]
  )

  // ---------- Health logs ----------
  const addHealthLog = useCallback((patientId, log) => {
    const entry = { date: new Date().toISOString(), ...log }
    setHealthLogs((prev) => ({
      ...prev,
      [patientId]: [entry, ...(prev[patientId] || [])],
    }))
    // Reflect the latest weight/BP/heart rate/blood sugar back onto the patient's current vitals
    setPatients((prev) =>
      prev.map((p) => {
        if (p.id !== patientId) return p
        return {
          ...p,
          weight: log.weight || p.weight,
          vitals: {
            ...p.vitals,
            bloodPressure: log.bloodPressure || p.vitals.bloodPressure,
            heartRate: log.heartRate || p.vitals.heartRate,
            bloodSugar: log.bloodSugar || p.vitals.bloodSugar,
          },
          currentSymptoms: log.symptoms || p.currentSymptoms,
        }
      })
    )
    return entry
  }, [])

  const healthLogsForPatient = useCallback((patientId) => healthLogs[patientId] || [], [healthLogs])

  // ---------- Reminders ----------
  const remindersForPatient = useCallback(
    (patientId) => reminders[patientId] || defaultReminders(patientId),
    [reminders]
  )

  const toggleReminder = useCallback(
    (patientId, reminderId) => {
      setReminders((prev) => {
        const list = prev[patientId] || defaultReminders(patientId)
        const updated = list.map((r) => (r.id === reminderId ? { ...r, completed: !r.completed } : r))
        return { ...prev, [patientId]: updated }
      })
    },
    []
  )

  // ---------- Derived dashboard stats ----------
  const registrationTrend = useMemo(() => {
    const now = new Date()
    const months = []
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
      months.push({ key: `${d.getFullYear()}-${d.getMonth()}`, month: d.toLocaleString('en-US', { month: 'short' }) })
    }
    const counts = Object.fromEntries(months.map((m) => [m.key, 0]))
    patients.forEach((p) => {
      const d = new Date(p.createdAt)
      const key = `${d.getFullYear()}-${d.getMonth()}`
      if (key in counts) counts[key] += 1
    })
    return months.map((m) => ({ month: m.month, patients: counts[m.key] }))
  }, [patients])

  const highRiskPatients = useMemo(() => patients.filter((p) => p.riskLevel === 'High Risk' || p.risk === 'High Risk'), [patients])

  const todaysAppointments = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10)
    return appointments.filter((a) => a.date === today)
  }, [appointments])

  const value = {
    staff,
    patients,
    appointments,
    currentStaff,
    currentPatient,
    isStaffAuthed: !!currentStaff,
    isPatientAuthed: !!currentPatient,
    staffLogin,
    patientLogin,
    logout,
    registerPatient,
    updatePatient,
    addLabReport,
    bookAppointment,
    appointmentsForPatient,
    appointmentsForStaff,
    addHealthLog,
    healthLogsForPatient,
    remindersForPatient,
    toggleReminder,
    registrationTrend,
    highRiskPatients,
    todaysAppointments,
  }

  return <AppDataContext.Provider value={value}>{children}</AppDataContext.Provider>
}

export function useAppData() {
  const ctx = useContext(AppDataContext)
  if (!ctx) throw new Error('useAppData must be used within AppDataProvider')
  return ctx
}
