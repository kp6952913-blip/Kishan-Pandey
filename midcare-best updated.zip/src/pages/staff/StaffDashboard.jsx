import React, { useMemo, useState } from 'react'
import { Download, Plus } from 'lucide-react'
import StaffLayout from '../../layouts/StaffLayout.jsx'
import Button from '../../components/common/Button.jsx'
import Card from '../../components/common/Card.jsx'
import KpiCard from '../../components/staff/KpiCard.jsx'
import RegistrationChart from '../../components/staff/RegistrationChart.jsx'
import AppointmentsDonut from '../../components/staff/AppointmentsDonut.jsx'
import RegistrationRow from '../../components/staff/RegistrationRow.jsx'
import UrgentTaskCard from '../../components/staff/UrgentTaskCard.jsx'
import NewPatientModal from '../../components/staff/NewPatientModal.jsx'
import { urgentTasks } from '../../data/mockData.js'
import { useAppData } from '../../context/AppDataContext.jsx'
import { titleForProfession } from '../../utils/pregnancy.js'
import { exportDailyReportPDF } from '../../utils/exportReport.js'

export default function StaffDashboard() {
  const { currentStaff, patients, highRiskPatients, todaysAppointments, registrationTrend } = useAppData()
  const [showNewPatient, setShowNewPatient] = useState(false)

  const activePatients = patients.filter((p) => p.status !== 'DISCHARGED')

  const kpis = useMemo(
    () => [
      { label: 'Registered', value: patients.length.toLocaleString(), icon: 'Users', tone: 'default' },
      { label: 'Active', value: activePatients.length.toLocaleString(), icon: 'PersonStanding', tone: 'default' },
      { label: "Today's Appts", value: todaysAppointments.length, sub: 'Scheduled', icon: 'CalendarDays' },
      { label: 'High-Risk', value: highRiskPatients.length, icon: 'AlertTriangle', tone: 'alert' },
      { label: 'Deliveries (Mo)', value: patients.filter((p) => p.pregnancyWeek >= 38).length, sub: 'Near term', icon: 'Smile' },
    ],
    [patients, activePatients, todaysAppointments, highRiskPatients]
  )

  const recentRegistrations = useMemo(
    () =>
      [...patients]
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        .slice(0, 5)
        .map((p) => ({
          name: p.name,
          id: p.id,
          week: p.pregnancyWeek,
          nextAppt: p.lastCheckup ? `Last: ${p.lastCheckup}` : '—',
          status: p.riskLevel,
        })),
    [patients]
  )

  function handleExport() {
    exportDailyReportPDF({
      staffName: currentStaff ? `${titleForProfession(currentStaff.profession)} ${currentStaff.name}` : 'Hospital Staff',
      stats: kpis.map((k) => ({ label: k.label, value: k.value })),
      highRisk: highRiskPatients,
      recentRegistrations: [...patients].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 10),
      todaysAppointments: todaysAppointments.map((a) => ({ patientName: a.patientName, staffName: a.staffName, time: a.time })),
    })
  }

  const welcomeName = currentStaff ? `${titleForProfession(currentStaff.profession)} ${currentStaff.name}` : 'there'

  return (
    <StaffLayout>
      <div className="space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="font-serif text-2xl font-bold text-ink sm:text-3xl">Welcome, {welcomeName}.</h1>
            <p className="mt-1 max-w-xl text-sm text-slate-500">
              Here's an overview of the hospital's maternal care metrics for today. You have{' '}
              <span className="font-semibold text-rose-600">{highRiskPatients.length} high-risk patients</span> requiring attention.
            </p>
          </div>
          <div className="flex gap-3">
            <Button variant="secondary" icon={Download} iconPosition="left" onClick={handleExport}>
              Export Daily Report
            </Button>
            <Button icon={Plus} iconPosition="left" onClick={() => setShowNewPatient(true)}>
              New Patient
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {kpis.map((kpi) => (
            <KpiCard key={kpi.label} {...kpi} />
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <RegistrationChart data={registrationTrend} />
          <AppointmentsDonut />
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <div className="mb-2 flex items-center justify-between">
              <h3 className="font-semibold text-ink">Recent Registrations</h3>
            </div>
            <div className="divide-y divide-slate-100">
              {recentRegistrations.length === 0 && (
                <p className="py-6 text-center text-sm text-slate-400">No patients registered yet.</p>
              )}
              {recentRegistrations.map((reg) => (
                <RegistrationRow key={reg.id} {...reg} />
              ))}
            </div>
          </Card>

          <Card>
            <h3 className="mb-3 flex items-center gap-2 font-semibold text-rose-600">Urgent Tasks</h3>
            <div className="space-y-3">
              {urgentTasks.map((task) => (
                <UrgentTaskCard key={task.title} {...task} />
              ))}
            </div>
          </Card>
        </div>
      </div>

      <NewPatientModal open={showNewPatient} onClose={() => setShowNewPatient(false)} />
    </StaffLayout>
  )
}
