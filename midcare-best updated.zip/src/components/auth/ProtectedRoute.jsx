import React from 'react'
import { Navigate } from 'react-router-dom'
import { useAppData } from '../../context/AppDataContext.jsx'

export function StaffRoute({ children }) {
  const { isStaffAuthed } = useAppData()
  if (!isStaffAuthed) return <Navigate to="/login" replace state={{ portal: 'hospital' }} />
  return children
}

export function PatientRoute({ children }) {
  const { isPatientAuthed } = useAppData()
  if (!isPatientAuthed) return <Navigate to="/login" replace state={{ portal: 'couple' }} />
  return children
}
