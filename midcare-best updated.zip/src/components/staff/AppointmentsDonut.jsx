import React from 'react'
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts'
import Card from '../common/Card.jsx'
import { appointmentBreakdown } from '../../data/mockData.js'

export default function AppointmentsDonut() {
  const total = appointmentBreakdown.reduce((sum, item) => sum + item.value, 0)

  return (
    <Card>
      <h3 className="font-semibold text-ink">Today's Appointments</h3>
      <p className="text-sm text-slate-400">Status breakdown for {total} scheduled visits</p>

      <div className="relative mx-auto mt-4 h-44 w-44">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={appointmentBreakdown}
              dataKey="value"
              nameKey="label"
              innerRadius={55}
              outerRadius={80}
              paddingAngle={2}
              startAngle={90}
              endAngle={-270}
            >
              {appointmentBreakdown.map((entry) => (
                <Cell key={entry.label} fill={entry.color} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <p className="text-2xl font-bold text-ink">{total}</p>
          <p className="text-xs text-slate-400">Total</p>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        {appointmentBreakdown.map((item) => (
          <div key={item.label} className="flex items-center gap-2 text-sm text-slate-600">
            <span className="h-2.5 w-2.5 rounded-full" style={{ background: item.color }} />
            {item.label} ({item.value})
          </div>
        ))}
      </div>
    </Card>
  )
}
