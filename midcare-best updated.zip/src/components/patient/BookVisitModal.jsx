import React, { useMemo, useState } from 'react'
import { CalendarDays, UserRound, CheckCircle2 } from 'lucide-react'
import Modal from '../common/Modal.jsx'
import Button from '../common/Button.jsx'
import { useAppData } from '../../context/AppDataContext.jsx'
import { titleForProfession } from '../../utils/pregnancy.js'

function buildMonthCells(year, month) {
  const firstDay = new Date(year, month, 1)
  const startWeekday = firstDay.getDay()
  const daysInMonth = new Date(year, month + 1, 0).getDate()
  const cells = [...Array(startWeekday).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => i + 1)]
  return cells
}

const weekDays = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT']

export default function BookVisitModal({ open, onClose, patient, onBooked }) {
  const { staff, bookAppointment } = useAppData()
  const today = new Date()
  const [viewYear] = useState(today.getFullYear())
  const [viewMonth] = useState(today.getMonth())
  const [selectedDate, setSelectedDate] = useState(null)
  const [selectedStaffId, setSelectedStaffId] = useState(null)
  const [confirmed, setConfirmed] = useState(false)

  const cells = useMemo(() => buildMonthCells(viewYear, viewMonth), [viewYear, viewMonth])
  const monthLabel = new Date(viewYear, viewMonth, 1).toLocaleString('en-US', { month: 'long', year: 'numeric' })
  const selectedStaff = staff.find((s) => s.id === selectedStaffId)

  function isPast(day) {
    if (!day) return true
    const d = new Date(viewYear, viewMonth, day)
    return d < new Date(today.toDateString())
  }

  function handlePickDate(day) {
    if (!day || isPast(day)) return
    const iso = new Date(viewYear, viewMonth, day).toISOString().slice(0, 10)
    setSelectedDate(iso)
    setSelectedStaffId(null)
  }

  function handleConfirm() {
    if (!selectedDate || !selectedStaff) return
    const appt = bookAppointment({
      patientId: patient.id,
      patientName: patient.name,
      staffId: selectedStaff.id,
      staffName: selectedStaff.name,
      staffProfession: selectedStaff.profession,
      date: selectedDate,
      time: '10:00 AM',
    })
    setConfirmed(true)
    onBooked?.(appt)
    setTimeout(() => {
      handleClose()
    }, 1300)
  }

  function handleClose() {
    setSelectedDate(null)
    setSelectedStaffId(null)
    setConfirmed(false)
    onClose()
  }

  return (
    <Modal open={open} onClose={handleClose} title="Book a Visit" subtitle="Choose a date, then a member of your care team." maxWidth="max-w-3xl">
      {confirmed ? (
        <div className="flex flex-col items-center justify-center gap-3 py-10 text-center">
          <CheckCircle2 size={40} className="text-emerald-500" />
          <p className="font-semibold text-ink">Appointment booked!</p>
          <p className="text-sm text-slate-500">
            {new Date(selectedDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })} with {selectedStaff?.name}
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          <div>
            <p className="mb-2 flex items-center gap-2 text-sm font-semibold text-ink">
              <CalendarDays size={16} className="text-brand-600" /> Step 1 — Select a Date
            </p>
            <div className="rounded-xl border border-slate-100 p-4">
              <p className="mb-3 text-center text-sm font-semibold text-ink">{monthLabel}</p>
              <div className="grid grid-cols-7 gap-1 text-center text-xs font-semibold text-slate-400">
                {weekDays.map((d) => <span key={d}>{d}</span>)}
              </div>
              <div className="mt-2 grid grid-cols-7 gap-1">
                {cells.map((day, i) => {
                  const iso = day ? new Date(viewYear, viewMonth, day).toISOString().slice(0, 10) : null
                  const active = iso === selectedDate
                  const disabled = isPast(day)
                  return (
                    <button
                      type="button"
                      key={i}
                      disabled={disabled}
                      onClick={() => handlePickDate(day)}
                      className={`flex h-10 items-center justify-center rounded-lg text-sm ${
                        !day
                          ? ''
                          : disabled
                          ? 'text-slate-300'
                          : active
                          ? 'bg-brand-600 font-semibold text-white'
                          : 'text-slate-600 hover:bg-brand-50'
                      }`}
                    >
                      {day || ''}
                    </button>
                  )
                })}
              </div>
            </div>
          </div>

          {selectedDate && (
            <div>
              <p className="mb-2 flex items-center gap-2 text-sm font-semibold text-ink">
                <UserRound size={16} className="text-brand-600" /> Step 2 — Choose Your Care Provider
              </p>
              <div className="grid gap-2 sm:grid-cols-2">
                {staff.map((s) => (
                  <button
                    type="button"
                    key={s.id}
                    onClick={() => setSelectedStaffId(s.id)}
                    className={`flex items-center gap-3 rounded-xl border p-3 text-left ${
                      selectedStaffId === s.id ? 'border-brand-300 bg-brand-50' : 'border-slate-100 hover:bg-slate-50'
                    }`}
                  >
                    <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">
                      {titleForProfession(s.profession)[0]}
                    </span>
                    <div>
                      <p className="text-sm font-semibold text-ink">{titleForProfession(s.profession)} {s.name}</p>
                      <p className="text-xs text-slate-400">{s.profession}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {selectedDate && selectedStaff && (
            <div className="rounded-xl border border-emerald-100 bg-emerald-50 p-4 text-sm">
              <p className="font-semibold text-emerald-700">Appointment Summary</p>
              <p className="mt-1 text-emerald-800">
                <strong>Appointment Date:</strong>{' '}
                {new Date(selectedDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
              </p>
              <p className="text-emerald-800">
                <strong>Doctor/Staff:</strong> {titleForProfession(selectedStaff.profession)} {selectedStaff.name}
              </p>
            </div>
          )}

          <div className="flex justify-end gap-3">
            <Button variant="secondary" type="button" onClick={handleClose}>Cancel</Button>
            <Button type="button" disabled={!selectedDate || !selectedStaff} onClick={handleConfirm}>
              Confirm Appointment
            </Button>
          </div>
        </div>
      )}
    </Modal>
  )
}
