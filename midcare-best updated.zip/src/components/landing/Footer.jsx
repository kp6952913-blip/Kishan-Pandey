import React from 'react'
import { Waves } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="border-t border-slate-100 bg-white">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 py-6 text-sm text-slate-500 sm:flex-row sm:px-6 lg:px-8">
        <div className="flex items-center gap-2">
          <span className="flex h-6 w-6 items-center justify-center rounded-md bg-brand-600 text-white">
            <Waves size={12} />
          </span>
          © 2024 MidCare Health.
        </div>
        <div className="flex gap-6">
          <a href="#" className="hover:text-brand-600">Privacy Policy</a>
          <a href="#" className="hover:text-brand-600">Terms of Service</a>
        </div>
      </div>
    </footer>
  )
}
